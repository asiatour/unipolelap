import { Hono } from "hono";
import type { Client } from "@sdk/server-types";
import { tables, buckets } from "@generated";
import { eq, and, asc, desc, sql, inArray } from "drizzle-orm";

/**
 * UNIPOL ELAP - English Language Assessment Program
 * Backend API for Mexican Police Cadets English Level Assessment
 */
export async function createApp(
  edgespark: Client<typeof tables>
): Promise<Hono> {
  const app = new Hono();

  // ⚠️ TEMPORARY POLICY (2026-10-01): test takers may attempt the assessment
  // more than once. Set back to false to restore one-attempt-only (original).
  const ALLOW_MULTIPLE_ATTEMPTS = true;

  // ═══════════════════════════════════════════════════════════
  // PUBLIC ROUTES (no auth required)
  // ═══════════════════════════════════════════════════════════

  /**
   * Check if a student ID already has a completed test
   */
  app.post("/api/public/check-student", async (c) => {
    try {
      const { studentId } = await c.req.json();

      if (!studentId || typeof studentId !== "string" || studentId.trim() === "") {
        return c.json({ error: "Student ID is required", errorEn: "Student ID is required" }, 400);
      }

      const trimmedId = studentId.trim();

      // Check for existing completed attempt
      // ⚠️ TEMPORARY: skipped while ALLOW_MULTIPLE_ATTEMPTS is true so cadets
      // who already finished can start a new attempt.
      if (!ALLOW_MULTIPLE_ATTEMPTS) {
        const existing = await edgespark.db
          .select()
          .from(tables.testAttempts)
          .where(
            and(
              eq(tables.testAttempts.studentId, trimmedId),
              eq(tables.testAttempts.status, "completed")
            )
          )
          .limit(1);

        if (existing.length > 0) {
          return c.json({
            exists: true,
            message: "Este estudiante ya completó la evaluación",
            messageEn: "This student has already completed the assessment",
            attempt: existing[0],
            multipleAttemptsAllowed: false,
          });
        }
      }

      // Check for in-progress attempt
      const inProgress = await edgespark.db
        .select()
        .from(tables.testAttempts)
        .where(
          and(
            eq(tables.testAttempts.studentId, trimmedId),
            eq(tables.testAttempts.status, "in_progress")
          )
        )
        .limit(1);

      if (inProgress.length > 0) {
        return c.json({
          exists: true,
          inProgress: true,
          attemptId: inProgress[0].id,
          multipleAttemptsAllowed: ALLOW_MULTIPLE_ATTEMPTS,
          message: "Este estudiante tiene un examen en progreso",
          messageEn: "This student has a test in progress",
        });
      }

      return c.json({ exists: false, multipleAttemptsAllowed: ALLOW_MULTIPLE_ATTEMPTS });
    } catch (error: any) {
      console.error("[API] check-student error:", error);
      return c.json({ error: "Server error", errorEn: "Server error" }, 500);
    }
  });

  /**
   * Start a new test attempt - selects 10 random questions per type
   * ordered by difficulty (ascending - easiest first)
   */
  app.post("/api/public/start-test", async (c) => {
    try {
      const { studentId } = await c.req.json();

      if (!studentId || typeof studentId !== "string" || studentId.trim() === "") {
        return c.json({ error: "Student ID is required" }, 400);
      }

      const trimmedId = studentId.trim();

      // Close out stale in-progress attempts for this student (e.g., a
      // previous session on the same browser that was abandoned mid-test)
      // so every retake starts clean and old partial runs never linger as
      // "in progress" or get mixed into the new attempt's results.
      await edgespark.db
        .update(tables.testAttempts)
        .set({ status: "abandoned" })
        .where(
          and(
            eq(tables.testAttempts.studentId, trimmedId),
            eq(tables.testAttempts.status, "in_progress")
          )
        );

      // Double-check no completed attempt
      // ⚠️ TEMPORARY: skipped while ALLOW_MULTIPLE_ATTEMPTS is true so new
      // attempts can be created for cadets who already finished.
      if (!ALLOW_MULTIPLE_ATTEMPTS) {
        const existing = await edgespark.db
          .select()
          .from(tables.testAttempts)
          .where(
            and(
              eq(tables.testAttempts.studentId, trimmedId),
              eq(tables.testAttempts.status, "completed")
            )
          )
          .limit(1);

        if (existing.length > 0) {
          return c.json({ error: "Student already completed the test" }, 400);
        }
      }

      // Create test attempt
      const now = Date.now();
      const attemptResult = await edgespark.db
        .insert(tables.testAttempts)
        .values({
          studentId: trimmedId,
          startedAt: now,
          status: "in_progress",
        })
        .returning();

      const attemptId = attemptResult[0].id;

      // Select 10 random questions per type, ordered by difficulty
      const questionsByType: Record<number, any[]> = {};

      for (let type = 1; type <= 4; type++) {
        // Get all questions of this type, ordered by difficulty
        const allQuestions = await edgespark.db
          .select()
          .from(tables.questions)
          .where(eq(tables.questions.questionType, type))
          .orderBy(asc(tables.questions.difficultyOrder));

        // Select 10 random from the full set
        const shuffled = [...allQuestions].sort(() => Math.random() - 0.5);
        const selected = shuffled.slice(0, 10);

        // Re-sort selected by difficulty order
        selected.sort((a, b) => a.difficultyOrder - b.difficultyOrder);

        questionsByType[type] = selected;
      }

      return c.json({
        attemptId,
        questions: questionsByType,
      });
    } catch (error: any) {
      console.error("[API] start-test error:", error);
      return c.json({ error: "Server error" }, 500);
    }
  });

  /**
   * Submit an answer for a question
   */
  app.post("/api/public/submit-answer", async (c) => {
    try {
      const { attemptId, questionId, selectedAnswer, timeSpent } = await c.req.json();

      if (!attemptId || !questionId) {
        return c.json({ error: "attemptId and questionId are required" }, 400);
      }

      // Get the correct answer
      const question = await edgespark.db
        .select()
        .from(tables.questions)
        .where(eq(tables.questions.id, questionId))
        .limit(1);

      if (question.length === 0) {
        return c.json({ error: "Question not found" }, 404);
      }

      // For fill-in-the-blank (type 4), compare case-insensitively and trimmed.
      // Multiple accepted answers may be stored separated by "/", "," or ";"
      // (e.g. "stolen/took") — typing ANY of them counts as correct.
      let isCorrect = 0;
      if (question[0].questionType === 4) {
        const normalize = (s: string) => s.trim().toLowerCase().replace(/\s+/g, " ");
        const typed = normalize(selectedAnswer || "");
        const accepted = (question[0].correctAnswer || "")
          .split(/[\/,;]/)
          .map(normalize)
          .filter(Boolean);
        isCorrect = typed !== "" && accepted.includes(typed) ? 1 : 0;
      } else {
        isCorrect = selectedAnswer === question[0].correctAnswer ? 1 : 0;
      }

      await edgespark.db.insert(tables.answers).values({
        attemptId,
        questionId,
        questionType: question[0].questionType,
        selectedAnswer: selectedAnswer || null,
        isCorrect,
        timeSpentSeconds: timeSpent || 0,
      });

      return c.json({ success: true, isCorrect: isCorrect === 1 });
    } catch (error: any) {
      console.error("[API] submit-answer error:", error);
      return c.json({ error: "Server error" }, 500);
    }
  });

  /**
   * Complete the test - calculate final score
   */
  app.post("/api/public/complete-test", async (c) => {
    try {
      const { attemptId } = await c.req.json();

      if (!attemptId) {
        return c.json({ error: "attemptId is required" }, 400);
      }

      // Get all answers for this attempt
      const answers = await edgespark.db
        .select()
        .from(tables.answers)
        .where(eq(tables.answers.attemptId, attemptId));

      const totalScore = answers.reduce((sum, a) => sum + (a.isCorrect || 0), 0);

      // Update attempt
      await edgespark.db
        .update(tables.testAttempts)
        .set({
          completedAt: Date.now(),
          totalScore,
          status: "completed",
        })
        .where(eq(tables.testAttempts.id, attemptId));

      return c.json({ success: true, totalScore, maxScore: 40 });
    } catch (error: any) {
      console.error("[API] complete-test error:", error);
      return c.json({ error: "Server error" }, 500);
    }
  });

  /**
   * Get results for a specific student
   */
  app.get("/api/public/results/:studentId", async (c) => {
    try {
      const studentId = c.req.param("studentId");

      if (!studentId) {
        return c.json({ error: "studentId is required" }, 400);
      }

      const attempts = await edgespark.db
        .select()
        .from(tables.testAttempts)
        .where(
          and(
            eq(tables.testAttempts.studentId, studentId),
            eq(tables.testAttempts.status, "completed")
          )
        )
        // Retakes are allowed, so return the LATEST completed attempt
        // (not an arbitrary one) — newest completion wins on ties.
        .orderBy(
          desc(tables.testAttempts.completedAt),
          desc(tables.testAttempts.id)
        );

      if (attempts.length === 0) {
        return c.json({ error: "No completed test found for this student" }, 404);
      }

      const attempt = attempts[0];

      // Get answers with question details
      const answersList = await edgespark.db
        .select()
        .from(tables.answers)
        .where(eq(tables.answers.attemptId, attempt.id));

      // Group by type
      const byType: Record<number, { correct: number; total: number }> = {};
      for (let type = 1; type <= 4; type++) {
        const typeAnswers = answersList.filter((a) => a.questionType === type);
        byType[type] = {
          correct: typeAnswers.filter((a) => a.isCorrect === 1).length,
          total: typeAnswers.length,
        };
      }

      return c.json({
        studentId,
        totalScore: attempt.totalScore,
        maxScore: attempt.maxScore,
        completedAt: attempt.completedAt,
        byType,
      });
    } catch (error: any) {
      console.error("[API] results error:", error);
      return c.json({ error: "Server error" }, 500);
    }
  });

  /**
   * Admin endpoint - Get all scores
   * Protected by admin secret code
   */
  app.post("/api/public/admin/scores", async (c) => {
    try {
      const { adminCode } = await c.req.json();

      // Verify admin code
      const storedCode = await edgespark.secret.get("ADMIN_SECRET_CODE");
      if (!storedCode || adminCode !== storedCode) {
        return c.json({ error: "Unauthorized", errorEn: "Unauthorized" }, 401);
      }

      // Get all completed attempts
      const attempts = await edgespark.db
        .select()
        .from(tables.testAttempts)
        .where(eq(tables.testAttempts.status, "completed"))
        .orderBy(sql`${tables.testAttempts.totalScore} DESC`);

      // Get answers for each attempt to compute per-type scores
      const results = await Promise.all(
        attempts.map(async (attempt) => {
          const answersList = await edgespark.db
            .select()
            .from(tables.answers)
            .where(eq(tables.answers.attemptId, attempt.id));

          const byType: Record<number, { correct: number; total: number }> = {};
          for (let type = 1; type <= 4; type++) {
            const typeAnswers = answersList.filter((a) => a.questionType === type);
            byType[type] = {
              correct: typeAnswers.filter((a) => a.isCorrect === 1).length,
              total: typeAnswers.length,
            };
          }

          return {
            id: attempt.id,
            studentId: attempt.studentId,
            totalScore: attempt.totalScore,
            maxScore: attempt.maxScore,
            completedAt: attempt.completedAt,
            byType,
          };
        })
      );

      return c.json({ scores: results, total: results.length });
    } catch (error: any) {
      console.error("[API] admin scores error:", error);
      return c.json({ error: "Server error" }, 500);
    }
  });

  /**
   * Admin endpoint - Delete a test score (attempt + its answers)
   * Protected by admin secret code
   */
  app.post("/api/public/admin/scores/delete", async (c) => {
    try {
      const { adminCode, scoreId } = await c.req.json();

      if (!(await verifyAdmin(adminCode))) {
        return c.json({ error: "Unauthorized" }, 401);
      }

      if (!scoreId || typeof scoreId !== "number") {
        return c.json({ error: "scoreId is required" }, 400);
      }

      const attempt = await edgespark.db
        .select()
        .from(tables.testAttempts)
        .where(eq(tables.testAttempts.id, scoreId))
        .limit(1);

      if (attempt.length === 0) {
        return c.json({ error: "Score not found" }, 404);
      }

      // Atomic: remove the attempt's answers and the attempt itself
      await edgespark.db.batch([
        edgespark.db
          .delete(tables.answers)
          .where(eq(tables.answers.attemptId, scoreId)),
        edgespark.db
          .delete(tables.testAttempts)
          .where(eq(tables.testAttempts.id, scoreId)),
      ]);

      console.log("[API] Score deleted:", scoreId, "student:", attempt[0].studentId);
      return c.json({ success: true });
    } catch (error: any) {
      console.error("[API] admin scores delete error:", error);
      return c.json({ error: "Server error" }, 500);
    }
  });

  // ═══════════════════════════════════════════════════════════
  // ADMIN QUESTION EDITOR ROUTES (protected by admin code)
  // ═══════════════════════════════════════════════════════════

  /**
   * Helper: verify admin code
   */
  async function verifyAdmin(adminCode: string): Promise<boolean> {
    const storedCode = await edgespark.secret.get("ADMIN_SECRET_CODE");
    return !!storedCode && adminCode === storedCode;
  }

  /**
   * Get all questions (optionally filtered by type)
   */
  app.post("/api/public/admin/questions", async (c) => {
    try {
      const { adminCode, questionType } = await c.req.json();

      if (!(await verifyAdmin(adminCode))) {
        return c.json({ error: "Unauthorized" }, 401);
      }

      let allQuestions;
      if (questionType && questionType >= 1 && questionType <= 4) {
        allQuestions = await edgespark.db
          .select()
          .from(tables.questions)
          .where(eq(tables.questions.questionType, questionType))
          .orderBy(
            asc(tables.questions.questionType),
            asc(tables.questions.difficultyOrder)
          );
      } else {
        allQuestions = await edgespark.db
          .select()
          .from(tables.questions)
          .orderBy(
            asc(tables.questions.questionType),
            asc(tables.questions.difficultyOrder)
          );
      }

      return c.json({ questions: allQuestions });
    } catch (error: any) {
      console.error("[API] admin questions list error:", error);
      return c.json({ error: "Server error" }, 500);
    }
  });

  /**
   * Create a new question
   */
  app.post("/api/public/admin/questions/create", async (c) => {
    try {
      const { adminCode, question } = await c.req.json();

      if (!(await verifyAdmin(adminCode))) {
        return c.json({ error: "Unauthorized" }, 401);
      }

      if (!question || !question.questionText || !question.correctAnswer) {
        return c.json({ error: "questionText and correctAnswer are required" }, 400);
      }

      if (!question.questionType || question.questionType < 1 || question.questionType > 4) {
        return c.json({ error: "questionType must be between 1 and 4" }, 400);
      }

      const result = await edgespark.db
        .insert(tables.questions)
        .values({
          questionType: question.questionType,
          difficultyOrder: question.difficultyOrder || 1,
          questionText: question.questionText,
          optionA: question.optionA || null,
          optionB: question.optionB || null,
          optionC: question.optionC || null,
          optionD: question.optionD || null,
          correctAnswer: question.correctAnswer,
        })
        .returning();

      console.log("[API] Question created:", result[0].id);
      return c.json({ success: true, question: result[0] });
    } catch (error: any) {
      console.error("[API] admin questions create error:", error);
      return c.json({ error: "Server error" }, 500);
    }
  });

  /**
   * Update an existing question
   */
  app.post("/api/public/admin/questions/update", async (c) => {
    try {
      const { adminCode, questionId, updates } = await c.req.json();

      if (!(await verifyAdmin(adminCode))) {
        return c.json({ error: "Unauthorized" }, 401);
      }

      if (!questionId) {
        return c.json({ error: "questionId is required" }, 400);
      }

      // Build update object with only provided fields
      const updateData: Record<string, any> = {};
      if (updates.questionType !== undefined) updateData.questionType = updates.questionType;
      if (updates.difficultyOrder !== undefined) updateData.difficultyOrder = updates.difficultyOrder;
      if (updates.questionText !== undefined) updateData.questionText = updates.questionText;
      if (updates.optionA !== undefined) updateData.optionA = updates.optionA;
      if (updates.optionB !== undefined) updateData.optionB = updates.optionB;
      if (updates.optionC !== undefined) updateData.optionC = updates.optionC;
      if (updates.optionD !== undefined) updateData.optionD = updates.optionD;
      if (updates.correctAnswer !== undefined) updateData.correctAnswer = updates.correctAnswer;

      if (Object.keys(updateData).length === 0) {
        return c.json({ error: "No fields to update" }, 400);
      }

      await edgespark.db
        .update(tables.questions)
        .set(updateData)
        .where(eq(tables.questions.id, questionId));

      console.log("[API] Question updated:", questionId);
      return c.json({ success: true });
    } catch (error: any) {
      console.error("[API] admin questions update error:", error);
      return c.json({ error: "Server error" }, 500);
    }
  });

  /**
   * Delete a question
   */
  app.post("/api/public/admin/questions/delete", async (c) => {
    try {
      const { adminCode, questionId } = await c.req.json();

      if (!(await verifyAdmin(adminCode))) {
        return c.json({ error: "Unauthorized" }, 401);
      }

      if (!questionId) {
        return c.json({ error: "questionId is required" }, 400);
      }

      await edgespark.db
        .delete(tables.questions)
        .where(eq(tables.questions.id, questionId));

      console.log("[API] Question deleted:", questionId);
      return c.json({ success: true });
    } catch (error: any) {
      console.error("[API] admin questions delete error:", error);
      return c.json({ error: "Server error" }, 500);
    }
  });

  return app;
}
