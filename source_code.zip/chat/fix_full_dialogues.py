#!/usr/bin/env python3
"""Rebuild question_text for types 2-4 as full dialogues from the import files.

The original pipeline (gen_sql.py) stored only the first dialogue line per
question because its parser dropped every continuation line. The import files
in chat/ already contain the verified full dialogues (cross-checked against
questions_raw.md from the official docx), including blank markers for types 3
and 4. This script re-parses those files, keeps every dialogue line,
normalizes blank markers to a visible "__________", and updates question_text
via the edgespark CLI (same pattern as batch_insert.py).

It also probes options/answers against the verified files and REPORTS any
drift (without changing options — those may have been edited on purpose).

Expected id mapping (insertion order == file order, verified against DB):
  type 2 -> ids 143-190, type 3 -> ids 191-238, type 4 -> ids 239-286
"""
import re
import subprocess
import sys

FILES = {
    2: "chat/import_type2_grammar.txt",
    3: "chat/import_type3_reading.txt",
    4: "chat/import_type4_fillblank.txt",
}

ID_RANGES = {2: (143, 190), 3: (191, 238), 4: (239, 286)}

BLANK = "__________"


def clean_blanks(text: str) -> str:
    """Normalize escaped (\\_\\_) or plain underscore runs into one visible blank."""
    return re.sub(r"(?:\\_|_){3,}", BLANK, text)


def parse_import(path: str):
    """Parse admin-import format:
    N. first dialogue line
    (continuation dialogue lines)
    A) option / B) option / ...
    Answer: X
    """
    questions = []
    current = None
    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            qm = re.match(r"^(\d+)\.\s*(.*)$", line)
            om = re.match(r"^([A-Da-d])\)\s*(.*)$", line)
            am = re.match(r"^Answer:\s*(.*)$", line)
            if qm and not om:
                if current:
                    questions.append(current)
                current = {
                    "text_parts": [qm.group(2)],
                    "a": "",
                    "b": "",
                    "c": "",
                    "d": "",
                    "ans": "",
                }
                continue
            if current is None:
                continue
            if om:
                current[om.group(1).lower()] = om.group(2).strip()
                continue
            if am:
                ans = am.group(1).strip()
                # MCQ answers are single letters; typing answers are full words
                current["ans"] = ans.upper() if re.fullmatch(r"[A-Da-d]", ans) else ans
                continue
            # Dialogue speaker lines ("A: ...", "B: ...") belong to the question
            current["text_parts"].append(line)
    if current:
        questions.append(current)
    for q in questions:
        q["text"] = clean_blanks("\n".join(q["text_parts"]))
        del q["text_parts"]
    return questions


def esc(s: str) -> str:
    return s.replace("'", "''")


def run_sql(sql: str, timeout: int = 90) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["npx", "edgespark", "db", "sql", sql],
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def probe_mismatches(parsed_by_id):
    """Report option/answer drift vs the verified files (report-only)."""
    for qtype, (start, end) in ID_RANGES.items():
        rows = []
        for qid in range(start, end + 1):
            q = parsed_by_id[qid]
            rows.append(
                f"({qid}, '{esc(q['a'])}', '{esc(q['b'])}', '{esc(q['c'])}', "
                f"'{esc(q['d'])}', '{esc(q['ans'])}')"
            )
        sql = (
            "WITH e(id, a, b, c, d, ans) AS (VALUES " + ", ".join(rows) + ") "
            "SELECT COALESCE(group_concat(q.id), 'none') AS mismatched FROM questions q "
            "JOIN e ON e.id = q.id WHERE "
            "q.option_a IS NOT e.a OR q.option_b IS NOT e.b OR q.option_c IS NOT e.c "
            "OR q.option_d IS NOT e.d OR q.correct_answer IS NOT e.ans"
        )
        r = run_sql(sql)
        cell = "parse-failed"
        m = re.search(r"│\s*'([^']*)'\s*│", r.stdout)
        if m:
            cell = m.group(1)
        print(f"Type {qtype} option/answer drift vs verified files: {cell}")
        if cell not in ("none", "parse-failed") and r.returncode == 0:
            ids = cell.split(",")
            detail_sql = (
                "SELECT id, option_a, option_b, option_c, option_d, correct_answer "
                f"FROM questions WHERE id IN ({','.join(ids)}) ORDER BY id"
            )
            d = run_sql(detail_sql)
            print(d.stdout.strip())


def main():
    parsed_by_id = {}
    updates = {}  # id -> question_text
    for qtype, path in FILES.items():
        qs = parse_import(path)
        start, end = ID_RANGES[qtype]
        print(f"Type {qtype}: parsed {len(qs)} questions from {path}")
        if len(qs) != end - start + 1:
            print(
                f"  ERROR: expected {end - start + 1} questions, got {len(qs)}",
                file=sys.stderr,
            )
            sys.exit(1)
        blanks = sum(1 for q in qs if BLANK in q["text"])
        multi = sum(1 for q in qs if "\n" in q["text"])
        print(f"  multi-line dialogues: {multi}/{len(qs)}, with blanks: {blanks}/{len(qs)}")
        print(f"  first: {qs[0]['text'].splitlines()[0]!r} (answer {qs[0]['ans']!r})")
        print(f"  last:  {qs[-1]['text'].splitlines()[0]!r} (answer {qs[-1]['ans']!r})")
        for i, q in enumerate(qs):
            parsed_by_id[start + i] = q
            updates[start + i] = q["text"]

    assert min(updates) == 143 and max(updates) == 286 and len(updates) == 144

    print("\n=== Updating question_text ===")
    ids = sorted(updates)
    BATCH = 12
    ok = 0
    for i in range(0, len(ids), BATCH):
        batch = ids[i : i + BATCH]
        stmts = [
            f"UPDATE questions SET question_text = '{esc(updates[qid])}' WHERE id = {qid}"
            for qid in batch
        ]
        result = run_sql("; ".join(stmts))
        batch_num = i // BATCH + 1
        if result.returncode == 0:
            ok += len(batch)
            print(f"Batch {batch_num}: updated ids {batch[0]}..{batch[-1]} (total {ok})")
        else:
            print(f"Batch {batch_num} FAILED: {result.stderr[:300]}", file=sys.stderr)
            for qid in batch:
                r = run_sql(
                    f"UPDATE questions SET question_text = '{esc(updates[qid])}' WHERE id = {qid}"
                )
                if r.returncode == 0:
                    ok += 1
                    print(f"  id {qid}: OK")
                else:
                    print(f"  id {qid}: FAILED - {r.stderr[:200]}", file=sys.stderr)

    print(f"\nUpdated {ok}/144 rows")

    print("\n=== Verification ===")
    checks = [
        (
            "length stats per type",
            "SELECT question_type, COUNT(*) AS cnt, MIN(LENGTH(question_text)) AS min_len, "
            "MAX(LENGTH(question_text)) AS max_len, CAST(AVG(LENGTH(question_text)) AS INT) AS avg_len "
            "FROM questions WHERE question_type IN (2,3,4) GROUP BY question_type",
        ),
        (
            "rows with visible blanks",
            f"SELECT COUNT(*) AS with_blank FROM questions WHERE question_type IN (2,3,4) AND question_text LIKE '%{BLANK}%'",
        ),
        (
            "rows still single-line (<100 chars)",
            "SELECT COUNT(*) AS still_short FROM questions WHERE question_type IN (2,3,4) AND LENGTH(question_text) < 100",
        ),
        (
            "leftover escaped underscores",
            "SELECT COUNT(*) AS escaped FROM questions WHERE question_text LIKE '%\\_%'",
        ),
    ]
    for label, sql in checks:
        r = run_sql(sql)
        print(f"\n--- {label} ---")
        print(r.stdout.strip() if r.returncode == 0 else f"FAILED: {r.stderr[:200]}")

    print("\n=== Option/answer drift report (not modified) ===")
    probe_mismatches(parsed_by_id)


if __name__ == "__main__":
    main()
