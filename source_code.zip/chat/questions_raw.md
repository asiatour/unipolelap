**Section 1: Being Friendly**

**Unit 1: Greetings & First Contact**

1. How do you say "Buenos días" in English?
   * A) Good evening
   * B) Good afternoon
   * C) Good night
   * D) Good morning
2. How do you say "Mucho gusto" in English?
   * A) Welcome
   * B) Take care
   * C) Nice to meet you
   * D) See you later
3. How do you say "Por favor" in English?
   * A) Thank you
   * B) You're welcome
   * C) Excuse me
   * D) Please
4. How do you say "¿Cómo estás?" in English?
   * A) What's your name?
   * B) Where are you from?
   * C) How are you?
   * D) How old are you?

**Unit 2: Numbers, Time & Calendar**

1. How do you say "Lunes" in English?
   * A) Tuesday
   * B) Thursday
   * C) Sunday
   * D) Monday
2. How do you say "¿Qué hora es?" in English?
   * A) What date is today?
   * B) When is it?
   * C) How long is it?
   * D) What time is it?
3. How do you say "Enero" in English?
   * A) June
   * B) July
   * C) January
   * D) August
4. How do you say "Catorce" in English?
   * A) Forty
   * B) Four
   * C) Fourteen
   * D) Fourteenth

**Unit 3: Making Yourself Understood**

1. How do you say "¿Puede repetir eso, por favor?" in English?
   * A) Can you repeat that, please?
   * B) Can you write it down?
   * C) Can you speak louder, please?
   * D) Could you spell that?
2. How do you say "No entiendo" in English?
   * A) I understand
   * B) I'm not sure
   * C) I don't understand
   * D) I don't know
3. How do you say "¿Cómo se deletrea eso?" in English?
   * A) How do you say that?
   * B) How do you write that?
   * C) How do you spell that?
   * D) Is that correct?
4. How do you say "Despacio, por favor" in English?
   * A) Louder, please
   * B) Again, please
   * C) Step by step
   * D) Slower, please

**Unit 4: Personal Info & Making Conversation**

1. How do you say "Apellido" in English?
   * A) First name
   * B) Hometown
   * C) Last name
   * D) Occupation
2. How do you say "¿De dónde eres?" in English?
   * A) Where do you live?
   * B) Where are you from?
   * C) Where are you going?
   * D) Who are you with?
3. How do you say "Nacionalidad" in English?
   * A) Country
   * B) City
   * C) Nationality
   * D) Address
4. How do you say "¿Cuántos años tienes?" in English?
   * A) How long are you staying?
   * B) What's your job?
   * C) How are you doing?
   * D) How old are you?

**Unit 5: Offering Assistance**

1. How do you say "¿Puedo ayudarle?" in English?
   * A) Do you need anything?
   * B) What do you need?
   * C) How are you?
   * D) Can I help you?
2. How do you say "Espere aquí, por favor" in English?
   * A) Come with me, please
   * B) Sit down, please
   * C) Look at this, please
   * D) Wait here, please
3. How do you say "Por supuesto" in English?
   * A) Not at all
   * B) Of course
   * C) No problem
   * D) Don't worry
4. How do you say "Firma" in English?
   * A) Document
   * B) Signature
   * C) Identification
   * D) Permission

**Unit 6: Small Talk & Warm Closings**

1. How do you say "Caluroso" in English?
   * A) Sunny
   * B) Hot
   * C) Cold
   * D) Windy
2. How do you say "¡Que tenga un buen viaje!" in English?
   * A) Have a safe trip!
   * B) Have a great day!
   * C) Enjoy your stay!
   * D) Good luck!
3. How do you say "Cuídate" in English?
   * A) Be safe!
   * B) Good luck!
   * C) Take care!
   * D) Stay safe!
4. How do you say "Por cierto" in English?
   * A) In that case
   * B) By the way
   * C) One more thing
   * D) Before you go

**Section 2: Giving Directions**

**Unit 7: Places Around the City**

1. How do you say "Tienda" in English?
   * A) Hospital
   * B) Pharmacy
   * C) Bank
   * D) Store
2. How do you say "Estación de metro" in English?
   * A) Metro station
   * B) Bus terminal
   * C) Airport
   * D) Taxi stand
3. How do you say "Disculpe, ¿dónde está...?" in English?
   * A) How do I get to...?
   * B) Is there a... near here?
   * C) Excuse me, where is...?
   * D) I'm looking for...
4. How do you say "Está cerca" in English?
   * A) It's far
   * B) It's over there
   * C) It's close
   * D) It's right here

**Unit 8: Where Is It?**

1. How do you say "Al lado de" in English?
   * A) Next to
   * B) Across from
   * C) In front of
   * D) Behind
2. How do you say "Entre" in English?
   * A) Beside
   * B) Between
   * C) Opposite
   * D) Near
3. How do you say "En la esquina" in English?
   * A) On the sidewalk
   * B) In the middle
   * C) On the corner
   * D) At the top
4. How do you say "A la izquierda" in English?
   * A) On the right
   * B) On the left
   * C) At the bottom
   * D) Upstairs

**Unit 9: Walking Directions**

1. How do you say "Siga derecho" in English?
   * A) Go straight
   * B) Turn left
   * C) Turn right
   * D) Go back
2. How do you say "Gire a la derecha" in English?
   * A) Turn left
   * B) Turn right
   * C) Go straight
   * D) Cross the street
3. How do you say "Una cuadra" in English?
   * A) One meter
   * B) One block
   * C) One minute
   * D) One step
4. How do you say "Cruce la calle" in English?
   * A) Continue straight
   * B) Walk back
   * C) Cross the street
   * D) Stop here

**Unit 10: Taking the Metro**

1. How do you say "Boleto" in English?
   * A) Card
   * B) Ticket
   * C) Fare
   * D) Turnstile
2. How do you say "Andén" in English?
   * A) Station
   * B) Platform
   * C) Entrance
   * D) Exit
3. How do you say "Transbordo" in English?
   * A) Exit
   * B) Board
   * C) Transfer
   * D) Insert
4. How do you say "Bájese en..." in English?
   * A) Get on at...
   * B) Wait at...
   * C) Get off at...
   * D) Transfer at...

**Unit 11: Taking the Bus**

1. How do you say "Parada de autobús" in English?
   * A) Bus stop
   * B) Bus station
   * C) Bus lane
   * D) Bus route
2. How do you say "Conductor" in English?
   * A) Passenger
   * B) Driver
   * C) Local
   * D) Resident
3. How do you say "Subir al autobús" in English?
   * A) Get on the bus
   * B) Get off the bus
   * C) Wait for the bus
   * D) Pay the driver
4. How do you say "Hora pico" in English?
   * A) Schedule
   * B) Delay
   * C) Rush hour
   * D) Last stop

**Unit 12: Putting It Together**

1. How do you say "Camine hasta la estación de metro" in English?
   * A) Walk to the metro station
   * B) Take the metro to the station
   * C) Get off at the metro station
   * D) Look for the metro station
2. How do you say "Es más rápido en metro" in English?
   * A) It's cheaper by bus
   * B) It's faster by metro
   * C) It's safer to walk
   * D) It's too far to walk
3. How do you say "Aquí tiene un mapa" in English?
   * A) I don't have a map
   * B) Show me on the map
   * C) Here's a map
   * D) Is there a map?
4. How do you say "La estación está cerrada" in English?
   * A) The line isn't working
   * B) The station is closed
   * C) The station is crowded
   * D) The train is late

**Section 3: Health & Safety**

**Unit 13: The Body**

1. How do you say "Cabeza" in English?
   * A) Chest
   * B) Neck
   * C) Face
   * D) Head
2. How do you say "Pecho" in English?
   * A) Chest
   * B) Stomach
   * C) Back
   * D) Shoulder
3. How do you say "Brazo" in English?
   * A) Leg
   * B) Wrist
   * C) Arm
   * D) Elbow
4. How do you say "Lado izquierdo" in English?
   * A) Left side
   * B) Right side
   * C) Front side
   * D) Back side

**Unit 14: Common Health Problems**

1. How do you say "Dolor de cabeza" in English?
   * A) Stomachache
   * B) Toothache
   * C) Headache
   * D) Backache
2. How do you say "Fiebre" in English?
   * A) Cough
   * B) Cold
   * C) Fever
   * D) Flu
3. How do you say "Mareado(a)" in English?
   * A) Nauseous
   * B) Dizzy
   * C) Tired
   * D) Weak
4. How do you say "Hueso roto" in English?
   * A) Sprain
   * B) Cut
   * C) Bruise
   * D) Broken bone

**Unit 15: Parts of a Home**

1. How do you say "Cocina" in English?
   * A) Kitchen
   * B) Living room
   * C) Bedroom
   * D) Dining room
2. How do you say "Puerta principal" in English?
   * A) Back door
   * B) Gate
   * C) Front door
   * D) Window
3. How do you say "Llave" in English?
   * A) Lock
   * B) Key
   * C) Alarm
   * D) Switch
4. How do you say "Extintor de incendios" in English?
   * A) Smoke detector
   * B) Fire extinguisher
   * C) Water heater
   * D) Security camera

**Unit 16: Responding at a Home**

1. How do you say "Recibimos una llamada" in English?
   * A) We got a call
   * B) We need help
   * C) We are leaving
   * D) We called you
2. How do you say "¿Está todo bien?" in English?
   * A) Is anyone injured?
   * B) What happened?
   * C) Is everyone alright?
   * D) Are you alone?
3. How do you say "Fuga de gas" in English?
   * A) Fire
   * B) Break-in
   * C) Gas leak
   * D) Medical emergency
4. How do you say "No toque nada" in English?
   * A) Don't touch anything
   * B) Don't move
   * C) Don't worry
   * D) Don't open the door

**Unit 17: Staying Safe in the City**

1. How do you say "Tenga precaución" in English?
   * A) Stay here
   * B) Be cautious
   * C) Watch your belongings
   * D) Stay safe
2. How do you say "Carterista" in English?
   * A) Pickpocket
   * B) Thief
   * C) Scam
   * D) Stranger
3. How do you say "Lugar concurrido" in English?
   * A) Unsafe area
   * B) Tourist trap
   * C) Crowded place
   * D) Dark street
4. How do you say "Calles bien iluminadas" in English?
   * A) Empty streets
   * B) Dark streets
   * C) Well-lit streets
   * D) Crowded streets

**Unit 18: Putting It Together**

1. How do you say "¿Está lesionado(a)?" in English?
   * A) Are you hurt?
   * B) Are you okay?
   * C) Are you alone?
   * D) Are you scared?
2. How do you say "Llamaré a una ambulancia" in English?
   * A) I'll call the police
   * B) I'll call a doctor
   * C) I'll call an ambulance
   * D) I'll call for backup
3. How do you say "Mantenga la calma" in English?
   * A) Stay here
   * B) Stay calm
   * C) Stay safe
   * D) Stay alert
4. How do you say "¿Puede describir qué sucedió?" in English?
   * A) Can you show me where it hurts?
   * B) Did you see who did it?
   * C) What time did this happen?
   * D) Can you describe what happened?

**Section 4: Dealing with Problems**

**Unit 19: Lost & Stolen Items**

1. How do you say "Billetera" in English?
   * A) Purse
   * B) Backpack
   * C) Wallet
   * D) Passport
2. How do you say "Me robaron mi..." in English?
   * A) Someone stole my...
   * B) I lost my...
   * C) I can't find my...
   * D) I left my...
3. How do you say "Pasaporte" in English?
   * A) ID card
   * B) License
   * C) Passport
   * D) Document
4. How do you say "Levantaré un reporte" in English?
   * A) I'll check the lost and found
   * B) I'll file a report
   * C) I'll call your bank
   * D) I'll search the area

**Unit 20: Missing Persons & Descriptions**

1. How do you say "Alto(a)" in English?
   * A) Tall
   * B) Short
   * C) Heavy
   * D) Thin
2. How do you say "Cabello rizado" in English?
   * A) Straight hair
   * B) Short hair
   * C) Curly hair
   * D) Long hair
3. How do you say "Cicatriz" in English?
   * A) Tattoo
   * B) Beard
   * C) Scar
   * D) Mustache
4. How do you say "¿Qué ropa llevaba puesta?" in English?
   * A) What did he look like?
   * B) Where was he going?
   * C) What was he wearing?
   * D) When did you see him?

**Unit 21: Taxi & Transport Scams**

1. How do you say "Taxímetro" in English?
   * A) Meter
   * B) License plate
   * C) Receipt
   * D) Route
2. How do you say "El conductor me cobró de más" in English?
   * A) The meter wasn't working
   * B) The driver overcharged me
   * C) He took a longer route
   * D) He refused to give change
3. How do you say "Placa del vehículo" in English?
   * A) Taxi number
   * B) Driver's ID
   * C) License plate
   * D) Receipt
4. How do you say "Acordar el precio primero" in English?
   * A) Pay in advance
   * B) Agree on the price first
   * C) Ask for a receipt
   * D) Check the meter

**Unit 22: Restaurant, Bar & Card Scams**

1. How do you say "La cuenta" in English?
   * A) The receipt
   * B) The bill
   * C) The menu
   * D) The total
2. How do you say "Propina" in English?
   * A) Service charge
   * B) Tip
   * C) Cover charge
   * D) Tax
3. How do you say "Me cobraron dos veces" in English?
   * A) They added extra items
   * B) They charged me twice
   * C) The price was different
   * D) They overcharged my card
4. How do you say "Recibo detallado" in English?
   * A) Card statement
   * B) Receipt copy
   * C) Itemized bill
   * D) Menu price

**Unit 23: Taking a Report**

1. How do you say "¿Me permite su nombre?" in English?
   * A) Can I get your name?
   * B) Can I get your phone number?
   * C) Can I get your address?
   * D) Can I see your ID?
2. How do you say "Número de folio" in English?
   * A) Case number
   * B) Reference number
   * C) Report form
   * D) Passport number
3. How do you say "Firme aquí" in English?
   * A) Print your name
   * B) Write the date
   * C) Sign here
   * D) Check here
4. How do you say "Guarde esto para sus registros" in English?
   * A) Show this to your embassy
   * B) Keep this for your records
   * C) Take this to the bank
   * D) Bring this tomorrow

**Unit 24: Putting It Together**

1. How do you say "Se me perdió algo importante" in English?
   * A) I lost something important
   * B) My things were stolen
   * C) A person is missing
   * D) Someone took my wallet
2. How do you say "¿Cuándo fue la última vez que lo vio?" in English?
   * A) Where did this happen?
   * B) When did you last see them?
   * C) What does it look like?
   * D) Who were you with?
3. How do you say "Llenemos los detalles" in English?
   * A) Let's fill out the details
   * B) Let me write this down
   * C) Let me check the report
   * D) Let's call the embassy
4. How do you say "Haremos todo lo posible para ayudarle" in English?
   * A) We'll start searching now
   * B) We'll file the report now
   * C) We'll call you if we find it
   * D) We'll do our best to help

**Answer Key**

| **Question** | **Answer** | **Question** | **Answer** | **Question** | **Answer** | **Question** | **Answer** |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | D | 25 | D | 49 | D | 73 | C |
| 2 | C | 26 | A | 50 | A | 74 | A |
| 3 | D | 27 | C | 51 | C | 75 | C |
| 4 | C | 28 | C | 52 | A | 76 | B |
| 5 | D | 29 | A | 53 | C | 77 | A |
| 6 | D | 30 | B | 54 | C | 78 | C |
| 7 | C | 31 | C | 55 | B | 79 | C |
| 8 | C | 32 | B | 56 | D | 80 | C |
| 9 | A | 33 | A | 57 | A | 81 | A |
| 10 | C | 34 | B | 58 | C | 82 | B |
| 11 | C | 35 | B | 59 | B | 83 | C |
| 12 | D | 36 | C | 60 | B | 84 | B |
| 13 | C | 37 | B | 61 | A | 85 | B |
| 14 | B | 38 | B | 62 | C | 86 | B |
| 15 | C | 39 | C | 63 | C | 87 | B |
| 16 | D | 40 | C | 64 | A | 88 | C |
| 17 | D | 41 | A | 65 | B | 89 | A |
| 18 | D | 42 | B | 66 | A | 90 | A |
| 19 | B | 43 | A | 67 | C | 91 | C |
| 20 | B | 44 | C | 68 | C | 92 | B |
| 21 | B | 45 | A | 69 | A | 93 | A |
| 22 | A | 46 | B | 70 | C | 94 | B |
| 23 | C | 47 | C | 71 | B | 95 | A |
| 24 | B | 48 | B | 72 | D | 96 | D |

**Multiple Choice Questions (Part 2: Single-Word Completion)**

Below are 48 additional multiple-choice questions using the same A-B-A-B conversations. In each dialogue, one key target word has been removed and replaced with a blank (\_\_\_\_\_\_\_\_\_\_).

**Question 1**

**Unit 1: Greetings & First Contact** — *Greeting and self-introduction*

**Conversation:**

A: Good morning, sir!

B: Good morning. My name is Mark. What's your name?

A: I'm Officer López. Nice to meet you.

B: Nice to \_\_\_\_\_\_\_\_\_\_ you, too.

**Options:**

* A) hear
* B) know
* C) meet
* D) see

**Correct Answer:** C

**Question 2**

**Unit 1: Greetings & First Contact** — *Asking how someone is doing*

**Conversation:**

A: Hello! How are you doing today?

B: I'm doing well, thank you. And you?

A: Pretty good, thanks. Welcome to Mexico City!

B: Thank you \_\_\_\_\_\_\_\_\_\_ much!

**Options:**

* A) very
* B) more
* C) so
* D) too

**Correct Answer:** A

**Question 3**

**Unit 2: Numbers, Time & Calendar** — *Asking for the time*

**Conversation:**

A: Excuse me, Officer. Do you have the time?

B: Yes, let me check. It's 10:15.

A: Perfect. What time does the museum open?

B: It opens \_\_\_\_\_\_\_\_\_\_ 11:00.

**Options:**

* A) in
* B) at
* C) on
* D) to

**Correct Answer:** B

**Question 4**

**Unit 2: Numbers, Time & Calendar** — *Confirming phone numbers and dates*

**Conversation:**

A: Is today Tuesday or Wednesday?

B: Today is Tuesday, October 14th.

A: Great. Can I give you my phone number?

B: Yes, go \_\_\_\_\_\_\_\_\_\_.

**Options:**

* A) back
* B) out
* C) ahead
* D) on

**Correct Answer:** C

**Question 5**

**Unit 3: Making Yourself Understood** — *Asking someone to slow down or repeat*

**Conversation:**

A: Where is the bus stop to go directly to the airport?

B: I'm sorry, can you speak slowly, please?

A: Sure! Where is the bus stop for the airport?

B: Ah, I \_\_\_\_\_\_\_\_\_\_ now. It's on the corner.

**Options:**

* A) listen
* B) understand
* C) remember
* D) repeat

**Correct Answer:** B

**Question 6**

**Unit 3: Making Yourself Understood** — *Spelling a name to confirm details*

**Conversation:**

A: My last name is Szczepanski.

B: Could you spell that for me, please?

A: Yes, S-Z-C-Z-E-P-A-N-S-K-I.

B: Thank you, let me \_\_\_\_\_\_\_\_\_\_ that.

**Options:**

* A) write
* B) confirm
* C) ask
* D) spell

**Correct Answer:** B

**Question 7**

**Unit 4: Personal Info & Making Conversation** — *Asking about origin and travel duration*

**Conversation:**

A: Where are you visiting from?

B: I'm from Canada.

A: Welcome! How long are you staying in Mexico City?

B: I'm staying \_\_\_\_\_\_\_\_\_\_ one week.

**Options:**

* A) in
* B) at
* C) during
* D) for

**Correct Answer:** D

**Question 8**

**Unit 4: Personal Info & Making Conversation** — *Asking about occupation and purpose of travel*

**Conversation:**

A: Are you here on vacation or for work?

B: I'm here for work. I have a conference.

A: What's your job?

B: I'm an \_\_\_\_\_\_\_\_\_\_.

**Options:**

* A) engineered
* B) engineering
* C) engineer
* D) engineers

**Correct Answer:** C

**Question 9**

**Unit 5: Offering Assistance** — *Offering help to a lost tourist*

**Conversation:**

A: Excuse me, Officer. You look like you can help.

B: Can I help you, ma'am?

A: Yes, I'm looking for the tourist information booth.

B: \_\_\_\_\_\_\_\_\_\_ me, please. It's right over here.

**Options:**

* A) Listen
* B) Go
* C) Look
* D) Follow

**Correct Answer:** D

**Question 10**

**Unit 5: Offering Assistance** — *Requesting identification politely*

**Conversation:**

A: Can you help me find my group?

B: Of course. First, show me your identification, please.

A: Here is my passport.

B: Thank you. One \_\_\_\_\_\_\_\_\_\_, please.

**Options:**

* A) moment
* B) time
* C) minute
* D) second

**Correct Answer:** A

**Question 11**

**Unit 6: Small Talk & Warm Closings** — *Making small talk about weather and trip*

**Conversation:**

A: It's a very sunny and warm day today!

B: Yes, it is! Are you enjoying your trip?

A: Yes, Mexico City is beautiful.

B: I'm happy to \_\_\_\_\_\_\_\_\_\_ that!

**Options:**

* A) hear
* B) speak
* C) listen
* D) know

**Correct Answer:** A

**Question 12**

**Unit 6: Small Talk & Warm Closings** — *Warmly closing a conversation with a visitor*

**Conversation:**

A: Thank you for all your help, Officer!

B: You're very welcome. Do you need anything else?

A: No, that's everything. Have a good day!

B: Thanks! Enjoy the \_\_\_\_\_\_\_\_\_\_ of your day!

**Options:**

* A) stay
* B) rest
* C) part
* D) time

**Correct Answer:** B

**Question 13**

**Unit 7: Places Around the City** — *Asking for nearby services (ATM / Bank)*

**Conversation:**

A: Excuse me, is there an ATM near here?

B: Yes, there is one inside the shopping center.

A: Is it far from this park?

B: No, it's very \_\_\_\_\_\_\_\_\_\_.

**Options:**

* A) short
* B) close
* C) next
* D) near

**Correct Answer:** B

**Question 14**

**Unit 7: Places Around the City** — *Locating famous landmarks*

**Conversation:**

A: Excuse me, how do I get to the Zócalo?

B: The main plaza? You can walk straight down this avenue.

A: Is the cathedral next to it?

B: Yes, the cathedral is \_\_\_\_\_\_\_\_\_\_ on the Zócalo.

**Options:**

* A) directly
* B) just
* C) here
* D) right

**Correct Answer:** D

**Question 15**

**Unit 8: Where Is It?** — *Locating a building using relative positions*

**Conversation:**

A: Where is the national museum located?

B: It's across from the big fountain in the park.

A: Is it next to the coffee shop?

B: Yes, it's right \_\_\_\_\_\_\_\_\_\_ the coffee shop and the bookstore.

**Options:**

* A) between
* B) across
* C) behind
* D) among

**Correct Answer:** A

**Question 16**

**Unit 8: Where Is It?** — *Finding an office inside a building / floor level*

**Conversation:**

A: Excuse me, where is the bathroom in this building?

B: It's on the second floor, next to the stairs.

A: Is there an elevator?

B: Yes, the elevator is \_\_\_\_\_\_\_\_\_\_ your left.

**Options:**

* A) in
* B) at
* C) on
* D) to

**Correct Answer:** C

**Question 17**

**Unit 9: Walking Directions** — *Giving step-by-step walking instructions*

**Conversation:**

A: How do I walk to the Palace of Fine Arts?

B: Go straight for two blocks, then turn left at the traffic light.

A: Turn left at the traffic light?

B: Yes, \_\_\_\_\_\_\_\_\_\_. It's right on the corner.

**Options:**

* A) right
* B) sure
* C) correctly
* D) exactly

**Correct Answer:** D

**Question 18**

**Unit 9: Walking Directions** — *Reassuring distance and checking understanding*

**Conversation:**

A: Is it a long walk to the market?

B: No, it's a short walk—about five minutes.

A: Okay, great. Do I cross the avenue?

B: Yes, \_\_\_\_\_\_\_\_\_\_ the street and you'll see it.

**Options:**

* A) turn
* B) walk
* C) cross
* D) go

**Correct Answer:** C

**Question 19**

**Unit 10: Taking the Metro** — *Finding the correct metro line and direction*

**Conversation:**

A: Which metro line goes to Chapultepec?

B: You need Line 1, the pink line.

A: Which direction do I take?

B: Take Line 1 \_\_\_\_\_\_\_\_\_\_ Observatorio.

**Options:**

* A) toward
* B) for
* C) to
* D) into

**Correct Answer:** A

**Question 20**

**Unit 10: Taking the Metro** — *Buying tickets and entering the metro*

**Conversation:**

A: Where do I buy a metro ticket?

B: At the ticket window over there.

A: How much is the fare?

B: It's five pesos \_\_\_\_\_\_\_\_\_\_ ride.

**Options:**

* A) by
* B) for
* C) each
* D) per

**Correct Answer:** D

**Question 21**

**Unit 11: Taking the Bus** — *Finding the bus stop and correct bus number*

**Conversation:**

A: Excuse me, which bus goes to the museum?

B: Take bus number 7.

A: Where is the bus stop?

B: It's across the street, in \_\_\_\_\_\_\_\_\_\_ of the bank.

**Options:**

* A) next
* B) opposite
* C) front
* D) behind

**Correct Answer:** C

**Question 22**

**Unit 11: Taking the Bus** — *Paying the fare and knowing when to get off*

**Conversation:**

A: How do I pay on the Metrobús?

B: You need to use your transit card.

A: How many stops until the monument?

B: It's three stops \_\_\_\_\_\_\_\_\_\_ here.

**Options:**

* A) from
* B) away
* C) off
* D) to

**Correct Answer:** A

**Question 23**

**Unit 12: Putting It Together** — *Combining walking and transit options*

**Conversation:**

A: What's the best way to get to the airport from here?

B: The metro is faster than walking or taking a bus.

A: Okay. Do I walk to the station first?

B: Yes, walk two blocks, \_\_\_\_\_\_\_\_\_\_ take Line 5.

**Options:**

* A) then
* B) next
* C) after
* D) later

**Correct Answer:** A

**Question 24**

**Unit 12: Putting It Together** — *Handling a service disruption / alternative route*

**Conversation:**

A: Is the metro line working today?

B: No, that line is closed for construction.

A: Oh no! What do you recommend instead?

B: I recommend \_\_\_\_\_\_\_\_\_\_ the Metrobús instead.

**Options:**

* A) to take
* B) take
* C) taking
* D) takes

**Correct Answer:** C

**Question 25**

**Unit 13: The Body** — *Identifying location of pain or injury*

**Conversation:**

A: Are you okay, sir?

B: No, I fell down and hurt myself.

A: Where does it hurt?

B: My \_\_\_\_\_\_\_\_\_\_ leg and knee hurt.

**Options:**

* A) correct
* B) straight
* C) right
* D) rightly

**Correct Answer:** C

**Question 26**

**Unit 13: The Body** — *Specifying head / face injuries*

**Conversation:**

A: What happened to your face?

B: A ball hit me while I was walking.

A: Did it hit your eye or forehead?

B: It hit my forehead, right \_\_\_\_\_\_\_\_\_\_ my eyebrow.

**Options:**

* A) up
* B) over
* C) top
* D) above

**Correct Answer:** D

**Question 27**

**Unit 14: Common Health Problems** — *Asking about symptoms and calling for help*

**Conversation:**

A: You look unwell, ma'am. What's wrong?

B: I feel very dizzy and nauseous.

A: Do you need an ambulance?

B: Yes, please. I don't \_\_\_\_\_\_\_\_\_\_ I can stand.

**Options:**

* A) know
* B) feel
* C) think
* D) believe

**Correct Answer:** C

**Question 28**

**Unit 14: Common Health Problems** — *Dealing with minor injuries and offering care*

**Conversation:**

A: Ouch! I cut my hand on some broken glass.

B: Let me see. Is it bleeding a lot?

A: A little bit, but it burns.

B: Stay \_\_\_\_\_\_\_\_\_\_. Let's get some basic first aid.

**Options:**

* A) still
* B) calm
* C) easy
* D) quiet

**Correct Answer:** B

**Question 29**

**Unit 15: Parts of a Home** — *Identifying access points and residents*

**Conversation:**

A: Excuse me, Officer. We heard a loud noise.

B: Is anyone inside the house?

A: My elderly mother is in the living room.

B: Is the \_\_\_\_\_\_\_\_\_\_ door unlocked?

**Options:**

* A) entrance
* B) front
* C) forward
* D) first

**Correct Answer:** B

**Question 30**

**Unit 15: Parts of a Home** — *Checking home safety features*

**Conversation:**

A: Officer, I smell smoke coming from next door.

B: Did you hear a smoke detector alarm?

A: Yes, the alarm is ringing loudly!

B: Please stay \_\_\_\_\_\_\_\_\_\_. We will check the property.

**Options:**

* A) away
* B) out
* C) outside
* D) off

**Correct Answer:** C

**Question 31**

**Unit 16: Responding at a Home** — *Arriving at a home after a call*

**Conversation:**

A: Hello, Officer! Thank you for coming so fast.

B: We got a call about a noise complaint. Is everyone alright?

A: Yes, we were just having a disagreement, but it's fine now.

B: Please keep the noise \_\_\_\_\_\_\_\_\_\_ so your neighbors can sleep.

**Options:**

* A) under
* B) off
* C) low
* D) down

**Correct Answer:** D

**Question 32**

**Unit 16: Responding at a Home** — *Securing a scene and instructing occupants*

**Conversation:**

A: Someone tried to break into my back door!

B: Is the person still inside or nearby?

A: No, they ran away down the street.

B: Please stay right here and don't \_\_\_\_\_\_\_\_\_\_ the door handle.

**Options:**

* A) touch
* B) grab
* C) hold
* D) open

**Correct Answer:** A

**Question 33**

**Unit 17: Staying Safe in the City** — *Giving pickpocket warnings in crowded areas*

**Conversation:**

A: Is this market area safe for tourists?

B: It's generally fine, but it gets very crowded.

A: Should I be careful with my belongings?

B: Yes, keep your phone close and hold your bag in \_\_\_\_\_\_\_\_\_\_.

**Options:**

* A) ahead
* B) forward
* C) front
* D) before

**Correct Answer:** C

**Question 34**

**Unit 17: Staying Safe in the City** — *Advising on night travel and taxi safety*

**Conversation:**

A: What is the safest way to get back to my hotel at night?

B: Avoid dark, empty streets and don't walk alone.

A: Should I take a street taxi or an app taxi?

B: Use a \_\_\_\_\_\_\_\_\_\_ taxi or an app-based ride.

**Options:**

* A) licensing
* B) license
* C) licenses
* D) licensed

**Correct Answer:** D

**Question 35**

**Unit 18: Putting It Together** — *Managing an emergency scene with injury*

**Conversation:**

A: Help! My friend tripped and twisted her ankle!

B: Don't panic. Are you able to walk, ma'am?

C: No, it hurts too much to put weight on it.

B: Sit down here. I'll call \_\_\_\_\_\_\_\_\_\_ assistance for you.

**Options:**

* A) medicine
* B) medical
* C) medic
* D) medically

**Correct Answer:** B

**Question 36**

**Unit 18: Putting It Together** — *Combining home safety check and reassurance*

**Conversation:**

A: Officer, is my house safe to enter now after the alarm?

B: Yes, we checked all the rooms and windows. Everything is clear.

A: Thank you so much for your quick help!

B: You're very welcome. You're safe now. Call us if you \_\_\_\_\_\_\_\_\_\_ anything.

**Options:**

* A) need
* B) require
* C) have
* D) want

**Correct Answer:** A

**Question 37**

**Unit 19: Lost & Stolen Items** — *Reporting a lost or stolen wallet/bag*

**Conversation:**

A: Excuse me, Officer. Someone stole my purse!

B: I'm sorry to hear that. Where were you when it happened?

A: I was sitting at a café table about ten minutes ago.

B: Can you \_\_\_\_\_\_\_\_\_\_ what the purse looks like?

**Options:**

* A) tell
* B) describe
* C) say
* D) explain

**Correct Answer:** B

**Question 38**

**Unit 19: Lost & Stolen Items** — *Taking down details and providing a case reference*

**Conversation:**

A: I left my backpack on the bench and now it's gone.

B: Okay, I'll file a report for you right now.

A: Will I get a reference number for my insurance?

B: Yes, here is your case reference \_\_\_\_\_\_\_\_\_\_.

**Options:**

* A) number
* B) file
* C) digit
* D) code

**Correct Answer:** A

**Question 39**

**Unit 20: Missing Persons & Descriptions** — *Reporting a missing child/companion*

**Conversation:**

A: Officer, I can't find my young son! He was right behind me!

B: Stay calm, ma'am. We'll start searching right away.

A: Oh thank goodness! Please help me find him!

B: What is his name and what was he \_\_\_\_\_\_\_\_\_\_?

**Options:**

* A) carrying
* B) dressed
* C) wearing
* D) using

**Correct Answer:** C

**Question 40**

**Unit 20: Missing Persons & Descriptions** — *Gathering physical description details*

**Conversation:**

A: My friend got separated from our tour group.

B: Can you describe what he looks like?

A: He's tall, has short curly brown hair, and wears glasses.

B: Thank you. Do you have a \_\_\_\_\_\_\_\_\_\_ photo of him?

**Options:**

* A) present
* B) new
* C) late
* D) recent

**Correct Answer:** D

**Question 41**

**Unit 21: Taxi & Transport Scams** — *Reporting a taxi overcharging scam*

**Conversation:**

A: Excuse me, Officer. This taxi driver just charged me $50 for a five-minute ride!

B: Did he use the meter during the trip?

A: No, he refused to turn on the meter.

B: Do you have the license \_\_\_\_\_\_\_\_\_\_ number or a receipt?

**Options:**

* A) plate
* B) card
* C) board
* D) tag

**Correct Answer:** A

**Question 42**

**Unit 21: Taxi & Transport Scams** — *Taking a taxi report and prevention advice*

**Conversation:**

A: The driver took a very long route and demanded extra cash.

B: I understand your frustration. Let's write down the details.

A: Here is a photo I took of his license plate.

B: Great job. I will file an \_\_\_\_\_\_\_\_\_\_ report with this information.

**Options:**

* A) officer
* B) official
* C) office
* D) officially

**Correct Answer:** B

**Question 43**

**Unit 22: Restaurant, Bar & Card Scams** — *Reporting an inflated bill or double charge*

**Conversation:**

A: Officer, this restaurant charged my credit card twice for dinner!

B: Did you speak to the manager about the double charge?

A: Yes, but they refused to give me an itemized receipt.

B: Let's see your card \_\_\_\_\_\_\_\_\_\_ and go speak with them.

**Options:**

* A) bill
* B) statement
* C) paper
* D) account

**Correct Answer:** B

**Question 44**

**Unit 22: Restaurant, Bar & Card Scams** — *Advising victim of card scam on next steps*

**Conversation:**

A: They added a huge extra service charge that wasn't on the menu.

B: I'm taking note of this incident for our report.

A: What should I do about the charge on my card?

B: Contact your bank immediately to \_\_\_\_\_\_\_\_\_\_ the charge.

**Options:**

* A) dispute
* B) discuss
* C) cancel
* D) refuse

**Correct Answer:** A

**Question 45**

**Unit 23: Taking a Report** — *Opening a report and gathering personal details*

**Conversation:**

A: Hello Officer, I need to report a stolen phone.

B: Of course. Can I get your full name and local address?

A: My name is John Smith, staying at Hotel Alameda.

B: Thank you. What is your phone number \_\_\_\_\_\_\_\_\_\_ email?

**Options:**

* A) but
* B) with
* C) and
* D) or

**Correct Answer:** D

**Question 46**

**Unit 23: Taking a Report** — *Finalizing a report and giving instructions*

**Conversation:**

A: I've given you all the details of the incident.

B: Perfect. Please read this summary to make sure it's correct.

A: Everything looks accurate.

B: Please sign here, and keep this copy for your \_\_\_\_\_\_\_\_\_\_.

**Options:**

* A) notes
* B) records
* C) papers
* D) files

**Correct Answer:** B

**Question 47**

**Unit 24: Putting It Together** — *Handling a complex lost item & scam report*

**Conversation:**

A: Officer, my backpack with my passport was taken from a taxi!

B: Don't worry, we'll help you file a full report right now.

A: I'm so worried about my passport and travel plans.

B: We'll do our best to help, and you can contact your \_\_\_\_\_\_\_\_\_\_ with this report.

**Options:**

* A) ambassador
* B) consul
* C) embassy
* D) country

**Correct Answer:** C

**Question 48**

**Unit 24: Putting It Together** — *Reassuring a tourist after resolving an incident*

**Conversation:**

A: Thank you for helping me resolve the issue with the restaurant bill.

B: You're very welcome. Here is your copy of the incident report.

A: I really appreciate your patience and help today.

B: It was my \_\_\_\_\_\_\_\_\_\_. Enjoy the rest of your visit to Mexico City!

**Options:**

* A) pleasure
* B) welcome
* C) happy
* D) glad

**Correct Answer:** A

**Multiple Choice Questions (Part 3: Conversation Completion)**

Below are 48 short **A-B-A-B dialogues** across all 24 course units (2 topics per unit). In each scenario, the last line is missing.

**Question 1**

**Unit 1: Greetings & First Contact** — *Greeting and self-introduction*

**Conversation:**

**A:** Good morning, sir!

**B:** Good morning. My name is Mark. What's your name?

**A:** I'm Officer López. Nice to meet you.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Good night, Officer.
* B) Nice to meet you, too.
* C) See you later.
* D) Open your notebook.

**Correct Answer:** B

**Question 2**

**Unit 1: Greetings & First Contact** — *Asking how someone is doing*

**Conversation:**

**A:** Hello! How are you doing today?

**B:** I'm doing well, thank you. And you?

**A:** Pretty good, thanks. Welcome to Mexico City!

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) You're welcome.
* B) I'm Officer López.
* C) Thank you very much!
* D) Let's take a break.

**Correct Answer:** C

**Question 3**

**Unit 2: Numbers, Time & Calendar** — *Asking for the time*

**Conversation:**

**A:** Excuse me, Officer. Do you have the time?

**B:** Yes, let me check. It's 10:15.

**A:** Perfect. What time does the museum open?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) It's fifteen dollars.
* B) It opens at 11:00.
* C) It's on Monday.
* D) It's near the park.

**Correct Answer:** B

**Question 4**

**Unit 2: Numbers, Time & Calendar** — *Confirming phone numbers and dates*

**Conversation:**

**A:** Is today Tuesday or Wednesday?

**B:** Today is Tuesday, October 14th.

**A:** Great. Can I give you my phone number?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Yes, go ahead.
* B) No, it's October.
* C) At three o'clock.
* D) It's 200 pesos.

**Correct Answer:** A

**Question 5**

**Unit 3: Making Yourself Understood** — *Asking someone to slow down or repeat*

**Conversation:**

**A:** Where is the bus stop to go directly to the airport?

**B:** I'm sorry, can you speak slowly, please?

**A:** Sure! Where is the bus stop for the airport?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Capital letter, please.
* B) Ah, I understand now. It's on the corner.
* C) I don't speak English.
* D) Could you spell that?

**Correct Answer:** B

**Question 6**

**Unit 3: Making Yourself Understood** — *Spelling a name to confirm details*

**Conversation:**

**A:** My last name is Szczepanski.

**B:** Could you spell that for me, please?

**A:** Yes, S-Z-C-Z-E-P-A-N-S-K-I.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Thank you, let me confirm that.
* B) Faster, please.
* C) What's your name?
* D) I don't understand.

**Correct Answer:** A

**Question 7**

**Unit 4: Personal Info & Making Conversation** — *Asking about origin and travel duration*

**Conversation:**

**A:** Where are you visiting from?

**B:** I'm from Canada.

**A:** Welcome! How long are you staying in Mexico City?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) I'm thirty years old.
* B) I work as a teacher.
* C) I am Canadian.
* D) I’ll be here for one week.

**Correct Answer:** D

**Question 8**

**Unit 4: Personal Info & Making Conversation** — *Asking about occupation and purpose of travel*

**Conversation:**

**A:** Are you here on vacation or for work?

**B:** I'm here for work. I have a conference.

**A:** What do you do?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) I'm an engineer.
* B) I like the city very much.
* C) I'm from Germany.
* D) I'm staying at a hotel.

**Correct Answer:** A

**Question 9**

**Unit 5: Offering Assistance** — *Offering help to a lost tourist*

**Conversation:**

**A:** Excuse me, Officer.

**B:** Can I help you, ma'am?

**A:** Yes, I'm looking for the tourist information booth.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Don't worry about it.
* B) Follow me, please. It's right over here.
* C) What's your name?
* D) I have a question.

**Correct Answer:** B

**Question 10**

**Unit 5: Offering Assistance** — *Requesting identification politely*

**Conversation:**

**A:** Can you help me find my group?

**B:** Of course. First, show me your identification, please.

**A:** Here is my passport.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) What's the matter?
* B) Sit down, please.
* C) Thank you. One moment, please.
* D) Don't touch that.

**Correct Answer:** C

**Question 11**

**Unit 6: Small Talk & Warm Closings** — *Making small talk about weather and trip*

**Conversation:**

**A:** It's a very sunny and warm day today!

**B:** Yes, it is! Are you enjoying your trip?

**A:** Yes, Mexico City is beautiful.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) I don't know, sorry.
* B) Turn right on the next street.
* C) Have a safe trip!
* D) I'm happy to hear that!

**Correct Answer:** D

**Question 12**

**Unit 6: Small Talk & Warm Closings** — *Warmly closing a conversation with a visitor*

**Conversation:**

**A:** Thank you for all your help, Officer!

**B:** You're very welcome. Do you need anything else?

**A:** No, that's everything. Have a good day!

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) What brings you here?
* B) Thanks! Enjoy the rest of your day!
* C) I'm fine, thank you.
* D) It's two blocks away.

**Correct Answer:** B

**Question 13**

**Unit 7: Places Around the City** — *Asking for nearby services (ATM / Bank)*

**Conversation:**

**A:** Excuse me, is there an ATM near here?

**B:** Yes, there is one inside the shopping center.

**A:** Is it far from this park?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) No, it's very close.
* B) At two o'clock.
* C) Yes, I am.
* D) It's an ATM.

**Correct Answer:** A

**Question 14**

**Unit 7: Places Around the City** — *Locating famous landmarks*

**Conversation:**

**A:** Excuse me, how do I get to the Zócalo?

**B:** The main plaza? You can walk straight down this avenue.

**A:** Is the cathedral next to it?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) No, it's closed.
* B) Yes, the cathedral is in the Zócalo.
* C) The metro station is far.
* D) I don't speak Spanish.

**Correct Answer:** B

**Question 15**

**Unit 8: Where Is It?** — *Locating a building using relative positions*

**Conversation:**

**A:** Where is the national museum located?

**B:** It's across from the big fountain in the park.

**A:** Is it next to the coffee shop?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) I drink coffee every day.
* B) There is a coffee shop three blocks from here.
* C) Let’s get a cup of coffee.
* D) No, but there are many coffee shops nearby.

**Correct Answer:** D

**Question 16**

**Unit 8: Where Is It?** — *Finding an office inside a building / floor level*

**Conversation:**

**A:** Excuse me, where is the bathroom in this building?

**B:** It's on the second floor, next to the stairs.

**A:** Is there an elevator?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Yes, the elevator is on your left.
* B) On the corner of the street.
* C) No, it's downstairs.
* D) It's about ten minutes.

**Correct Answer:** A

**Question 17**

**Unit 9: Walking Directions** — *Giving step-by-step walking instructions*

**Conversation:**

**A:** How do I walk to the Palace of Fine Arts?

**B:** Go straight for two blocks, then turn left at the traffic light.

**A:** Turn left at the traffic light?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Slowly, please.
* B) No, take the bus.
* C) Yes, exactly. It's right on the corner.
* D) It's three o'clock.

**Correct Answer:** C

**Question 18**

**Unit 9: Walking Directions** — *Reassuring distance and checking understanding*

**Conversation:**

**A:** Is it a long walk to the market?

**B:** No, it's a short walk—about five minutes.

**A:** Okay, great. Do I cross the avenue?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Yes, cross the street and you'll see it.
* B) First walk, then take a taxi.
* C) I'm Officer López.
* D) No worries, take your time.

**Correct Answer:** A

**Question 19**

**Unit 10: Taking the Metro** — *Finding the correct metro line and direction*

**Conversation:**

**A:** Which metro line goes to Chapultepec?

**B:** You need Line 1, the pink line.

**A:** Which direction do I take?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Get off at the next station.
* B) Take Line 1 toward Observatorio.
* C) It's six pesos.
* D) Buy a ticket at the window.

**Correct Answer:** B

**Question 20**

**Unit 10: Taking the Metro** — *Buying tickets and entering the metro*

**Conversation:**

**A:** Where do I buy a metro ticket?

**B:** At the ticket window over there.

**A:** How much is the fare?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Take Line 2.
* B) It's five pesos per ride.
* C) Go up the stairs.
* D) Transfer at the next station.

**Correct Answer:** B

**Question 21**

**Unit 11: Taking the Bus** — *Finding the bus stop and correct bus number*

**Conversation:**

**A:** Excuse me, which bus goes to the museum?

**B:** Take bus number 7.

**A:** Where is the bus stop?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Pay the driver in cash.
* B) It's across the street, in front of the bank.
* C) It's rush hour now.
* D) Get off at the third stop.

**Correct Answer:** B

**Question 22**

**Unit 11: Taking the Bus** — *Paying the fare and knowing when to get off*

**Conversation:**

**A:** How do I pay on the Metrobús?

**B:** You need to use your transit card.

**A:** How many stops until the monument?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Sit down and hold on.
* B) It's three stops from here.
* C) On this side of the street.
* D) The bus is full.

**Correct Answer:** B

**Question 23**

**Unit 12: Putting It Together** — *Combining walking and transit options*

**Conversation:**

**A:** What's the best way to get to the airport from here?

**B:** The metro is faster than walking or taking a bus.

**A:** Okay. Do I walk to the station first?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Yes, walk two blocks, then take Line 5.
* B) It's cheaper by taxi.
* C) The station is closed.
* D) I don't have a map.

**Correct Answer:** A

**Question 24**

**Unit 12: Putting It Together** — *Handling a service disruption / alternative route*

**Conversation:**

**A:** Is the metro line working today?

**B:** No, that line is closed for construction.

**A:** Oh no! What do you recommend instead?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Show me on the map.
* B) You should take the Metrobús.
* C) Walk to the metro station.
* D) Yes, it's very fast.

**Correct Answer:** B

**Question 25**

**Unit 13: The Body** — *Identifying location of pain or injury*

**Conversation:**

**A:** Are you okay, sir?

**B:** No, I fell down and hurt myself.

**A:** Where does it hurt?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) My right leg and knee hurt.
* B) On the first floor.
* C) I am from Canada.
* D) I have a cold.

**Correct Answer:** A

**Question 26**

**Unit 13: The Body** — *Specifying head / face injuries*

**Conversation:**

**A:** What happened to your face?

**B:** A rock hit me while I was walking.

**A:** Did it hit your eye or forehead?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) My left foot hurts.
* B) It hit my forehead, right above my eyebrow.
* C) It's on the right side.
* D) I need a doctor.

**Correct Answer:** B

**Question 27**

**Unit 14: Common Health Problems** — *Asking about symptoms and calling for help*

**Conversation:**

**A:** You look unwell, ma'am. What's wrong?

**B:** I feel very dizzy and nauseous.

**A:** Do you need an ambulance?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Yes, please. I don't think I can stand.
* B) I'm allergic to cats.
* C) Sit down, please.
* D) I have a broken bone.

**Correct Answer:** A

**Question 28**

**Unit 14: Common Health Problems** — *Dealing with minor injuries and offering care*

**Conversation:**

**A:** Ouch! I cut my hand on some broken glass.

**B:** Let me see. Is it bleeding a lot?

**A:** A little bit, but it burns.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) I have a headache.
* B) Stay calm. Let's get some basic first aid.
* C) Where is the pharmacy?
* D) Can you stand up?

**Correct Answer:** B

**Question 29**

**Unit 15: Parts of a Home** — *Identifying access points and residents*

**Conversation:**

**A:** Excuse me, Officer. We heard a loud noise.

**B:** Is anyone inside the house?

**A:** My elderly mother is in the living room.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Where is the kitchen?
* B) Is the front door unlocked?
* C) I have a key.
* D) I'm going to turn off the stove.

**Correct Answer:** B

**Question 30**

**Unit 15: Parts of a Home** — *Checking home safety features*

**Conversation:**

**A:** Officer, I smell smoke coming from next door.

**B:** Did you hear a smoke detector alarm?

**A:** Yes, the alarm is ringing loudly!

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Please stay outside. We will check the property.
* B) I’ll need to see some identification.
* C) Is the refrigerator on?
* D) Where is the bathroom?

**Correct Answer:** A

**Question 31**

**Unit 16: Responding at a Home** — *Arriving at a home after a call*

**Conversation:**

**A:** Hello, Officer! Thank you for coming so fast.

**B:** We got a call about a noise complaint. Is everyone alright?

**A:** Yes, we were just having a disagreement, but it's fine now.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Please keep the noise down so your neighbors can sleep.
* B) Where is the gas leak?
* C) Check the windows and doors. They might be unlocked.
* D) Don't touch anything!

**Correct Answer:** A

**Question 32**

**Unit 16: Responding at a Home** — *Securing a scene and instructing occupants*

**Conversation:**

**A:** Someone tried to break into my back door!

**B:** Is the person still inside or nearby?

**A:** No, they ran away down the street.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) You are safe in the kitchen.
* B) Please stay right here and don't touch the door handle.
* C) Turn off the stove immediately.
* D) Recibimos una llamada.

**Correct Answer:** B

**Question 33**

**Unit 17: Staying Safe in the City** — *Giving pickpocket warnings in crowded areas*

**Conversation:**

**A:** Is this market area safe for tourists?

**B:** It's generally fine, but it gets very crowded.

**A:** Should I be careful with my belongings?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Take a fake taxi.
* B) Don't fight back.
* C) Yes, keep your phone close and hold your bag in front.
* D) Leave your hotel now.

**Correct Answer:** C

**Question 34**

**Unit 17: Staying Safe in the City** — *Advising on night travel and taxi safety*

**Conversation:**

**A:** What is the safest way to get back to my hotel at night?

**B:** Avoid dark, empty streets and don't walk alone.

**A:** Should I take a street taxi or an app taxi?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Don't carry any money.
* B) Use a licensed taxi or an app-based ride.
* C) Walk through the park.
* D) Report it to the police.

**Correct Answer:** B

**Question 35**

**Unit 18: Putting It Together** — *Managing an emergency scene with injury*

**Conversation:**

**A:** Help! My friend tripped and twisted her ankle!

**B:** Don't panic. Are you able to walk, ma'am?

**C:** No, it hurts too much to put weight on it.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Lock the front door.
* B) Take the pink metro line.
* C) Sit down here. I'll call medical assistance for you.
* D) Watch your belongings.

**Correct Answer:** C

**Question 36**

**Unit 18: Putting It Together** — *Combining home safety check and reassurance*

**Conversation:**

**A:** Officer, is my house safe to enter now after the alarm?

**B:** Yes, we checked all the rooms and windows. Everything is clear.

**A:** Thank you so much for your quick help!

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) You're very welcome. You're safe now. Call us if you need anything.
* B) Can you describe what happened?
* C) What did the item look like?
* D) Turn left at the next block.

**Correct Answer:** A

**Question 37**

**Unit 19: Lost & Stolen Items** — *Reporting a lost or stolen wallet/bag*

**Conversation:**

**A:** Excuse me, Officer. Someone stole my purse!

**B:** I'm sorry to hear that. Where were you when it happened?

**A:** I was sitting at a café table about ten minutes ago.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Did you cancel your hotel?
* B) Go straight two blocks.
* C) Can you describe what the purse looks like?
* D) Where is the bathroom?

**Correct Answer:** C

**Question 38**

**Unit 19: Lost & Stolen Items** — *Taking down details and providing a case reference*

**Conversation:**

**A:** I left my backpack on the bench and now it's gone.

**B:** Okay, I'll file a report for you right now.

**A:** Will I get a reference number for my insurance?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Call your embassy.
* B) Yes, here is your case reference number.
* C) It was leather and silver.
* D) No, check the lost and found.

**Correct Answer:** B

**Question 39**

**Unit 20: Missing Persons & Descriptions** — *Reporting a missing child/companion*

**Conversation:**

**A:** Officer, I can't find my young son! He was right behind me!

**B:** Stay calm, ma'am. We'll start searching right away.

**A:** Oh thank goodness! Please help me find him!

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) What is his name and what was he wearing?
* B) Does he have a scar?
* C) Is he tall or heavy?
* D) Where is your passport?

**Correct Answer:** A

**Question 40**

**Unit 20: Missing Persons & Descriptions** — *Gathering physical description details*

**Conversation:**

**A:** My friend got separated from our tour group.

**B:** Can you describe what he looks like?

**A:** He's tall, has short curly brown hair, and wears glasses.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Is he a pickpocket?
* B) What time does the bus leave?
* C) Thank you. Do you have a recent photo of him?
* D) What's his phone number?

**Correct Answer:** C

**Question 41**

**Unit 21: Taxi & Transport Scams** — *Reporting a taxi overcharging scam*

**Conversation:**

**A:** Excuse me, Officer. This taxi driver just charged me $50 for a five-minute ride!

**B:** Did he use the meter during the trip?

**A:** No, he refused to turn on the meter.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Always agree on the price first.
* B) Do you have the license plate number or a receipt?
* C) Take the next bus.
* D) Did you pay in cash?

**Correct Answer:** B

**Question 42**

**Unit 21: Taxi & Transport Scams** — *Taking a taxi report and prevention advice*

**Conversation:**

**A:** The driver took a very long route and demanded extra cash.

**B:** I understand your frustration. Let's write down the details.

**A:** Here is a photo I took of his license plate.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Next time, take the metro.
* B) Great job. I will file an official report with this information.
* C) You should not pay anything.
* D) Don't argue with him.

**Correct Answer:** B

**Question 43**

**Unit 22: Restaurant, Bar & Card Scams** — *Reporting an inflated bill or double charge*

**Conversation:**

**A:** Officer, this restaurant charged my credit card twice for dinner!

**B:** Did you speak to the manager about the double charge?

**A:** Yes, but they refused to give me an itemized receipt.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Let's see your card statement and go speak with them.
* B) Did you leave a tip?
* C) The menu prices are high.
* D) Count your change.

**Correct Answer:** A

**Question 44**

**Unit 22: Restaurant, Bar & Card Scams** — *Advising victim of card scam on next steps*

**Conversation:**

**A:** They added a huge extra service charge that wasn't on the menu.

**B:** I'm taking note of this incident for our report.

**A:** What should I do about the charge on my card?

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Always check the menu first.
* B) Contact your bank immediately to dispute the charge.
* C) Pay in cash next time.
* D) Count your change carefully.

**Correct Answer:** B

**Question 45**

**Unit 23: Taking a Report** — *Opening a report and gathering personal details*

**Conversation:**

**A:** Hello Officer, I need to report a stolen phone.

**B:** Of course. Can I get your full name and local address?

**A:** My name is John Smith, staying at Hotel Alameda.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Here is your case number.
* B) Sign here, please.
* C) What time did this happen?
* D) Thank you. What is your phone number or email?

**Correct Answer:** D

**Question 46**

**Unit 23: Taking a Report** — *Finalizing a report and giving instructions*

**Conversation:**

**A:** I've given you all the details of the incident.

**B:** Perfect. Please read this summary to make sure it's correct.

**A:** Everything looks accurate.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) What's the date today?
* B) Please sign here, and keep this copy for your records.
* C) Can you explain it again?
* D) No need to hurry.

**Correct Answer:** B

**Question 47**

**Unit 24: Putting It Together** — *Handling a complex lost item & scam report*

**Conversation:**

**A:** Officer, my backpack with my passport was taken from a taxi!

**B:** Don't worry, we'll help you file a full report right now.

**A:** I'm so worried about my passport and travel plans.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Take the metro instead.
* B) Have a safe rest of your trip.
* C) We'll do our best to help, and you can contact your embassy with this report.
* D) What does the taxi look like?

**Correct Answer:** C

**Question 48**

**Unit 24: Putting It Together** — *Reassuring a tourist after resolving an incident*

**Conversation:**

**A:** Thank you for helping me resolve the issue with the restaurant bill.

**B:** You're very welcome. Here is your copy of the incident report.

**A:** I really appreciate your patience and help today.

**B:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Options:**

* A) Is this all correct?
* B) It was my pleasure. Enjoy the rest of your visit to Mexico City!
* C) Call your bank right now.
* D) Let's fill out the details.

**Correct Answer:** B

**Fill-in-the-Blank Exercises (Part 4: Typing Practice)**

**Instructions:** Read each conversation and type the missing word into the blank space (\_\_\_\_\_\_\_\_\_\_).

**Question 1**

**Unit 1: Greetings & First Contact** — *Greeting and self-introduction*

**Conversation:**

A: Good morning, sir!

B: Good morning. My name is Mark. What's your name?

A: I'm Officer López. Nice to \_\_\_\_\_\_\_\_\_\_ you.

B: Nice to meet you, too.

**Answer:** meet

**Question 2**

**Unit 1: Greetings & First Contact** — *Asking how someone is doing*

**Conversation:**

A: Hello! How are you doing today?

B: I'm doing well, thank you. And you?

A: Pretty good, thanks. \_\_\_\_\_\_\_\_\_\_ to Mexico City!

B: Thank you very much!

**Answer:** Welcome

**Question 3**

**Unit 2: Numbers, Time & Calendar** — *Asking for the time*

**Conversation:**

A: Excuse me, Officer. Do you have the \_\_\_\_\_\_\_\_\_\_?

B: Yes, let me check. It's 10:15.

A: Perfect. What time does the museum open?

B: It opens at 11:00.

**Answer:** time

**Question 4**

**Unit 2: Numbers, Time & Calendar** — *Confirming phone numbers and dates*

**Conversation:**

A: Is today Tuesday or Wednesday?

B: Today is Tuesday, October 14th.

A: Great. Can I give you my phone \_\_\_\_\_\_\_\_\_\_?

B: Yes, go ahead.

**Answer:** number

**Question 5**

**Unit 3: Making Yourself Understood** — *Asking someone to slow down or repeat*

**Conversation:**

A: Where is the bus stop to go directly to the airport?

B: I'm sorry, can you speak \_\_\_\_\_\_\_\_\_\_, please?

A: Sure! Where is the bus stop for the airport?

B: Ah, I understand now. It's on the corner.

**Answer:** slowly

**Question 6**

**Unit 3: Making Yourself Understood** — *Spelling a name to confirm details*

**Conversation:**

A: My last name is Szczepanski.

B: Could you \_\_\_\_\_\_\_\_\_\_ that for me, please?

A: Yes, S-Z-C-Z-E-P-A-N-S-K-I.

B: Thank you, let me confirm that.

**Answer:** spell

**Question 7**

**Unit 4: Personal Info & Making Conversation** — *Asking about origin and travel duration*

**Conversation:**

A: Where are you visiting \_\_\_\_\_\_\_\_\_\_?

B: I'm from Canada.

A: Welcome! How long are you staying in Mexico City?

B: I'm staying for one week.

**Answer:** from

**Question 8**

**Unit 4: Personal Info & Making Conversation** — *Asking about occupation and purpose of travel*

**Conversation:**

A: Are you here on vacation or for \_\_\_\_\_\_\_\_\_\_?

B: I'm here for work. I have a conference.

A: What's your job?

B: I'm an engineer.

**Answer:** work

**Question 9**

**Unit 5: Offering Assistance** — *Offering help to a lost tourist*

**Conversation:**

A: Excuse me, Officer. You look like you can help.

B: Can I help you, ma'am?

A: Yes, I'm looking for the tourist information \_\_\_\_\_\_\_\_\_\_?

B: Follow me, please. It's right over here.

**Answer:** booth

**Question 10**

**Unit 5: Offering Assistance** — *Requesting identification politely*

**Conversation:**

A: Can you help me find my group?

B: Of course. First, show me your \_\_\_\_\_\_\_\_\_\_, please.

A: Here is my passport.

B: Thank you. One moment, please.

**Answer:** identification

**Question 11**

**Unit 6: Small Talk & Warm Closings** — *Making small talk about weather and trip*

**Conversation:**

A: It's a very sunny and warm day today!

B: Yes, it is! Are you \_\_\_\_\_\_\_\_\_\_ your trip?

A: Yes, Mexico City is beautiful.

B: I'm happy to hear that!

**Answer:** enjoying

**Question 12**

**Unit 6: Small Talk & Warm Closings** — *Warmly closing a conversation with a visitor*

**Conversation:**

A: Thank you for all your help, Officer!

B: You're very welcome. Do you need \_\_\_\_\_\_\_\_\_\_ else?

A: No, that's everything. Have a good day!

B: Thanks! Enjoy the rest of your day!

**Answer:** anything

**Question 13**

**Unit 7: Places Around the City** — *Asking for nearby services (ATM / Bank)*

**Conversation:**

A: Excuse me, is there an \_\_\_\_\_\_\_\_\_\_ near here?

B: Yes, there is one inside the shopping center.

A: Is it far from this park?

B: No, it's very close.

**Answer:** ATM

**Question 14**

**Unit 7: Places Around the City** — *Locating famous landmarks*

**Conversation:**

A: Excuse me, how do I get to the Zócalo?

B: The main plaza? You can walk \_\_\_\_\_\_\_\_\_\_ down this avenue.

A: Is the cathedral next to it?

B: Yes, the cathedral is right on the Zócalo.

**Answer:** straight

**Question 15**

**Unit 8: Where Is It?** — *Locating a building using relative positions*

**Conversation:**

A: Where is the national museum located?

B: It's \_\_\_\_\_\_\_\_\_\_ from the big fountain in the park.

A: Is it next to the coffee shop?

B: Yes, it's right between the coffee shop and the bookstore.

**Answer:** across

**Question 16**

**Unit 8: Where Is It?** — *Finding an office inside a building / floor level*

**Conversation:**

A: Excuse me, where is the bathroom in this building?

B: It's on the second floor, next to the \_\_\_\_\_\_\_\_\_\_?

A: Is there an elevator?

B: Yes, the elevator is on your left.

**Answer:** stairs

**Question 17**

**Unit 9: Walking Directions** — *Giving step-by-step walking instructions*

**Conversation:**

A: How do I walk to the Palace of Fine Arts?

B: Go straight for two blocks, then turn left at the traffic \_\_\_\_\_\_\_\_\_\_.

A: Turn left at the traffic light?

B: Yes, exactly. It's right on the corner.

**Answer:** light

**Question 18**

**Unit 9: Walking Directions** — *Reassuring distance and checking understanding*

**Conversation:**

A: Is it a long walk to the market?

B: No, it's a \_\_\_\_\_\_\_\_\_\_ walk—about five minutes.

A: Okay, great. Do I cross the avenue?

B: Yes, cross the street and you'll see it.

**Answer:** short

**Question 19**

**Unit 10: Taking the Metro** — *Finding the correct metro line and direction*

**Conversation:**

A: Which metro line goes to Chapultepec?

B: You \_\_\_\_\_\_\_\_\_\_ Line 1, the pink line.

A: Which direction do I take?

B: Take Line 1 toward Observatorio.

**Answer:** need

**Question 20**

**Unit 10: Taking the Metro** — *Buying tickets and entering the metro*

**Conversation:**

A: Where do I buy a metro ticket?

B: At the ticket \_\_\_\_\_\_\_\_\_\_ over there.

A: How much is the fare?

B: It's five pesos per ride.

**Answer:** window

**Question 21**

**Unit 11: Taking the Bus** — *Finding the bus stop and correct bus number*

**Conversation:**

A: Excuse me, which bus goes to the museum?

B: Take bus \_\_\_\_\_\_\_\_\_\_ 7.

A: Where is the bus stop?

B: It's across the street, in front of the bank.

**Answer:** number

**Question 22**

**Unit 11: Taking the Bus** — *Paying the fare and knowing when to get off*

**Conversation:**

A: How do I pay on the Metrobús?

B: You need to use your transit card.

A: How many \_\_\_\_\_\_\_\_\_\_ until the monument?

B: It's three stops from here.

**Answer:** stops

**Question 23**

**Unit 12: Putting It Together** — *Combining walking and transit options*

**Conversation:**

A: What's the best way to get to the airport from here?

B: The metro is \_\_\_\_\_\_\_\_\_\_ than walking or taking a bus.

A: Okay. Do I walk to the station first?

B: Yes, walk two blocks, then take Line 5.

**Answer:** faster

**Question 24**

**Unit 12: Putting It Together** — *Handling a service disruption / alternative route*

**Conversation:**

A: Is the metro line working today?

B: No, that line is \_\_\_\_\_\_\_\_\_\_ for construction.

A: Oh no! What do you recommend instead?

B: I recommend taking the Metrobús instead.

**Answer:** closed

**Question 25**

**Unit 13: The Body** — *Identifying location of pain or injury*

**Conversation:**

A: Are you okay, sir?

B: No, I fell down and \_\_\_\_\_\_\_\_\_\_ myself.

A: Where does it hurt?

B: My right leg and knee hurt.

**Answer:** hurt

**Question 26**

**Unit 13: The Body** — *Specifying head / face injuries*

**Conversation:**

A: What happened to your face?

B: A ball hit me while I was walking.

A: Did it hit your eye or \_\_\_\_\_\_\_\_\_\_?

B: It hit my forehead, right above my eyebrow.

**Answer:** forehead

**Question 27**

**Unit 14: Common Health Problems** — *Asking about symptoms and calling for help*

**Conversation:**

A: You look unwell, ma'am. What's wrong?

B: I feel very dizzy and \_\_\_\_\_\_\_\_\_\_?

A: Do you need an ambulance?

B: Yes, please. I don't think I can stand.

**Answer:** nauseous

**Question 28**

**Unit 14: Common Health Problems** — *Dealing with minor injuries and offering care*

**Conversation:**

A: Ouch! I cut my hand on some broken glass.

B: Let me see. Is it \_\_\_\_\_\_\_\_\_\_ a lot?

A: A little bit, but it burns.

B: Stay calm. Let's get some basic first aid.

**Answer:** bleeding

**Question 29**

**Unit 15: Parts of a Home** — *Identifying access points and residents*

**Conversation:**

A: Excuse me, Officer. We heard a loud noise.

B: Is anyone \_\_\_\_\_\_\_\_\_\_ the house?

A: My elderly mother is in the living room.

B: Is the front door unlocked?

**Answer:** inside

**Question 30**

**Unit 15: Parts of a Home** — *Checking home safety features*

**Conversation:**

A: Officer, I smell smoke coming from next door.

B: Did you hear a smoke detector \_\_\_\_\_\_\_\_\_\_?

A: Yes, the alarm is ringing loudly!

B: Please stay outside. We will check the property.

**Answer:** alarm

**Question 31**

**Unit 16: Responding at a Home** — *Arriving at a home after a call*

**Conversation:**

A: Hello, Officer! Thank you for coming so fast.

B: We got a call about a noise complaint. Is everyone \_\_\_\_\_\_\_\_\_\_?

A: Yes, we were just having a disagreement, but it's fine now.

B: Please keep the noise down so your neighbors can sleep.

**Answer:** alright

**Question 32**

**Unit 16: Responding at a Home** — *Securing a scene and instructing occupants*

**Conversation:**

A: Someone tried to break into my back door!

B: Is the person still inside or \_\_\_\_\_\_\_\_\_\_?

A: No, they ran away down the street.

B: Please stay right here and don't touch the door handle.

**Answer:** nearby

**Question 33**

**Unit 17: Staying Safe in the City** — *Giving pickpocket warnings in crowded areas*

**Conversation:**

A: Is this market area safe for tourists?

B: It's generally fine, but it gets very \_\_\_\_\_\_\_\_\_\_?

A: Should I be careful with my belongings?

B: Yes, keep your phone close and hold your bag in front.

**Answer:** crowded

**Question 34**

**Unit 17: Staying Safe in the City** — *Advising on night travel and taxi safety*

**Conversation:**

A: What is the safest way to get back to my hotel at night?

B: Avoid dark, empty streets and don't walk \_\_\_\_\_\_\_\_\_\_?

A: Should I take a street taxi or an app taxi?

B: Use a licensed taxi or an app-based ride.

**Answer:** alone

**Question 35**

**Unit 18: Putting It Together** — *Managing an emergency scene with injury*

**Conversation:**

A: Help! My friend tripped and twisted her \_\_\_\_\_\_\_\_\_\_!

B: Don't panic. Are you able to walk, ma'am?

C: No, it hurts too much to put weight on it.

B: Sit down here. I'll call medical assistance for you.

**Answer:** ankle

**Question 36**

**Unit 18: Putting It Together** — *Combining home safety check and reassurance*

**Conversation:**

A: Officer, is my house safe to enter now after the alarm?

B: Yes, we checked all the rooms and \_\_\_\_\_\_\_\_\_\_ . Everything is clear.

A: Thank you so much for your quick help!

B: You're very welcome. You're safe now. Call us if you need anything.

**Answer:** windows

**Question 37**

**Unit 19: Lost & Stolen Items** — *Reporting a lost or stolen wallet/bag*

**Conversation:**

A: Excuse me, Officer. Someone \_\_\_\_\_\_\_\_\_\_ my purse!

B: I'm sorry to hear that. Where were you when it happened?

A: I was sitting at a café table about ten minutes ago.

B: Can you describe what the purse looks like?

**Answer:** stole

**Question 38**

**Unit 19: Lost & Stolen Items** — *Taking down details and providing a case reference*

**Conversation:**

A: I left my backpack on the bench and now it's gone.

B: Okay, I'll file a \_\_\_\_\_\_\_\_\_\_ for you right now.

A: Will I get a reference number for my insurance?

B: Yes, here is your case reference number.

**Answer:** report

**Question 39**

**Unit 20: Missing Persons & Descriptions** — *Reporting a missing child/companion*

**Conversation:**

A: Officer, I can't find my young son! He was right \_\_\_\_\_\_\_\_\_\_ me!

B: Stay calm, ma'am. We'll start searching right away.

A: Oh thank goodness! Please help me find him!

B: What is his name and what was he wearing?

**Answer:** behind

**Question 40**

**Unit 20: Missing Persons & Descriptions** — *Gathering physical description details*

**Conversation:**

A: My friend got separated from our tour group.

B: Can you describe what he looks \_\_\_\_\_\_\_\_\_\_?

A: He's tall, has short curly brown hair, and wears glasses.

B: Thank you. Do you have a recent photo of him?

**Answer:** like

**Question 41**

**Unit 21: Taxi & Transport Scams** — *Reporting a taxi overcharging scam*

**Conversation:**

A: Excuse me, Officer. This taxi driver just charged me $50 for a five-minute ride!

B: Did he use the \_\_\_\_\_\_\_\_\_\_ during the trip?

A: No, he refused to turn on the meter.

B: Do you have the license plate number or a receipt?

**Answer:** meter

**Question 42**

**Unit 21: Taxi & Transport Scams** — *Taking a taxi report and prevention advice*

**Conversation:**

A: The driver took a very long route and demanded extra cash.

B: I understand your frustration. Let's write \_\_\_\_\_\_\_\_\_\_ the details.

A: Here is a photo I took of his license plate.

B: Great job. I will file an official report with this information.

**Answer:** down

**Question 43**

**Unit 22: Restaurant, Bar & Card Scams** — *Reporting an inflated bill or double charge*

**Conversation:**

A: Officer, this restaurant charged my credit card twice for dinner!

B: Did you speak to the manager about the double charge?

A: Yes, but they refused to give me an itemized \_\_\_\_\_\_\_\_\_\_?

B: Let's see your card statement and go speak with them.

**Answer:** receipt

**Question 44**

**Unit 22: Restaurant, Bar & Card Scams** — *Advising victim of card scam on next steps*

**Conversation:**

A: They added a huge extra service charge that wasn't on the menu.

B: I'm taking note of this incident for our report.

A: What should I do about the charge on my card?

B: Contact your bank \_\_\_\_\_\_\_\_\_\_ to dispute the charge.

**Answer:** immediately

**Question 45**

**Unit 23: Taking a Report** — *Opening a report and gathering personal details*

**Conversation:**

A: Hello Officer, I need to report a \_\_\_\_\_\_\_\_\_\_ phone.

B: Of course. Can I get your full name and local address?

A: My name is John Smith, staying at Hotel Alameda.

B: Thank you. What is your phone number or email?

**Answer:** stolen

**Question 46**

**Unit 23: Taking a Report** — *Finalizing a report and giving instructions*

**Conversation:**

A: I've given you all the details of the incident.

B: Perfect. Please read this summary to make sure it's \_\_\_\_\_\_\_\_\_\_?

A: Everything looks accurate.

B: Please sign here, and keep this copy for your records.

**Answer:** correct

**Question 47**

**Unit 24: Putting It Together** — *Handling a complex lost item & scam report*

**Conversation:**

A: Officer, my backpack with my passport was taken from a taxi!

B: Don't worry, we'll help you file a full report right now.

A: I'm so worried about my passport and \_\_\_\_\_\_\_\_\_\_ plans.

B: We'll do our best to help, and you can contact your embassy with this report.

**Answer:** travel

**Question 48**

**Unit 24: Putting It Together** — *Reassuring a tourist after resolving an incident*

**Conversation:**

A: Thank you for helping me resolve the issue with the restaurant bill.

B: You're very welcome. Here is your copy of the incident report.

A: I really \_\_\_\_\_\_\_\_\_\_ your patience and help today.

B: It was my pleasure. Enjoy the rest of your visit to Mexico City!

**Answer:** appreciate