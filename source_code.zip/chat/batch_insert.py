#!/usr/bin/env python3
"""Batch insert all questions via edgespark CLI."""
import json, subprocess, time

sqls = json.load(open('chat/insert_statements.json'))
print(f"Total statements: {len(sqls)}")

BATCH_SIZE = 25
total_inserted = 0

for i in range(0, len(sqls), BATCH_SIZE):
    batch = sqls[i:i+BATCH_SIZE]
    batch_sql = "; ".join(batch)
    batch_num = i // BATCH_SIZE + 1
    total_batches = (len(sqls) + BATCH_SIZE - 1) // BATCH_SIZE
    
    result = subprocess.run(
        ['npx', 'edgespark', 'db', 'sql', batch_sql],
        capture_output=True, text=True, timeout=60
    )
    
    if result.returncode == 0:
        total_inserted += len(batch)
        print(f"Batch {batch_num}/{total_batches}: inserted {len(batch)} (total: {total_inserted})")
    else:
        print(f"Batch {batch_num}/{total_batches}: FAILED")
        print(f"  stderr: {result.stderr[:200]}")
        # Try one by one for failed batch
        for j, stmt in enumerate(batch):
            r = subprocess.run(
                ['npx', 'edgespark', 'db', 'sql', stmt],
                capture_output=True, text=True, timeout=30
            )
            if r.returncode == 0:
                total_inserted += 1
                print(f"  Individual {i+j+1}: OK")
            else:
                print(f"  Individual {i+j+1}: FAILED - {r.stderr[:100]}")

print(f"\nDone! Total inserted: {total_inserted}/{len(sqls)}")
