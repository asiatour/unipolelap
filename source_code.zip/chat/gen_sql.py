#!/usr/bin/env python3
"""Generate SQL INSERT statements for all 240 questions."""
import re

def read_file(path):
    with open(path) as f:
        return f.read()

def parse_import(text):
    """Parse admin-import format keeping FULL dialogues:
    N. first dialogue line / continuation lines / A) options / Answer: X
    """
    questions = []
    current = None
    for line in text.split('\n'):
        line = line.strip()
        if not line:
            continue
        qm = re.match(r'^(\d+)\.\s*(.*)', line)
        om = re.match(r'^([A-Da-d])\)\s*(.*)', line)
        am = re.match(r'^Answer:\s*(.*)', line)
        if qm and not om:
            if current:
                questions.append(current)
            current = {'text': [qm.group(2)], 'a': '', 'b': '', 'c': '', 'd': '', 'ans': ''}
            continue
        if current is None:
            continue
        if om:
            current[om.group(1).lower()] = om.group(2).strip()
            continue
        if am:
            ans = am.group(1).strip()
            # MCQ answers are single letters; typing answers are full words
            current['ans'] = ans.upper() if re.fullmatch(r'[A-Da-d]', ans) else ans
            continue
        # Dialogue speaker lines ("A: ...", "B: ...") belong to the full text
        current['text'].append(line)
    if current:
        questions.append(current)
    for q in questions:
        # Normalize escaped (\\_\\_) or plain underscore runs into a visible blank
        q['text'] = re.sub(r'(?:\\_|_){3,}', '__________', '\n'.join(q['text']))
    return questions

def esc(s):
    return s.replace("'", "''")

type1 = parse_import(read_file('chat/import_type1_vocabulary.txt'))
type2 = parse_import(read_file('chat/import_type2_grammar.txt'))
type3 = parse_import(read_file('chat/import_type3_reading.txt'))
type4 = parse_import(read_file('chat/import_type4_fillblank.txt'))

print(f'Type 1: {len(type1)}, Type 2: {len(type2)}, Type 3: {len(type3)}, Type 4: {len(type4)}')

sqls = []

for i, q in enumerate(type1):
    diff = (i % 10) + 1
    sqls.append(f"INSERT INTO questions (question_type, difficulty_order, question_text, option_a, option_b, option_c, option_d, correct_answer) VALUES (1, {diff}, '{esc(q['text'])}', '{esc(q['a'])}', '{esc(q['b'])}', '{esc(q['c'])}', '{esc(q['d'])}', '{esc(q['ans'])}')")

for i, q in enumerate(type2):
    diff = (i % 10) + 1
    sqls.append(f"INSERT INTO questions (question_type, difficulty_order, question_text, option_a, option_b, option_c, option_d, correct_answer) VALUES (2, {diff}, '{esc(q['text'])}', '{esc(q['a'])}', '{esc(q['b'])}', '{esc(q['c'])}', '{esc(q['d'])}', '{esc(q['ans'])}')")

for i, q in enumerate(type3):
    diff = (i % 10) + 1
    sqls.append(f"INSERT INTO questions (question_type, difficulty_order, question_text, option_a, option_b, option_c, option_d, correct_answer) VALUES (3, {diff}, '{esc(q['text'])}', '{esc(q['a'])}', '{esc(q['b'])}', '{esc(q['c'])}', '{esc(q['d'])}', '{esc(q['ans'])}')")

for i, q in enumerate(type4):
    diff = (i % 10) + 1
    sqls.append(f"INSERT INTO questions (question_type, difficulty_order, question_text, option_a, option_b, option_c, option_d, correct_answer) VALUES (4, {diff}, '{esc(q['text'])}', NULL, NULL, NULL, NULL, '{esc(q['ans'])}')")

print(f'Total SQL statements: {len(sqls)}')

# Write each SQL to a separate line in a JSON array for easy processing
import json
with open('chat/insert_statements.json', 'w') as f:
    json.dump(sqls, f)

print('Written to chat/insert_statements.json')
for s in sqls[:2]:
    print(s[:150] + '...')
