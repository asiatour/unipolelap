#!/usr/bin/env python3
"""Report-only: compare DB options/answers (types 2-4) against the verified
import files. Prints drift rows per type. Modifies nothing.

Note: uses OR-chain comparisons (not CTE VALUES) because the edgespark CLI
backend silently returns empty results for `WITH ... AS (VALUES ...)`.
"""
import sys

sys.path.insert(0, "chat")
from fix_full_dialogues import FILES, ID_RANGES, parse_import, esc, run_sql

BATCH = 12

for qtype, path in FILES.items():
    qs = parse_import(path)
    start, _ = ID_RANGES[qtype]
    mismatched = []
    for i in range(0, len(qs), BATCH):
        conds = []
        for j, q in enumerate(qs[i : i + BATCH]):
            qid = start + i + j
            if qtype == 4:
                conds.append(f"(id = {qid} AND (correct_answer IS NOT '{esc(q['ans'])}'))")
            else:
                conds.append(
                    f"(id = {qid} AND (option_a IS NOT '{esc(q['a'])}' "
                    f"OR option_b IS NOT '{esc(q['b'])}' "
                    f"OR option_c IS NOT '{esc(q['c'])}' "
                    f"OR option_d IS NOT '{esc(q['d'])}' "
                    f"OR correct_answer IS NOT '{esc(q['ans'])}'))"
                )
        r = run_sql("SELECT id FROM questions WHERE " + " OR ".join(conds) + " ORDER BY id")
        if r.returncode != 0:
            print(f"Type {qtype} batch {i//BATCH+1} FAILED: {r.stderr[:200]}")
            continue
        for line in r.stdout.splitlines():
            # table rows look like: │ 0       │ 143 │ — id is the last numeric cell
            cells = [c.strip().strip("'\"") for c in line.split("│") if c.strip()]
            numeric = [c for c in cells if c.isdigit()]
            if len(numeric) == 2 and "(" not in line and "index" not in line:
                mismatched.append(int(numeric[-1]))
    print(f"Type {qtype} drift vs verified files: {mismatched if mismatched else 'none'}")
    if mismatched:
        detail = run_sql(
            "SELECT id, option_a, option_b, option_c, option_d, correct_answer "
            f"FROM questions WHERE id IN ({','.join(str(x) for x in mismatched)}) ORDER BY id"
        )
        print(detail.stdout.strip())
        for qid in mismatched:
            if not (start <= qid < start + len(qs)):
                continue
            q = qs[qid - start]
            print(
                f"  file id {qid}: A={q['a']!r} B={q['b']!r} C={q['c']!r} "
                f"D={q['d']!r} ans={q['ans']!r}"
            )
