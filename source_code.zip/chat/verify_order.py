#!/usr/bin/env python3
"""Verification only: call the deployed start-test endpoint with a throwaway
student ID and print the presentation order (type -> difficulty sequence).
The created test_attempt row is deleted afterwards via SQL."""
import json
import urllib.request

URL = "https://staging--vp5tdlcfjg7l98fiuarx.youbase.cloud/api/public/start-test"
STUDENT = "9999999"

req = urllib.request.Request(
    URL,
    data=json.dumps({"studentId": STUDENT}).encode(),
    headers={
        "Content-Type": "application/json",
        # Cloudflare blocks non-browser UAs on the staging worker (error 1010)
        "User-Agent": (
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
        ),
        "Accept": "application/json",
    },
    method="POST",
)
try:
    with urllib.request.urlopen(req, timeout=30) as res:
        body = json.load(res)
except urllib.error.HTTPError as e:
    print("HTTP", e.code)
    print(e.read().decode(errors="replace")[:500])
    raise SystemExit(1)

if body.get("error"):
    print("API error:", body["error"])
    raise SystemExit(1)

attempt_id = body.get("attemptId")
print("attemptId:", attempt_id)

questions = body.get("questions", {})
for qtype in sorted(questions, key=int):
    seq = [q["difficultyOrder"] for q in questions[qtype]]
    ids = [q["id"] for q in questions[qtype]]
    ordered = all(seq[i] <= seq[i + 1] for i in range(len(seq) - 1))
    print(f"type {qtype}: ordered={ordered} difficulties={seq}")
    print(f"          ids={ids}")

print("\nNOTE: delete the test attempt afterwards:")
print(f"  DELETE FROM test_attempts WHERE student_id = '{STUDENT}';")
