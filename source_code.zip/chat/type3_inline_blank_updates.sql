UPDATE questions SET question_text = CASE id
  WHEN 191 THEN 'A: Good morning, sir!
B: Good morning. My name is Mark. What''s your name?
A: I''m Officer López. Nice to meet you.
B: Nice to __________ you, too.'
  WHEN 192 THEN 'A: Hello! How are you doing today?
B: I''m doing well, thank you. And you?
A: Pretty good, thanks. Welcome to Mexico City!
B: Thank you __________ much!'
  WHEN 193 THEN 'A: Excuse me, Officer. Do you have the time?
B: Yes, let me check. It''s 10:15.
A: Perfect. What time does the museum open?
B: It opens __________ 11:00.'
  WHEN 194 THEN 'A: Is today Tuesday or Wednesday?
B: Today is Tuesday, October 14th.
A: Great. Can I give you my phone number?
B: Yes, go __________.'
  WHEN 195 THEN 'A: Where is the bus stop to go directly to the airport?
B: I''m sorry, can you speak slowly, please?
A: Sure! Where is the bus stop for the airport?
B: Ah, I __________ now. It''s on the corner.'
  WHEN 196 THEN 'A: My last name is Szczepanski.
B: Could you spell that for me, please?
A: Yes, S-Z-C-Z-E-P-A-N-S-K-I.
B: Thank you, let me __________ that.'
  WHEN 197 THEN 'A: Where are you visiting from?
B: I''m from Canada.
A: Welcome! How long are you staying in Mexico City?
B: I''m staying __________ one week.'
  WHEN 198 THEN 'A: Are you here on vacation or for work?
B: I''m here for work. I have a conference.
A: What''s your job?
B: I''m an __________.'
  WHEN 199 THEN 'A: Excuse me, Officer. You look like you can help.
B: Can I help you, ma''am?
A: Yes, I''m looking for the tourist information booth.
B: __________ me, please. It''s right over here.'
  WHEN 200 THEN 'A: Can you help me find my group?
B: Of course. First, show me your identification, please.
A: Here is my passport.
B: Thank you. One __________, please.'
  WHEN 201 THEN 'A: It''s a very sunny and warm day today!
B: Yes, it is! Are you enjoying your trip?
A: Yes, Mexico City is beautiful.
B: I''m happy to __________ that!'
  WHEN 202 THEN 'A: Thank you for all your help, Officer!
B: You''re very welcome. Do you need anything else?
A: No, that''s everything. Have a good day!
B: Thanks! Enjoy the __________ of your day!'
  WHEN 203 THEN 'A: Excuse me, is there an ATM near here?
B: Yes, there is one inside the shopping center.
A: Is it far from this park?
B: No, it''s very __________.'
  WHEN 204 THEN 'A: Excuse me, how do I get to the Zócalo?
B: The main plaza? You can walk straight down this avenue.
A: Is the cathedral next to it?
B: Yes, the cathedral is __________ on the Zócalo.'
  WHEN 205 THEN 'A: Where is the national museum located?
B: It''s across from the big fountain in the park.
A: Is it next to the coffee shop?
B: Yes, it''s right __________ the coffee shop and the bookstore.'
  WHEN 206 THEN 'A: Excuse me, where is the bathroom in this building?
B: It''s on the second floor, next to the stairs.
A: Is there an elevator?
B: Yes, the elevator is __________ your left.'
  WHEN 207 THEN 'A: How do I walk to the Palace of Fine Arts?
B: Go straight for two blocks, then turn left at the traffic light.
A: Turn left at the traffic light?
B: Yes, __________. It''s right on the corner.'
  WHEN 208 THEN 'A: Is it a long walk to the market?
B: No, it''s a short walk—about five minutes.
A: Okay, great. Do I cross the avenue?
B: Yes, __________ the street and you''ll see it.'
  WHEN 209 THEN 'A: Which metro line goes to Chapultepec?
B: You need Line 1, the pink line.
A: Which direction do I take?
B: Take Line 1 __________ Observatorio.'
  WHEN 210 THEN 'A: Where do I buy a metro ticket?
B: At the ticket window over there.
A: How much is the fare?
B: It''s five pesos __________ ride.'
  WHEN 211 THEN 'A: Excuse me, which bus goes to the museum?
B: Take bus number 7.
A: Where is the bus stop?
B: It''s across the street, in __________ of the bank.'
  WHEN 212 THEN 'A: How do I pay on the Metrobús?
B: You need to use your transit card.
A: How many stops until the monument?
B: It''s three stops __________ here.'
  WHEN 213 THEN 'A: What''s the best way to get to the airport from here?
B: The metro is faster than walking or taking a bus.
A: Okay. Do I walk to the station first?
B: Yes, walk two blocks, __________ take Line 5.'
  WHEN 214 THEN 'A: Is the metro line working today?
B: No, that line is closed for construction.
A: Oh no! What do you recommend instead?
B: I recommend __________ the Metrobús instead.'
  WHEN 215 THEN 'A: Are you okay, sir?
B: No, I fell down and hurt myself.
A: Where does it hurt?
B: My __________ leg and knee hurt.'
  WHEN 216 THEN 'A: What happened to your face?
B: A ball hit me while I was walking.
A: Did it hit your eye or forehead?
B: It hit my forehead, right __________ my eyebrow.'
  WHEN 217 THEN 'A: You look unwell, ma''am. What''s wrong?
B: I feel very dizzy and nauseous.
A: Do you need an ambulance?
B: Yes, please. I don''t __________ I can stand.'
  WHEN 218 THEN 'A: Ouch! I cut my hand on some broken glass.
B: Let me see. Is it bleeding a lot?
A: A little bit, but it burns.
B: Stay __________. Let''s get some basic first aid.'
  WHEN 219 THEN 'A: Excuse me, Officer. We heard a loud noise.
B: Is anyone inside the house?
A: My elderly mother is in the living room.
B: Is the __________ door unlocked?'
  WHEN 220 THEN 'A: Officer, I smell smoke coming from next door.
B: Did you hear a smoke detector alarm?
A: Yes, the alarm is ringing loudly!
B: Please stay __________. We will check the property.'
  WHEN 221 THEN 'A: Hello, Officer! Thank you for coming so fast.
B: We got a call about a noise complaint. Is everyone alright?
A: Yes, we were just having a disagreement, but it''s fine now.
B: Please keep the noise __________ so your neighbors can sleep.'
  WHEN 222 THEN 'A: Someone tried to break into my back door!
B: Is the person still inside or nearby?
A: No, they ran away down the street.
B: Please stay right here and don''t __________ the door handle.'
  WHEN 223 THEN 'A: Is this market area safe for tourists?
B: It''s generally fine, but it gets very crowded.
A: Should I be careful with my belongings?
B: Yes, keep your phone close and hold your bag in __________.'
  WHEN 224 THEN 'A: What is the safest way to get back to my hotel at night?
B: Avoid dark, empty streets and don''t walk alone.
A: Should I take a street taxi or an app taxi?
B: Use a __________ taxi or an app-based ride.'
  WHEN 225 THEN 'A: Help! My friend tripped and twisted her ankle!
B: Don''t panic. Are you able to walk, ma''am?
B: Sit down here. I''ll call __________ assistance for you.'
  WHEN 226 THEN 'A: Officer, is my house safe to enter now after the alarm?
B: Yes, we checked all the rooms and windows. Everything is clear.
A: Thank you so much for your quick help!
B: You''re very welcome. You''re safe now. Call us if you __________ anything.'
  WHEN 227 THEN 'A: Excuse me, Officer. Someone stole my purse!
B: I''m sorry to hear that. Where were you when it happened?
A: I was sitting at a café table about ten minutes ago.
B: Can you __________ what the purse looks like?'
  WHEN 228 THEN 'A: I left my backpack on the bench and now it''s gone.
B: Okay, I''ll file a report for you right now.
A: Will I get a reference number for my insurance?
B: Yes, here is your case reference __________.'
  WHEN 229 THEN 'A: Officer, I can''t find my young son! He was right behind me!
B: Stay calm, ma''am. We''ll start searching right away.
A: Oh thank goodness! Please help me find him!
B: What is his name and what was he __________?'
  WHEN 230 THEN 'A: My friend got separated from our tour group.
B: Can you describe what he looks like?
A: He''s tall, has short curly brown hair, and wears glasses.
B: Thank you. Do you have a __________ photo of him?'
  WHEN 231 THEN 'A: Excuse me, Officer. This taxi driver just charged me $50 for a five-minute ride!
B: Did he use the meter during the trip?
A: No, he refused to turn on the meter.
B: Do you have the license __________ number or a receipt?'
  WHEN 232 THEN 'A: The driver took a very long route and demanded extra cash.
B: I understand your frustration. Let''s write down the details.
A: Here is a photo I took of his license plate.
B: Great job. I will file an __________ report with this information.'
  WHEN 233 THEN 'A: Officer, this restaurant charged my credit card twice for dinner!
B: Did you speak to the manager about the double charge?
A: Yes, but they refused to give me an itemized receipt.
B: Let''s see your card __________ and go speak with them.'
  WHEN 234 THEN 'A: They added a huge extra service charge that wasn''t on the menu.
B: I''m taking note of this incident for our report.
A: What should I do about the charge on my card?
B: Contact your bank immediately to __________ the charge.'
  WHEN 235 THEN 'A: Hello Officer, I need to report a stolen phone.
B: Of course. Can I get your full name and local address?
A: My name is John Smith, staying at Hotel Alameda.
B: Thank you. What is your phone number __________ email?'
  WHEN 236 THEN 'A: I''ve given you all the details of the incident.
B: Perfect. Please read this summary to make sure it''s correct.
A: Everything looks accurate.
B: Please sign here, and keep this copy for your __________.'
  WHEN 237 THEN 'A: Officer, my backpack with my passport was taken from a taxi!
B: Don''t worry, we''ll help you file a full report right now.
A: I''m so worried about my passport and travel plans.
B: We''ll do our best to help, and you can contact your __________ with this report.'
  WHEN 238 THEN 'A: Thank you for helping me resolve the issue with the restaurant bill.
B: You''re very welcome. Here is your copy of the incident report.
A: I really appreciate your patience and help today.
B: It was my __________. Enjoy the rest of your visit to Mexico City!'
END
WHERE question_type = 3 AND id BETWEEN 191 AND 238;
