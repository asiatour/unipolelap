#!/usr/bin/env python3
"""Rebuild type-3 question_text with the inline blank restored.

The original pipeline (format_questions.py) collapsed any dialogue line that
contained a blank marker into "Speaker: __________", which removed all context
words from the question. The official docx (questions_raw.md, Part 2:
Single-Word Completion) keeps the blank inline: only the correct answer's word
is missing, the rest of the line stays visible, e.g.

    B: Nice to __________ you, too.

This script re-parses Part 2 from questions_raw.md, rebuilds question_text for
the 48 type-3 questions (DB ids 191-238, insertion order == docx order),
verifies options/answers against the verified import file, and emits a single
CASE-based UPDATE statement for the D1 database.

Usage:
    python3 chat/rebuild_type3_inline_blanks.py            # report + SQL to stdout
    python3 chat/rebuild_type3_inline_blanks.py --sql-only # just the UPDATE
    python3 chat/rebuild_type3_inline_blanks.py --write-import
        # also rewrite chat/import_type3_reading.txt in the inline-blank
        # format so future admin bulk imports keep the context words
"""
import json
import re
import sys

MD_PATH = "chat/questions_raw.md"
IMPORT_PATH = "chat/import_type3_reading.txt"
PART2_START = "**Multiple Choice Questions (Part 2: Single-Word Completion)**"
PART3_START = "**Multiple Choice Questions (Part 3: Conversation Completion)**"
BLANK = "__________"
ID_BASE = 190  # type-3 ids start at 191 = ID_BASE + 1


def clean_blanks(text: str) -> str:
    """Normalize escaped (\\_\\_) or plain underscore runs into one visible blank."""
    return re.sub(r"(?:\\_|_){3,}", BLANK, text)


def parse_docx_part2():
    """Parse the 48 Part-2 questions from questions_raw.md."""
    with open(MD_PATH, encoding="utf-8") as f:
        text = f.read()
    s1 = text.find(PART2_START)
    s2 = text.find(PART3_START)
    if s1 == -1 or s2 == -1:
        raise SystemExit("Part 2 section markers not found in questions_raw.md")
    section = text[s1:s2]

    questions = []
    current = None
    for raw in section.split("\n"):
        line = raw.strip()
        if not line:
            continue
        qm = re.match(r"^\*\*Question\s+(\d+)\*\*$", line)
        if qm:
            if current:
                questions.append(current)
            current = {"num": int(qm.group(1)), "lines": [], "options": {}, "answer": ""}
            continue
        if current is None:
            continue
        om = re.match(r"^\*\s+([A-Da-d])\)\s*(.*)$", line)
        if om:
            current["options"][om.group(1).upper()] = om.group(2).strip()
            continue
        am = re.match(r"^\*\*Correct Answer:\*\*\s*([A-Da-d])", line)
        if am:
            current["answer"] = am.group(1).upper()
            continue
        if line.startswith("**") or line.startswith("Below are"):
            continue
        cm = re.match(r"^([AB]):\s*(.*)$", line)
        if cm:
            current["lines"].append(f"{cm.group(1)}: {clean_blanks(cm.group(2).strip())}")
    if current:
        questions.append(current)
    return questions


def parse_import_file():
    """Parse the verified admin import file (current DB source of truth)."""
    questions = []
    current = None
    with open(IMPORT_PATH, encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            qm = re.match(r"^(\d+)\.\s*(.*)$", line)
            om = re.match(r"^([A-Da-d])\)\s*(.*)$", line)
            am = re.match(r"^Answer:\s*(.*)$", line)
            if qm and not om:
                if current:
                    questions.append(current)
                current = {"num": int(qm.group(1)), "lines": [qm.group(2)], "options": {}, "answer": ""}
                continue
            if current is None:
                continue
            if om:
                current["options"][om.group(1).upper()] = om.group(2).strip()
            elif am:
                current["answer"] = am.group(1).strip().upper()
            else:
                current["lines"].append(line)
    if current:
        questions.append(current)
    return questions


def sql_escape(s: str) -> str:
    return s.replace("'", "''")


def main():
    docx_qs = parse_docx_part2()
    import_qs = parse_import_file()
    sql_only = "--sql-only" in sys.argv

    if len(docx_qs) != 48:
        raise SystemExit(f"Expected 48 Part-2 questions, parsed {len(docx_qs)}")
    if len(import_qs) != 48:
        raise SystemExit(f"Expected 48 import questions, parsed {len(import_qs)}")

    problems = []
    case_parts = []
    for dq, iq in zip(docx_qs, import_qs):
        qid = ID_BASE + dq["num"]
        text = "\n".join(dq["lines"])

        # --- consistency checks -------------------------------------------
        if dq["num"] != iq["num"]:
            problems.append(f"Q{dq['num']}: import file numbering drift ({iq['num']})")
        if dq["options"] != iq["options"]:
            problems.append(f"Q{dq['num']}: options drift docx={dq['options']} import={iq['options']}")
        if dq["answer"] != iq["answer"]:
            problems.append(f"Q{dq['num']}: answer drift docx={dq['answer']} import={iq['answer']}")

        blanked = [ln for ln in dq["lines"] if BLANK in ln]
        if len(blanked) != 1:
            problems.append(f"Q{dq['num']}: expected exactly 1 blanked line, got {len(blanked)}")
        elif not blanked[0].startswith("B:"):
            problems.append(f"Q{dq['num']}: blanked line is not a B: line -> {blanked[0]!r}")

        # The collapsed import line must be the same speaker line
        import_blanked = [ln for ln in iq["lines"] if BLANK in ln]
        if blanked and import_blanked:
            if blanked[0].split(":")[0] != import_blanked[0].split(":")[0]:
                problems.append(f"Q{dq['num']}: blanked speaker mismatch")

        correct_word = dq["options"].get(dq["answer"], "")
        case_parts.append(f"  WHEN {qid} THEN '{sql_escape(text)}'")

        if not sql_only:
            print(f"--- id {qid} (Q{dq['num']}) answer={dq['answer']} ({correct_word!r})")
            for ln in dq["lines"]:
                print(f"    {ln}")

    print("\n=== Verification ===", file=sys.stderr)
    if problems:
        print(f"{len(problems)} PROBLEM(S):", file=sys.stderr)
        for p in problems:
            print(f"  ! {p}", file=sys.stderr)
        raise SystemExit("Aborting: fix drift before updating the DB")
    print("All 48 questions: options/answers match the import file; "
          "each has exactly one inline blank on a B: line.", file=sys.stderr)

    sql = ("UPDATE questions SET question_text = CASE id\n"
           + "\n".join(case_parts)
           + f"\nEND\nWHERE question_type = 3 AND id BETWEEN {ID_BASE + 1} AND {ID_BASE + 48};")
    print("\n=== UPDATE SQL ===")
    print(sql)

    with open("chat/type3_inline_blank_updates.sql", "w", encoding="utf-8") as f:
        f.write(sql + "\n")
    print("\nSQL also written to chat/type3_inline_blank_updates.sql", file=sys.stderr)

    if "--write-import" in sys.argv:
        out_lines = []
        for q in docx_qs:
            out_lines.append(f"{q['num']}. " + "\n".join(q["lines"]))
            for letter in ["A", "B", "C", "D"]:
                if letter in q["options"]:
                    out_lines.append(f"{letter}) {q['options'][letter]}")
            out_lines.append(f"Answer: {q['answer']}")
            out_lines.append("")
        with open(IMPORT_PATH, "w", encoding="utf-8") as f:
            f.write("\n".join(out_lines))
        print(f"Rewrote {IMPORT_PATH} with inline blanks.", file=sys.stderr)


if __name__ == "__main__":
    main()
