#!/usr/bin/env python3
"""
Parse UNIPOL ELAP questions docx (markdown) → formatted import files.
Admin parser expects: 1. Question / A) Opt / Answer: X
"""

import re, json

def read_md():
    with open('chat/questions_raw.md', 'r') as f:
        return f.read()

def parse_answer_key(text):
    """Parse the answer key table."""
    answers = {}
    # Find the table after "Answer Key"
    ak_start = text.find('| **Question**')
    if ak_start == -1:
        return answers
    table_text = text[ak_start:]
    for line in table_text.split('\n'):
        line = line.strip()
        if not line.startswith('|') or line.startswith('| ---'):
            continue
        cells = [c.strip().replace('**', '') for c in line.split('|')[1:-1]]
        for i in range(0, len(cells), 2):
            if i + 1 < len(cells):
                qn = cells[i].strip()
                ans = cells[i + 1].strip()
                if qn.isdigit() and ans in ('A','B','C','D'):
                    answers[int(qn)] = ans
    return answers

def parse_part1_vocab(text):
    """Part 1: 96 Vocabulary MCQs (sections/units before Answer Key)."""
    # Get text from "Section 1" to "Answer Key"
    m1 = text.find('**Section 1: Being Friendly**')
    m2 = text.find('**Answer Key**')
    if m1 == -1 or m2 == -1:
        return []
    section = text[m1:m2]
    
    questions = []
    current = None
    
    for line in section.split('\n'):
        line = line.strip()
        if not line:
            continue
        
        # Question: "1. How do you say..."
        qm = re.match(r'^(\d+)\.\s+(.+)', line)
        if qm:
            if current:
                questions.append(current)
            current = {'questionText': qm.group(2), 'optionA':'', 'optionB':'', 'optionC':'', 'optionD':''}
            continue
        
        # Option: "* A) Good evening"
        om = re.match(r'^\*\s+([A-Da-d])\)\s+(.+)', line)
        if om and current:
            current[f'option{om.group(1).upper()}'] = om.group(2)
    
    if current:
        questions.append(current)
    return questions

def clean_blanks(text):
    """Normalize escaped (\\_\\_) or plain underscore runs into one visible blank."""
    return re.sub(r'(?:\\_|_){3,}', '__________', text)

def parse_conversation_mcqs(text, section_start_marker, section_end_marker):
    """Parse Part 2 or Part 3 conversation-based MCQs."""
    s1 = text.find(section_start_marker)
    s2 = text.find(section_end_marker) if section_end_marker else len(text)
    if s1 == -1:
        return []
    section = text[s1:s2]
    
    questions = []
    current = None
    conv_lines = []
    
    for line in section.split('\n'):
        line = line.strip()
        if not line:
            continue
        
        # Skip the header line and description
        if line.startswith('**Multiple Choice') or line.startswith('Below are'):
            continue
        
        # Question header: **Question N**
        qm = re.match(r'^\*\*Question\s+(\d+)\*\*', line)
        if qm:
            if current and conv_lines:
                current['questionText'] = '\n'.join(conv_lines)
                questions.append(current)
            current = {'questionText':'', 'optionA':'', 'optionB':'', 'optionC':'', 'optionD':'', '_correct':''}
            conv_lines = []
            continue
        
        if not current:
            continue
        
        # Unit header - skip
        if line.startswith('**Unit'):
            continue
        
        # Conversation header - skip
        if line == '**Conversation:**':
            continue
        
        # Options header
        if line == '**Options:**':
            continue
        
        # Correct Answer
        am = re.match(r'^\*\*Correct Answer:\*\*\s*([A-Da-d])', line)
        if am:
            current['_correct'] = am.group(1).upper()
            current['questionText'] = '\n'.join(conv_lines)
            continue
        
        # Option line: * A) text
        om = re.match(r'^\*\s+([A-Da-d])\)\s+(.+)', line)
        if om:
            current[f'option{om.group(1).upper()}'] = om.group(2)
            continue
        
        # Conversation content lines
        # Part 2 format: "A: text" or "B: text" (plain)
        # Part 3 format: "**A:** text" or "**B:** text" (bold)
        # Try bold first
        cm = re.match(r'^\*\*([AB]):\*\*\s*(.+)', line)
        if not cm:
            cm = re.match(r'^([AB]):\s*(.+)', line)
        if cm:
            speaker = cm.group(1)
            text_val = cm.group(2).strip()
            # Keep the blank inline so the surrounding context words stay
            # visible; only normalize the marker to a consistent run.
            conv_lines.append(f"{speaker}: {clean_blanks(text_val)}")
    
    # Don't forget last question
    if current and conv_lines:
        current['questionText'] = '\n'.join(conv_lines)
        questions.append(current)
    
    return questions

def parse_part4_typing(text):
    """Part 4: Fill-in-the-blank typing exercises."""
    s1 = text.find('**Fill-in-the-Blank Exercises')
    if s1 == -1:
        return []
    section = text[s1:]
    
    questions = []
    current = None
    conv_lines = []
    
    for line in section.split('\n'):
        line = line.strip()
        if not line:
            continue
        
        # Stop at next major section
        if line.startswith('**Answer Key**') or line.startswith('**Multiple Choice'):
            if current and conv_lines:
                current['questionText'] = '\n'.join(conv_lines)
                questions.append(current)
            break
        
        # Skip headers
        if line.startswith('**Fill-in-the-Blank') or line.startswith('**Instructions:**'):
            continue
        
        # Question header
        qm = re.match(r'^\*\*Question\s+(\d+)\*\*', line)
        if qm:
            if current and conv_lines:
                current['questionText'] = '\n'.join(conv_lines)
                questions.append(current)
            current = {'questionText':'', '_correct':''}
            conv_lines = []
            continue
        
        if not current:
            continue
        
        # Unit header - skip
        if line.startswith('**Unit'):
            continue
        
        # Conversation header - skip
        if line == '**Conversation:**':
            continue
        
        # Answer line
        am = re.match(r'^\*\*Answer:\*\*\s*(.+)', line)
        if am:
            current['_correct'] = am.group(1).strip()
            current['questionText'] = '\n'.join(conv_lines)
            continue
        
        # Conversation lines
        cm = re.match(r'^\*\*([AB]):\*\*\s*(.+)', line)
        if not cm:
            cm = re.match(r'^([AB]):\s*(.+)', line)
        if cm:
            speaker = cm.group(1)
            text_val = cm.group(2).strip()
            conv_lines.append(f"{speaker}: {text_val}")
    
    if current and conv_lines:
        current['questionText'] = '\n'.join(conv_lines)
        questions.append(current)
    
    return questions

def format_mcq_import(questions):
    """Format MCQ questions for admin import."""
    lines = []
    for i, q in enumerate(questions, 1):
        lines.append(f"{i}. {q['questionText']}")
        for letter in ['A', 'B', 'C', 'D']:
            opt = q.get(f'option{letter}', '')
            if opt:
                lines.append(f"{letter}) {opt}")
        lines.append(f"Answer: {q.get('_correct', 'A')}")
        lines.append("")
    return '\n'.join(lines)

def format_typing_import(questions):
    """Format fill-in-the-blank typing questions."""
    lines = []
    for i, q in enumerate(questions, 1):
        lines.append(f"{i}. {q['questionText']}")
        lines.append(f"Answer: {q.get('_correct', '')}")
        lines.append("")
    return '\n'.join(lines)

def main():
    text = read_md()
    
    # Parse all parts
    answer_key = parse_answer_key(text)
    print(f"Answer key: {len(answer_key)} answers")
    
    part1 = parse_part1_vocab(text)
    # Assign answers
    for i, q in enumerate(part1):
        if (i+1) in answer_key:
            q['_correct'] = answer_key[i+1]
    print(f"Part 1 (Vocabulary): {len(part1)} questions")
    
    part2 = parse_conversation_mcqs(text,
        '**Multiple Choice Questions (Part 2: Single-Word Completion)',
        '**Multiple Choice Questions (Part 3: Conversation Completion)')
    print(f"Part 2 (Single-Word Completion): {len(part2)} questions")
    
    part3 = parse_conversation_mcqs(text,
        '**Multiple Choice Questions (Part 3: Conversation Completion)',
        '**Fill-in-the-Blank Exercises')
    print(f"Part 3 (Conversation Completion): {len(part3)} questions")
    
    part4 = parse_part4_typing(text)
    print(f"Part 4 (Fill-in-the-Blank): {len(part4)} questions")
    
    # Write formatted files
    files = {
        'chat/import_type1_vocabulary.txt': format_mcq_import(part1),
        'chat/import_type2_grammar.txt': format_mcq_import(part3),
        'chat/import_type3_reading.txt': format_mcq_import(part2),
        'chat/import_type4_fillblank.txt': format_typing_import(part4),
    }
    
    for fname, content in files.items():
        with open(fname, 'w') as f:
            f.write(content)
    
    total = len(part1) + len(part2) + len(part3) + len(part4)
    print(f"\nTotal: {total} questions across 4 files")
    
    # Show samples
    for fname in files:
        with open(fname) as f:
            sample = f.read()[:400]
        print(f"\n--- {fname} ---")
        print(sample)

if __name__ == '__main__':
    main()
