import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { getResults } from "../api/client";
import { SECTION_ORDER } from "../config/assessment";

interface ResultsState {
  studentId: string;
}

interface ResultsData {
  studentId: string;
  totalScore: number;
  maxScore: number;
  completedAt: number;
  byType: Record<number, { correct: number; total: number }>;
}

const TYPE_LABELS: Record<number, { en: string; es: string }> = {
  1: { en: "Vocabulary", es: "Vocabulario" },
  2: { en: "Conversation", es: "Conversación" },
  3: { en: "Fill in the Blank", es: "Completar" },
  4: { en: "Type in the Missing Word", es: "Escribe la Palabra que Falta" },
};

// Ranking bands by raw score out of 40:
// 0-10 Cadet Low-Level | 11-15 Cadet High-Level | 16-20 Cadet Fast-Track |
// 21-30 Ready for Investigation | 31-40 Trainer Material
const getLevel = (score: number) => {
  if (score >= 31) return { label: "Trainer Material", color: "text-emerald-400" };
  if (score >= 21) return { label: "Ready for Investigation", color: "text-blue-400" };
  if (score >= 16) return { label: "Cadet Fast-Track", color: "text-yellow-400" };
  if (score >= 11) return { label: "Cadet High-Level", color: "text-orange-400" };
  return { label: "Cadet Low-Level", color: "text-red-400" };
};

export function ResultsPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const state = location.state as ResultsState;

  const [results, setResults] = useState<ResultsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!state?.studentId) {
      navigate("/");
      return;
    }

    const fetchResults = async () => {
      try {
        const data = await getResults(state.studentId);
        if (data.error) {
          setError(data.error);
        } else {
          setResults(data);
        }
      } catch (err) {
        setError("Error loading results");
      } finally {
        setLoading(false);
      }
    };

    // Small delay to allow DB to settle after test completion
    const timer = setTimeout(fetchResults, 1000);
    return () => clearTimeout(timer);
  }, [state?.studentId, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-pattern flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin h-12 w-12 border-2 border-[var(--gold-500)] border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-slate-400">Cargando resultados...</p>
        </div>
      </div>
    );
  }

  if (error || !results) {
    return (
      <div className="min-h-screen bg-pattern flex items-center justify-center p-4">
        <div className="glass-card rounded-xl p-8 max-w-md text-center">
          <div className="text-red-400 text-lg mb-4">{error || "No results found"}</div>
          <button
            onClick={() => navigate("/")}
            className="btn-primary px-6 py-2 rounded-lg"
          >
            Volver / Back
          </button>
        </div>
      </div>
    );
  }

  const percent = Math.round((results.totalScore / results.maxScore) * 100);
  // Normalize to the standard 40-point scale used by the ranking bands
  const score40 = Math.round((results.totalScore / results.maxScore) * 40);
  const level = getLevel(score40);

  return (
    <div className="min-h-screen bg-pattern">
      {/* Header */}
      <div className="bg-[var(--navy-800)] border-b border-[var(--gold-500)]/20 px-4 py-3">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <span className="badge-gold text-xs px-3 py-1 rounded-full">
            UNIPOL ELAP
          </span>
          <span className="text-sm text-slate-400">
            <span className="text-[var(--gold-400)]">{results.studentId}</span>
          </span>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8">
        {/* Score Card */}
        <div className="glass-card rounded-xl p-8 mb-6 text-center animate-slide-up">
          <div className="gold-accent mb-6" />

          <h1 className="text-2xl text-slate-300 mb-2">
            Evaluación Completada
          </h1>
          <p className="text-sm text-slate-500 mb-6">Assessment Complete</p>

          {/* Big Score */}
          <div className="mb-6">
            <div className="text-6xl font-bold font-['Oswald'] text-[var(--gold-500)] tracking-wider">
              {results.totalScore}
              <span className="text-2xl text-slate-500">/{results.maxScore}</span>
            </div>
            <div className="text-lg text-slate-400 mt-2">{percent}% correcto</div>
          </div>

          {/* Level Badge */}
          <div className={`inline-block px-6 py-2 rounded-full border ${
            level.color.includes("emerald") ? "border-emerald-500/30 bg-emerald-500/10" :
            level.color.includes("blue") ? "border-blue-500/30 bg-blue-500/10" :
            level.color.includes("yellow") ? "border-yellow-500/30 bg-yellow-500/10" :
            level.color.includes("orange") ? "border-orange-500/30 bg-orange-500/10" :
            "border-red-500/30 bg-red-500/10"
          }`}>
            <span className={`font-['Oswald'] text-sm tracking-wider ${level.color}`}>
              {level.label}
            </span>
          </div>

          <div className="gold-accent mt-6" />
        </div>

        {/* Breakdown by Type */}
        <div className="glass-card rounded-xl p-6 mb-6 animate-slide-up" style={{ animationDelay: "0.1s" }}>
          <h2 className="text-lg text-[var(--gold-400)] mb-4">
            Desglose por Tipo / Breakdown by Type
          </h2>

          <div className="space-y-4">
            {SECTION_ORDER.map((type) => {
              const data = results.byType[type];
              if (!data) return null;
              const typePercent = data.total > 0 ? Math.round((data.correct / data.total) * 100) : 0;

              return (
                <div key={type}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-slate-300">
                      {TYPE_LABELS[type].es}
                    </span>
                    <span className="text-sm text-slate-400">
                      {data.correct}/{data.total} ({typePercent}%)
                    </span>
                  </div>
                  <div className="h-2 bg-[var(--navy-900)] rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-1000"
                      style={{
                        width: `${typePercent}%`,
                        background:
                          typePercent >= 75
                            ? "var(--green-500)"
                            : typePercent >= 50
                            ? "var(--gold-500)"
                            : "var(--red-500)",
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Info Card */}
        <div className="glass-card rounded-xl p-6 mb-6 animate-slide-up" style={{ animationDelay: "0.2s" }}>
          <h2 className="text-lg text-[var(--gold-400)] mb-3">
            Información / Details
          </h2>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-slate-500">Estudiante / Student</span>
              <p className="text-slate-300 font-medium">{results.studentId}</p>
            </div>
            <div>
              <span className="text-slate-500">Fecha / Date</span>
              <p className="text-slate-300 font-medium">
                {new Date(results.completedAt).toLocaleDateString("es-MX", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
          </div>
        </div>

        {/* Back Button */}
        <div className="text-center animate-slide-up" style={{ animationDelay: "0.3s" }}>
          <button
            onClick={() => navigate("/")}
            className="btn-secondary px-8 py-3 rounded-lg"
          >
            Volver al Inicio / Back to Home
          </button>
        </div>
      </div>
    </div>
  );
}
