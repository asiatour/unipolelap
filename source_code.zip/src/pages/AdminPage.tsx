import {
  Fragment,
  useState,
  useEffect,
  useCallback,
  useRef,
} from "react";
import {
  getAdminScores,
  getAdminQuestions,
  createQuestion,
  updateQuestion,
  deleteQuestion,
  deleteScore,
} from "../api/client";
import mammoth from "mammoth";
import { SECTION_ORDER } from "../config/assessment";

interface ScoreEntry {
  id: number;
  studentId: string;
  totalScore: number;
  maxScore: number;
  completedAt: number;
  byType: Record<number, { correct: number; total: number }>;
}

interface QuestionEntry {
  id: number;
  questionType: number;
  difficultyOrder: number;
  questionText: string;
  optionA: string | null;
  optionB: string | null;
  optionC: string | null;
  optionD: string | null;
  correctAnswer: string;
}

const TYPE_LABELS: Record<number, { en: string; es: string }> = {
  1: { en: "Vocab", es: "Vocab" },
  2: { en: "Conv", es: "Conv" },
  3: { en: "Completar", es: "Completar" },
  4: { en: "Escribir", es: "Escribir" },
};

const TYPE_LABELS_FULL: Record<number, { en: string; es: string }> = {
  1: { en: "Vocabulary", es: "Vocabulario" },
  2: { en: "Conversation", es: "Conversación" },
  3: { en: "Fill in the Blank", es: "Completar" },
  4: { en: "Type in the Missing Word", es: "Escribe la Palabra que Falta" },
};

// Ranking bands by raw score out of 40 — FULL level labels, kept in
// sync with getLevel in ResultsPage.tsx
const getLevelLabel = (score40: number): string =>
  score40 >= 31
    ? "Trainer Material"
    : score40 >= 21
    ? "Ready for Investigation"
    : score40 >= 16
    ? "Cadet Fast-Track"
    : score40 >= 11
    ? "Cadet High-Level"
    : "Cadet Low-Level";

const EMPTY_QUESTION = {
  questionType: 1,
  difficultyOrder: 1,
  questionText: "",
  optionA: "",
  optionB: "",
  optionC: "",
  optionD: "",
  correctAnswer: "",
  // Extra accepted answers for type 4 (typed answer) questions. They are
  // persisted joined with "/" inside `correctAnswer` (e.g. "stolen/took")
  // and the backend accepts any of them as correct.
  altAnswers: [] as string[],
};

// Split a stored correctAnswer into its individual accepted answers.
// Alternatives may be separated by "/", "," or ";".
const splitCorrectAnswers = (value: string): string[] =>
  (value || "")
    .split(/[\/,;]/)
    .map((v) => v.trim())
    .filter(Boolean);

// Join the answer fields into the stored `correctAnswer` value, dropping
// empties and case-insensitive duplicates (keeps first occurrence).
const joinCorrectAnswers = (values: string[]): string => {
  const seen = new Set<string>();
  const parts: string[] = [];
  for (const raw of values) {
    const v = (raw || "").trim();
    if (!v) continue;
    const key = v.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    parts.push(v);
  }
  return parts.join("/");
};

// Persist the admin code for the current browser tab so a page refresh
// doesn't force re-authentication. sessionStorage survives reloads but is
// cleared when the tab/browser closes (and by the "Cerrar sesión" button).
const ADMIN_SESSION_KEY = "elap-admin-code";

// ---- Google Forms export -------------------------------------------------
// Google Forms can't be filled directly from an external app without OAuth
// setup, so the export works in two steps: (1) download a CSV of the current
// question list (with answers) that imports cleanly into Google Sheets, and
// (2) run a small Apps Script inside that sheet that builds the Google Form
// (as an auto-graded quiz) in one click.

// Column order MUST stay in sync with the column indexes used in
// GOOGLE_FORMS_APPS_SCRIPT (0 Parte · 1 Tipo · 2 Pregunta · 3-6 Opciones ·
// 7 Respuesta correcta · 8 Dificultad).
const GOOGLE_FORMS_CSV_HEADERS = [
  "Parte / Part",
  "Tipo / Type",
  "Pregunta / Question",
  "Opción A",
  "Opción B",
  "Opción C",
  "Opción D",
  "Respuesta correcta / Correct answer",
  "Dificultad / Difficulty",
];

const csvEscape = (value: string | number | null | undefined): string =>
  `"${String(value ?? "").replace(/"/g, '""')}"`;

// ---- Scores (results) CSV export ----------------------------------------
// Full export of the admin results table: one row per completed attempt,
// per-type columns follow SECTION_ORDER (presentation order).
const SCORES_CSV_HEADERS = [
  "#",
  "Matrícula / Student ID",
  "Puntaje / Score",
  "Máximo / Max",
  "%",
  ...SECTION_ORDER.map(
    (t) => `${TYPE_LABELS_FULL[t].es} / ${TYPE_LABELS_FULL[t].en}`
  ),
  "Nivel / Level",
  "Fecha / Date",
];

// Shared CSV download: BOM so Google Sheets/Excel detect UTF-8 accents
// correctly (e.g. "Conversación").
const downloadCsvFile = (filename: string, rows: string[]) => {
  const blob = new Blob(["\uFEFF" + rows.join("\r\n")], {
    type: "text/csv;charset=utf-8;",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

// Apps Script pasted into the exported Google Sheet (Extensión > Apps
// Script). Reads the sheet's first tab and creates a Google Form quiz with
// the correct answer marked on every multiple-choice item.
const GOOGLE_FORMS_APPS_SCRIPT = `// ELAP - crea un Google Form (cuestionario con calificación) a partir de
// la hoja exportada. En Google Sheets: Extensión > Apps Script, pega este
// código y ejecuta createFormFromSheet(). Otorga los permisos que pida.
// Creates a Google Form (auto-graded quiz) from the exported sheet.
// In Google Sheets: Extensions > Apps Script, paste and run
// createFormFromSheet(). Grant the requested permissions when prompted.
function createFormFromSheet() {
  var data = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0]
    .getDataRange().getValues();
  if (data.length < 2) {
    throw new Error("La hoja esta vacia / The sheet is empty");
  }
  // Columnas esperadas (las genera el botón Exportar):
  // 0 Parte · 1 Tipo · 2 Pregunta · 3-6 Opciones · 7 Respuesta correcta
  var rows = data.slice(1);
  var form = FormApp.create("ELAP - English Assessment");
  try { form.setIsQuiz(true); } catch (e) {}
  var added = 0;
  rows.forEach(function (row) {
    var question = String(row[2] || "").trim();
    if (!question) return;
    var type = parseInt(row[1], 10) || 1;
    if (type === 4) {
      // Respuesta escrita: FormApp no permite fijar aquí la clave de
      // respuesta; agrégala manualmente en el Form si la necesitas.
      form.addTextItem().setTitle(question).setPoints(1);
    } else {
      var choices = [row[3], row[4], row[5], row[6]]
        .map(function (v) { return String(v == null ? "" : v).trim(); })
        .filter(function (v) { return v !== ""; });
      if (choices.length === 0) return;
      var correct = String(row[7] || "").trim().toLowerCase();
      form.addMultipleChoiceItem()
        .setTitle(question)
        .setPoints(1)
        .setChoices(choices.map(function (c) {
          return FormApp.createChoice(c, c.toLowerCase() === correct);
        }));
    }
    added++;
  });
  Logger.log("Preguntas agregadas / Questions added: " + added);
  Logger.log("Editar / Edit: " + form.getEditUrl());
  Logger.log("Publicar / Publish: " + form.getPublishedUrl());
}`;
// --------------------------------------------------------------------------

export function AdminPage() {
  const [adminCode, setAdminCode] = useState("");
  const [scores, setScores] = useState<ScoreEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);
  const [error, setError] = useState("");
  const [sortBy, setSortBy] = useState<"score" | "student" | "date">("score");
  const [deletingScoreId, setDeletingScoreId] = useState<number | null>(null);

  // Tab system
  const [activeTab, setActiveTab] = useState<"scores" | "questions">("scores");

  // Question editor state
  const [questions, setQuestions] = useState<QuestionEntry[]>([]);
  const [questionsLoading, setQuestionsLoading] = useState(false);
  const [questionFilter, setQuestionFilter] = useState<number>(0); // 0 = all
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<QuestionEntry | null>(null);
  const [formDraft, setFormDraft] = useState({ ...EMPTY_QUESTION });
  const [formError, setFormError] = useState("");
  const [formSaving, setFormSaving] = useState(false);

  // Docx import state
  const [showImport, setShowImport] = useState(false);
  const [importText, setImportText] = useState("");
  const [importPreview, setImportPreview] = useState<any[]>([]);
  const [importType, setImportType] = useState(1);
  const [importDifficulty, setImportDifficulty] = useState(1);
  const [importLoading, setImportLoading] = useState(false);
  const [importResult, setImportResult] = useState("");
  // Google Forms export panel state
  const [showGoogleForms, setShowGoogleForms] = useState(false);
  const [scriptCopied, setScriptCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Restore a previous session after a refresh: the stored code is
  // re-verified against the backend before access is granted.
  useEffect(() => {
    const stored = sessionStorage.getItem(ADMIN_SESSION_KEY);
    if (!stored) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const result = await getAdminScores(stored);
        if (cancelled) return;
        if (result.error) {
          // Code no longer valid — clear it and show the login form.
          sessionStorage.removeItem(ADMIN_SESSION_KEY);
        } else {
          setAdminCode(stored);
          setScores(result.scores || []);
          setAuthenticated(true);
        }
      } catch {
        // Keep the stored code on network errors so the user can retry
        // from the login form without retyping it.
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const result = await getAdminScores(adminCode);
      if (result.error) {
        setError("Código incorrecto / Incorrect code");
      } else {
        sessionStorage.setItem(ADMIN_SESSION_KEY, adminCode);
        setScores(result.scores || []);
        setAuthenticated(true);
      }
    } catch (err) {
      setError("Error de conexión / Connection error");
    } finally {
      setLoading(false);
    }
  };

  const loadQuestions = useCallback(
    async (opts?: { silent?: boolean }) => {
      if (!authenticated) return;
      // Silent refreshes (right after create/edit/delete) keep the current
      // table rendered so the page doesn't jump back to the top; full loads
      // (tab open, filter change) keep showing the spinner as before.
      if (!opts?.silent) setQuestionsLoading(true);
      try {
        const result = await getAdminQuestions(adminCode, questionFilter || undefined);
        setQuestions(result.questions || []);
      } catch (err) {
        console.error("Failed to load questions:", err);
      } finally {
        if (!opts?.silent) setQuestionsLoading(false);
      }
    },
    [authenticated, adminCode, questionFilter]
  );

  useEffect(() => {
    if (authenticated && activeTab === "questions") {
      loadQuestions();
    }
  }, [authenticated, activeTab, loadQuestions]);

  // The edit form opens inline next to its question in the list; bring it
  // into view when editing starts so it is visible right where the user is.
  useEffect(() => {
    if (!editingQuestion) return;
    const el = document.getElementById("inline-edit-form");
    if (el) el.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [editingQuestion]);

  const handleCreateQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");

    if (!formDraft.questionText.trim()) {
      setFormError("Question text is required");
      return;
    }
    // Type 4 supports multiple accepted answers (stored joined with "/")
    const correctAnswer = joinCorrectAnswers([
      formDraft.correctAnswer,
      ...(formDraft.questionType === 4 ? formDraft.altAnswers : []),
    ]);
    if (!correctAnswer) {
      setFormError("Correct answer is required");
      return;
    }
    if (formDraft.questionType !== 4) {
      if (!formDraft.optionA.trim() || !formDraft.optionB.trim()) {
        setFormError("Options A and B are required for multiple choice");
        return;
      }
    }

    setFormSaving(true);
    try {
      const result = await createQuestion(adminCode, {
        questionType: formDraft.questionType,
        difficultyOrder: formDraft.difficultyOrder,
        questionText: formDraft.questionText.trim(),
        optionA: formDraft.optionA.trim() || undefined,
        optionB: formDraft.optionB.trim() || undefined,
        optionC: formDraft.optionC.trim() || undefined,
        optionD: formDraft.optionD.trim() || undefined,
        correctAnswer,
      });

      if (result.error) {
        setFormError(result.error);
      } else {
        setShowCreateForm(false);
        setFormDraft({ ...EMPTY_QUESTION });
        loadQuestions({ silent: true });
      }
    } catch (err) {
      setFormError("Failed to create question");
    } finally {
      setFormSaving(false);
    }
  };

  const handleUpdateQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingQuestion) return;
    setFormError("");

    if (!formDraft.questionText.trim()) {
      setFormError("Question text is required");
      return;
    }
    // Type 4 supports multiple accepted answers (stored joined with "/")
    const correctAnswer = joinCorrectAnswers([
      formDraft.correctAnswer,
      ...(formDraft.questionType === 4 ? formDraft.altAnswers : []),
    ]);
    if (!correctAnswer) {
      setFormError("Correct answer is required");
      return;
    }

    setFormSaving(true);
    try {
      const result = await updateQuestion(adminCode, editingQuestion.id, {
        questionType: formDraft.questionType,
        difficultyOrder: formDraft.difficultyOrder,
        questionText: formDraft.questionText.trim(),
        optionA: formDraft.optionA.trim() || null,
        optionB: formDraft.optionB.trim() || null,
        optionC: formDraft.optionC.trim() || null,
        optionD: formDraft.optionD.trim() || null,
        correctAnswer,
      });

      if (result.error) {
        setFormError(result.error);
      } else {
        // Stay at the same place in the question list: the refresh is silent
        // (table never unmounts) and the scroll position is restored after
        // the inline edit form collapses.
        const scrollY = window.scrollY;
        const savedQuestionId = editingQuestion.id;
        setEditingQuestion(null);
        setFormDraft({ ...EMPTY_QUESTION });
        loadQuestions({ silent: true });
        requestAnimationFrame(() =>
          requestAnimationFrame(() => {
            window.scrollTo(0, scrollY);
            document
              .getElementById(`question-row-${savedQuestionId}`)
              ?.scrollIntoView({ behavior: "smooth", block: "nearest" });
          })
        );
      }
    } catch (err) {
      setFormError("Failed to update question");
    } finally {
      setFormSaving(false);
    }
  };

  const handleDeleteQuestion = async (questionId: number) => {
    if (!confirm("¿Eliminar esta pregunta? / Delete this question?")) return;
    try {
      await deleteQuestion(adminCode, questionId);
      loadQuestions({ silent: true });
    } catch (err) {
      console.error("Failed to delete question:", err);
    }
  };

  const startEdit = (q: QuestionEntry) => {
    setEditingQuestion(q);
    setShowCreateForm(false);
    // Type 4 answers may list several accepted options ("stolen/took") —
    // split them into the primary field plus the extra answer fields.
    const storedAnswers = splitCorrectAnswers(q.correctAnswer);
    setFormDraft({
      questionType: q.questionType,
      difficultyOrder: q.difficultyOrder,
      questionText: q.questionText,
      optionA: q.optionA || "",
      optionB: q.optionB || "",
      optionC: q.optionC || "",
      optionD: q.optionD || "",
      correctAnswer: storedAnswers[0] || "",
      altAnswers: storedAnswers.slice(1),
    });
    setFormError("");
  };

  // Docx import handlers
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith(".docx") && !file.name.endsWith(".doc") && !file.name.endsWith(".txt")) {
      setImportResult("Error: Please upload a .docx, .doc, or .txt file");
      return;
    }

    try {
      if (file.name.endsWith(".txt")) {
        const text = await file.text();
        setImportText(text);
      } else {
        const arrayBuffer = await file.arrayBuffer();
        const result = await mammoth.extractRawText({ arrayBuffer });
        setImportText(result.value);
      }
      setImportResult("");
    } catch (err) {
      setImportResult("Error reading file. Please try again.");
    }

    // Reset file input
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const parseImportText = () => {
    if (!importText.trim()) {
      setImportResult("No text to parse");
      return;
    }

    const lines = importText.split("\n").filter((l) => l.trim());
    const parsed: any[] = [];
    let current: any = null;

    // Normalize escaped (\_\_) or long underscore runs into one visible blank
    const normalizeBlanks = (s: string) =>
      s.replace(/(?:\\_|_){3,}/g, "__________");

    for (const line of lines) {
      const trimmed = line.trim();

      // Detect question patterns like "1.", "1)", "Q1:", etc.
      const questionMatch = trimmed.match(/^(\d+)[.\):]\s*(.+)/);
      // Options use "A)" or "A." — dialogue speakers use "A:"/"B:" and must
      // stay inside the question text so full dialogues are stored
      const optionMatch = trimmed.match(/^([A-Da-d])[.)]\s+(.+)/);
      // Detect answer patterns like "Answer:", "Respuesta:", "Correct:", etc.
      const answerMatch = trimmed.match(/^(answer|correct|respuesta|correcta)[\s:=]+(.+)/i);

      if (questionMatch && !optionMatch) {
        // Save previous question
        if (current && current.questionText) {
          parsed.push(current);
        }
        current = {
          questionText: normalizeBlanks(questionMatch[2]),
          optionA: "",
          optionB: "",
          optionC: "",
          optionD: "",
          correctAnswer: "",
        };
      } else if (optionMatch && current) {
        const letter = optionMatch[1].toUpperCase();
        if (letter === "A") current.optionA = optionMatch[2];
        else if (letter === "B") current.optionB = optionMatch[2];
        else if (letter === "C") current.optionC = optionMatch[2];
        else if (letter === "D") current.optionD = optionMatch[2];
      } else if (answerMatch && current) {
        const answer = answerMatch[2].trim();
        // MCQ answers are single letters; fill-in answers are full words
        current.correctAnswer = /^[A-Da-d]$/.test(answer)
          ? answer.toUpperCase()
          : answer;
      } else if (
        current &&
        !/^(unit|section|part|unidad|sección|seccion)\b/i.test(trimmed)
      ) {
        // Dialogue lines ("A: ...", "B: ...") continue the full question,
        // including where the blanks are
        current.questionText += "\n" + normalizeBlanks(trimmed);
      }
    }

    // Don't forget the last question
    if (current && current.questionText) {
      parsed.push(current);
    }

    setImportPreview(parsed);
    if (parsed.length === 0) {
      setImportResult("No questions found. Check the format of your document.");
    } else {
      setImportResult(`Found ${parsed.length} questions. Review and import below.`);
    }
  };

  const handleBulkImport = async () => {
    if (importPreview.length === 0) return;

    setImportLoading(true);
    let successCount = 0;
    let failCount = 0;

    for (let i = 0; i < importPreview.length; i++) {
      const q = importPreview[i];
      try {
        const result = await createQuestion(adminCode, {
          questionType: importType,
          difficultyOrder: importDifficulty + i,
          questionText: q.questionText,
          optionA: q.optionA || undefined,
          optionB: q.optionB || undefined,
          optionC: q.optionC || undefined,
          optionD: q.optionD || undefined,
          correctAnswer: q.correctAnswer || "A",
        });
        if (result.error) failCount++;
        else successCount++;
      } catch (err) {
        failCount++;
      }
    }

    setImportLoading(false);
    setImportResult(
      `Import complete: ${successCount} created, ${failCount} failed.`
    );
    setImportPreview([]);
    setImportText("");
    loadQuestions({ silent: true });
  };

  const sortedScores = [...scores].sort((a, b) => {
    if (sortBy === "score") return (b.totalScore || 0) - (a.totalScore || 0);
    if (sortBy === "student") return a.studentId.localeCompare(b.studentId);
    return (b.completedAt || 0) - (a.completedAt || 0);
  });

  const handleDeleteScore = async (score: ScoreEntry) => {
    const confirmed = confirm(
      `¿Eliminar el puntaje de ${score.studentId} (${score.totalScore}/${score.maxScore})?\n` +
        `Esta acción no se puede deshacer.\n\n` +
        `Delete score for ${score.studentId} (${score.totalScore}/${score.maxScore})?\n` +
        `This action cannot be undone.`
    );
    if (!confirmed) return;

    setDeletingScoreId(score.id);
    try {
      const result = await deleteScore(adminCode, score.id);
      if (result.error) {
        alert(`No se pudo eliminar / Delete failed: ${result.error}`);
      } else {
        setScores((prev) => prev.filter((s) => s.id !== score.id));
      }
    } catch (err) {
      alert("Error de conexión / Connection error");
    } finally {
      setDeletingScoreId(null);
    }
  };

  // Export the full results table (all attempts, current sort order) as a
  // CSV file: matrícula, score, %, per-type breakdown (SECTION_ORDER),
  // level band and date. BOM included so Excel opens accents correctly.
  const handleExportScoresCsv = () => {
    if (sortedScores.length === 0) return;

    const rows = [SCORES_CSV_HEADERS.map(csvEscape).join(",")];
    for (const [idx, score] of sortedScores.entries()) {
      const percent = Math.round(
        ((score.totalScore || 0) / (score.maxScore || 40)) * 100
      );
      const score40 = Math.round(
        ((score.totalScore || 0) / (score.maxScore || 40)) * 40
      );
      rows.push(
        [
          idx + 1,
          score.studentId,
          score.totalScore,
          score.maxScore,
          `${percent}%`,
          ...SECTION_ORDER.map((type) => {
            const data = score.byType?.[type];
            return data ? `${data.correct}/${data.total}` : "-";
          }),
          getLevelLabel(score40),
          score.completedAt
            ? new Date(score.completedAt).toLocaleString("sv-SE", {
                hour12: false,
              })
            : "",
        ]
          .map(csvEscape)
          .join(",")
      );
    }
    downloadCsvFile(
      `unipol-elap-resultados-${new Date()
        .toISOString()
        .slice(0, 10)}.csv`,
      rows
    );
  };

  const avgScore =
    scores.length > 0
      ? Math.round(
          scores.reduce((sum, s) => sum + (s.totalScore || 0), 0) / scores.length
        )
      : 0;

  const filteredQuestions = questionFilter
    ? questions.filter((q) => q.questionType === questionFilter)
    : questions;

  // Export the currently visible questions (respects the type filter) as a
  // Google-Sheets-friendly CSV, ordered by presentation part (SECTION_ORDER)
  // then difficulty, and reveal the Apps Script instructions panel.
  const handleExportGoogleForms = () => {
    const ordered = [...filteredQuestions].sort((a, b) => {
      const partA = SECTION_ORDER.indexOf(a.questionType);
      const partB = SECTION_ORDER.indexOf(b.questionType);
      return (
        partA - partB ||
        a.difficultyOrder - b.difficultyOrder ||
        a.id - b.id
      );
    });

    const rows = [GOOGLE_FORMS_CSV_HEADERS.map(csvEscape).join(",")];
    for (const q of ordered) {
      rows.push(
        [
          SECTION_ORDER.indexOf(q.questionType) + 1,
          q.questionType,
          q.questionText,
          q.optionA ?? "",
          q.optionB ?? "",
          q.optionC ?? "",
          q.optionD ?? "",
          q.correctAnswer,
          q.difficultyOrder,
        ]
          .map(csvEscape)
          .join(",")
      );
    }

    // BOM so Google Sheets/Excel detect UTF-8 accents correctly.
    downloadCsvFile(
      `elap-preguntas-${
        questionFilter ? `tipo-${questionFilter}` : "completo"
      }-google-forms.csv`,
      rows
    );

    setShowGoogleForms(true);
    setScriptCopied(false);
  };

  const handleCopyAppsScript = async () => {
    try {
      await navigator.clipboard.writeText(GOOGLE_FORMS_APPS_SCRIPT);
      setScriptCopied(true);
      setTimeout(() => setScriptCopied(false), 2500);
    } catch {
      alert(
        "No se pudo copiar automáticamente. Selecciona el código manualmente.\n" +
          "Could not copy automatically. Please select the code manually."
      );
    }
  };

  // Question form JSX (shared between create and edit)
  const renderQuestionForm = (
    isEdit: boolean,
    onSubmit: (e: React.FormEvent) => void
  ) => (
    <form onSubmit={onSubmit} className="glass-card rounded-xl p-6 animate-slide-up">
      <h3 className="text-lg text-[var(--gold-400)] mb-4">
        {isEdit
          ? "Editar Pregunta / Edit Question"
          : "Nueva Pregunta / New Question"}
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label className="block text-xs text-slate-500 mb-1">Tipo / Type</label>
          <select
            value={formDraft.questionType}
            onChange={(e) =>
              setFormDraft((prev) => ({ ...prev, questionType: parseInt(e.target.value) }))
            }
            className="input-field w-full px-3 py-2 rounded-lg text-sm"
          >
            {[1, 2, 3, 4].map((t) => (
              <option key={t} value={t}>
                {t} - {TYPE_LABELS_FULL[t].es} / {TYPE_LABELS_FULL[t].en}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1">
            Dificultad / Difficulty (1-10)
          </label>
          <input
            type="number"
            min={1}
            max={10}
            value={formDraft.difficultyOrder}
            onChange={(e) =>
              setFormDraft((prev) => ({
                ...prev,
                difficultyOrder: parseInt(e.target.value) || 1,
              }))
            }
            className="input-field w-full px-3 py-2 rounded-lg text-sm"
          />
        </div>
      </div>

      <div className="mb-4">
        <label className="block text-xs text-slate-500 mb-1">
          Pregunta / Question Text
        </label>
        <textarea
          value={formDraft.questionText}
          onChange={(e) =>
            setFormDraft((prev) => ({ ...prev, questionText: e.target.value }))
          }
          className="input-field w-full px-3 py-2 rounded-lg text-sm whitespace-pre-line"
          rows={6}
          required
        />
      </div>

      {formDraft.questionType !== 4 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
          {["A", "B", "C", "D"].map((letter) => (
            <div key={letter}>
              <label className="block text-xs text-slate-500 mb-1">
                Opción {letter} / Option {letter}
              </label>
              <input
                type="text"
                value={formDraft[`option${letter}` as keyof typeof formDraft] as string}
                onChange={(e) =>
                  setFormDraft((prev) => ({
                    ...prev,
                    [`option${letter}`]: e.target.value,
                  }))
                }
                className="input-field w-full px-3 py-2 rounded-lg text-sm"
                placeholder={`Option ${letter}`}
              />
            </div>
          ))}
        </div>
      )}

      <div className="mb-4">
        <label className="block text-xs text-slate-500 mb-1">
          Respuesta Correcta / Correct Answer
        </label>
        {formDraft.questionType === 4 ? (
          <div className="space-y-2">
            <input
              type="text"
              value={formDraft.correctAnswer}
              onChange={(e) =>
                setFormDraft((prev) => ({ ...prev, correctAnswer: e.target.value }))
              }
              className="input-field w-full px-3 py-2 rounded-lg text-sm"
              placeholder="Respuesta correcta / Correct answer"
              required
            />
            {formDraft.altAnswers.map((alt, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <input
                  type="text"
                  value={alt}
                  onChange={(e) =>
                    setFormDraft((prev) => ({
                      ...prev,
                      altAnswers: prev.altAnswers.map((a, i) =>
                        i === idx ? e.target.value : a
                      ),
                    }))
                  }
                  className="input-field w-full px-3 py-2 rounded-lg text-sm"
                  placeholder={`Otra respuesta correcta ${idx + 2} / Another correct answer ${idx + 2}`}
                />
                <button
                  type="button"
                  onClick={() =>
                    setFormDraft((prev) => ({
                      ...prev,
                      altAnswers: prev.altAnswers.filter((_, i) => i !== idx),
                    }))
                  }
                  className="btn-secondary px-3 py-2 rounded-lg text-sm shrink-0"
                  title="Quitar opción / Remove option"
                >
                  ✕
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={() =>
                setFormDraft((prev) => ({
                  ...prev,
                  altAnswers: [...prev.altAnswers, ""],
                }))
              }
              className="btn-secondary px-3 py-2 rounded-lg text-xs"
            >
              + Añadir otra respuesta correcta / Add another correct answer
            </button>
            <p className="text-xs text-slate-500">
              Si hay varias, cuenta como correcta cualquiera de ellas (ej.
              "stolen/took"). / If there are several, any of them counts as
              correct (e.g. "stolen/took").
            </p>
          </div>
        ) : (
          <select
            value={formDraft.correctAnswer}
            onChange={(e) =>
              setFormDraft((prev) => ({ ...prev, correctAnswer: e.target.value }))
            }
            className="input-field w-full px-3 py-2 rounded-lg text-sm"
            required
          >
            <option value="">Select...</option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
            <option value="D">D</option>
          </select>
        )}
      </div>

      {formError && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg px-4 py-2 mb-4 text-sm text-red-400">
          {formError}
        </div>
      )}

      <div className="flex gap-3">
        <button
          type="button"
          onClick={() => {
            setShowCreateForm(false);
            setEditingQuestion(null);
            setFormDraft({ ...EMPTY_QUESTION });
            setFormError("");
          }}
          className="btn-secondary px-4 py-2 rounded-lg text-sm"
        >
          Cancelar / Cancel
        </button>
        <button
          type="submit"
          disabled={formSaving}
          className="btn-primary px-4 py-2 rounded-lg text-sm"
        >
          {formSaving
            ? "Guardando..."
            : isEdit
            ? "Guardar / Save"
            : "Crear / Create"}
        </button>
      </div>
    </form>
  );

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-pattern flex items-center justify-center p-4">
        <div className="w-full max-w-sm animate-slide-up">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full border border-[var(--gold-500)]/30 mb-4 bg-[var(--navy-800)]">
              <svg
                className="w-8 h-8 text-[var(--gold-500)]"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={1.5}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z"
                />
              </svg>
            </div>
            <h1 className="text-xl text-[var(--gold-500)] tracking-wider">
              Panel Administrativo
            </h1>
            <p className="text-xs text-slate-500 mt-1">UNIPOL ELAP · Admin Access</p>
          </div>

          <div className="glass-card rounded-xl p-6">
            <form onSubmit={handleLogin}>
              <label className="block mb-2 text-sm text-slate-400">
                Código de Administrador
              </label>
              <input
                type="password"
                value={adminCode}
                onChange={(e) => setAdminCode(e.target.value)}
                placeholder="••••••••"
                className="input-field w-full px-4 py-3 rounded-lg mb-4"
                autoFocus
              />

              {error && (
                <div className="bg-red-500/10 border border-red-500/30 rounded-lg px-4 py-2 mb-4 text-sm text-red-400 animate-fade-in">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading || !adminCode}
                className="btn-primary w-full py-3 rounded-lg"
              >
                {loading ? "Verificando..." : "Acceder / Access"}
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-pattern">
      {/* Header */}
      <div className="bg-[var(--navy-800)] border-b border-[var(--gold-500)]/20 px-4 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="badge-gold text-xs px-3 py-1 rounded-full">
              UNIPOL ELAP
            </span>
            <span className="text-xs text-slate-500">Admin Panel</span>
          </div>
          <button
            onClick={() => {
              sessionStorage.removeItem(ADMIN_SESSION_KEY);
              setAuthenticated(false);
              setScores([]);
              setAdminCode("");
              setActiveTab("scores");
            }}
            className="text-xs text-slate-500 hover:text-[var(--gold-400)] transition-colors"
          >
            Cerrar sesión
          </button>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-[var(--navy-800)]/50 border-b border-slate-700/30 px-4">
        <div className="max-w-6xl mx-auto flex gap-1">
          <button
            onClick={() => setActiveTab("scores")}
            className={`px-4 py-3 text-sm font-medium transition-colors border-b-2 ${
              activeTab === "scores"
                ? "border-[var(--gold-500)] text-[var(--gold-400)]"
                : "border-transparent text-slate-500 hover:text-slate-300"
            }`}
          >
            Resultados / Scores
          </button>
          <button
            onClick={() => setActiveTab("questions")}
            className={`px-4 py-3 text-sm font-medium transition-colors border-b-2 ${
              activeTab === "questions"
                ? "border-[var(--gold-500)] text-[var(--gold-400)]"
                : "border-transparent text-slate-500 hover:text-slate-300"
            }`}
          >
            Preguntas / Questions
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* ===== SCORES TAB ===== */}
        {activeTab === "scores" && (
          <>
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="glass-card rounded-xl p-5 animate-slide-up">
                <p className="text-xs text-slate-500 uppercase tracking-wider">
                  Total Estudiantes
                </p>
                <p className="text-3xl font-bold font-['Oswald'] text-[var(--gold-500)] mt-1">
                  {scores.length}
                </p>
              </div>
              <div
                className="glass-card rounded-xl p-5 animate-slide-up"
                style={{ animationDelay: "0.05s" }}
              >
                <p className="text-xs text-slate-500 uppercase tracking-wider">
                  Promedio / Average
                </p>
                <p className="text-3xl font-bold font-['Oswald'] text-[var(--gold-500)] mt-1">
                  {avgScore}/40
                </p>
              </div>
              <div
                className="glass-card rounded-xl p-5 animate-slide-up"
                style={{ animationDelay: "0.1s" }}
              >
                <p className="text-xs text-slate-500 uppercase tracking-wider">
                  % Promedio
                </p>
                <p className="text-3xl font-bold font-['Oswald'] text-[var(--gold-500)] mt-1">
                  {scores.length > 0
                    ? Math.round(
                        scores.reduce(
                          (sum, s) => sum + ((s.totalScore || 0) / (s.maxScore || 40)) * 100,
                          0
                        ) / scores.length
                      )
                    : 0}
                  %
                </p>
              </div>
            </div>

            {/* Sort Controls */}
            <div className="flex items-center gap-2 mb-4 flex-wrap">
              <span className="text-xs text-slate-500">Ordenar / Sort:</span>
              {(["score", "student", "date"] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setSortBy(s)}
                  className={`text-xs px-3 py-1 rounded-full transition-colors ${
                    sortBy === s
                      ? "bg-[var(--gold-500)]/20 text-[var(--gold-400)] border border-[var(--gold-500)]/30"
                      : "text-slate-500 border border-slate-700/50 hover:border-slate-600"
                  }`}
                >
                  {s === "score" ? "Por Puntaje" : s === "student" ? "Por ID" : "Por Fecha"}
                </button>
              ))}
              <button
                onClick={handleExportScoresCsv}
                disabled={sortedScores.length === 0}
                className="ml-auto text-xs px-3 py-1 rounded-full transition-colors border border-[var(--gold-500)]/40 text-[var(--gold-400)] hover:bg-[var(--gold-500)]/10 disabled:opacity-40 disabled:cursor-not-allowed"
                title="Descargar todos los resultados en formato CSV / Download all results as CSV"
              >
                Exportar CSV / Export CSV
              </button>
            </div>

            {/* Scores Table */}
            <div className="glass-card rounded-xl overflow-hidden animate-slide-up" style={{ animationDelay: "0.15s" }}>
              {scores.length === 0 ? (
                <div className="p-8 text-center text-slate-500">
                  No hay resultados aún / No results yet
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="admin-table admin-table-compact">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>ID Estudiante</th>
                        <th>Puntaje</th>
                        <th>%</th>
                        {SECTION_ORDER.map((type) => (
                          <th key={type} className="text-center text-[10px]">
                            {TYPE_LABELS[type].es}
                          </th>
                        ))}
                        <th className="whitespace-nowrap">Nivel / Level</th>
                        <th>Fecha</th>
                        <th>Acción / Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedScores.map((score, idx) => {
                        const percent = Math.round(
                          ((score.totalScore || 0) / (score.maxScore || 40)) * 100
                        );
                        // Ranking bands by raw score out of 40 — FULL level
                        // labels, kept in sync with getLevel in ResultsPage.tsx
                        const score40 = Math.round(
                          ((score.totalScore || 0) / (score.maxScore || 40)) * 40
                        );
                        const level = getLevelLabel(score40);

                        return (
                          <tr key={score.id}>
                            <td className="text-slate-500 text-xs">{idx + 1}</td>
                            <td className="font-medium text-slate-200 text-sm">
                              {score.studentId}
                            </td>
                            <td className="font-bold text-[var(--gold-400)]">
                              {score.totalScore}/{score.maxScore}
                            </td>
                            <td>{percent}%</td>
                            {SECTION_ORDER.map((type) => {
                              const data = score.byType?.[type];
                              return (
                                <td key={type} className="text-center text-slate-400">
                                  {data ? `${data.correct}/${data.total}` : "-"}
                                </td>
                              );
                            })}
                            <td>
                              <span
                                className={`text-xs px-2 py-0.5 rounded-full whitespace-nowrap ${
                                  score40 >= 31
                                    ? "bg-emerald-500/10 text-emerald-400"
                                    : score40 >= 21
                                    ? "bg-blue-500/10 text-blue-400"
                                    : score40 >= 16
                                    ? "bg-yellow-500/10 text-yellow-400"
                                    : score40 >= 11
                                    ? "bg-orange-500/10 text-orange-400"
                                    : "bg-red-500/10 text-red-400"
                                }`}
                              >
                                {level}
                              </span>
                            </td>
                            <td className="text-slate-500 text-xs">
                              {score.completedAt
                                ? new Date(score.completedAt).toLocaleDateString(
                                    "es-MX",
                                    { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }
                                  )
                                : "-"}
                            </td>
                            <td>
                              <button
                                onClick={() => handleDeleteScore(score)}
                                disabled={deletingScoreId === score.id}
                                className="text-xs text-slate-400 hover:text-red-400 transition-colors disabled:opacity-50"
                                title="Eliminar puntaje / Delete score"
                              >
                                {deletingScoreId === score.id
                                  ? "..."
                                  : "Eliminar"}
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        )}

        {/* ===== QUESTIONS TAB ===== */}
        {activeTab === "questions" && (
          <>
            {/* Filter + Create Controls */}
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <span className="text-xs text-slate-500">Filtrar / Filter:</span>
              <button
                onClick={() => setQuestionFilter(0)}
                className={`text-xs px-3 py-1 rounded-full transition-colors ${
                  questionFilter === 0
                    ? "bg-[var(--gold-500)]/20 text-[var(--gold-400)] border border-[var(--gold-500)]/30"
                    : "text-slate-500 border border-slate-700/50 hover:border-slate-600"
                }`}
              >
                Todas / All ({questions.length})
              </button>
              {[1, 2, 3, 4].map((t) => {
                const count = questions.filter((q) => q.questionType === t).length;
                return (
                  <button
                    key={t}
                    onClick={() => {
                      setQuestionFilter(t);
                      setEditingQuestion(null);
                    }}
                    className={`text-xs px-3 py-1 rounded-full transition-colors ${
                      questionFilter === t
                        ? "bg-[var(--gold-500)]/20 text-[var(--gold-400)] border border-[var(--gold-500)]/30"
                        : "text-slate-500 border border-slate-700/50 hover:border-slate-600"
                    }`}
                  >
                    {TYPE_LABELS_FULL[t].es} ({count})
                  </button>
                );
              })}
              <div className="ml-auto flex gap-2">
                <button
                  onClick={() => {
                    setShowGoogleForms(!showGoogleForms);
                    setShowImport(false);
                    setShowCreateForm(false);
                    setEditingQuestion(null);
                  }}
                  className="btn-secondary px-4 py-2 rounded-lg text-sm"
                >
                  📤 Exportar / Export
                </button>
                <button
                  onClick={() => {
                    setShowImport(!showImport);
                    setShowCreateForm(false);
                    setEditingQuestion(null);
                    setImportResult("");
                  }}
                  className="btn-secondary px-4 py-2 rounded-lg text-sm"
                >
                  📄 Importar / Import
                </button>
                <button
                  onClick={() => {
                    setShowCreateForm(true);
                    setEditingQuestion(null);
                    setFormDraft({ ...EMPTY_QUESTION });
                    setFormError("");
                  }}
                  className="btn-primary px-4 py-2 rounded-lg text-sm"
                >
                  + Nueva Pregunta
                </button>
              </div>
            </div>

            {/* Import Section */}
            {showImport && (
              <div className="glass-card rounded-xl p-6 mb-4 animate-slide-up">
                <h3 className="text-lg text-[var(--gold-400)] mb-3">
                  Importar Preguntas / Import Questions
                </h3>
                <p className="text-xs text-slate-500 mb-4">
                  Upload a .docx file with your questions. The parser looks for numbered questions (1. 2. etc.) with lettered options (A. B. C. D.) and "Answer:" or "Respuesta:" lines.
                </p>

                <div className="flex flex-wrap items-end gap-4 mb-4">
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">
                      Archivo / File
                    </label>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".docx,.doc,.txt"
                      onChange={handleFileUpload}
                      className="text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-[var(--gold-500)]/20 file:text-[var(--gold-400)] hover:file:bg-[var(--gold-500)]/30"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">
                      Tipo / Type
                    </label>
                    <select
                      value={importType}
                      onChange={(e) => setImportType(parseInt(e.target.value))}
                      className="input-field px-3 py-2 rounded-lg text-sm"
                    >
                      {[1, 2, 3, 4].map((t) => (
                        <option key={t} value={t}>
                          {TYPE_LABELS_FULL[t].es}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">
                      Dificultad inicial / Starting difficulty
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={10}
                      value={importDifficulty}
                      onChange={(e) => setImportDifficulty(parseInt(e.target.value) || 1)}
                      className="input-field w-20 px-3 py-2 rounded-lg text-sm"
                    />
                  </div>
                  {importText && (
                    <button
                      onClick={parseImportText}
                      className="btn-primary px-4 py-2 rounded-lg text-sm"
                    >
                      Analizar / Parse
                    </button>
                  )}
                </div>

                {importText && (
                  <div className="mb-4">
                    <label className="block text-xs text-slate-500 mb-1">
                      Texto extraído / Extracted text (editable)
                    </label>
                    <textarea
                      value={importText}
                      onChange={(e) => setImportText(e.target.value)}
                      className="input-field w-full px-3 py-2 rounded-lg text-sm font-mono"
                      rows={6}
                    />
                  </div>
                )}

                {importResult && (
                  <div className="mb-4 text-sm text-[var(--gold-400)]">
                    {importResult}
                  </div>
                )}

                {importPreview.length > 0 && (
                  <>
                    <div className="mb-3">
                      <p className="text-xs text-slate-500">
                        Vista previa / Preview ({importPreview.length} questions)
                      </p>
                    </div>
                    <div className="max-h-64 overflow-y-auto mb-4 space-y-2">
                      {importPreview.map((q, idx) => (
                        <div key={idx} className="bg-[var(--navy-900)] rounded-lg p-3 text-sm">
                          <p className="text-slate-200 mb-1 whitespace-pre-line">
                            <span className="text-[var(--gold-400)] font-bold">{idx + 1}.</span> {q.questionText}
                          </p>
                          <div className="text-xs text-slate-500 space-x-3">
                            {q.optionA && <span>A: {q.optionA}</span>}
                            {q.optionB && <span>B: {q.optionB}</span>}
                            {q.optionC && <span>C: {q.optionC}</span>}
                            {q.optionD && <span>D: {q.optionD}</span>}
                          </div>
                          <p className="text-xs text-emerald-400 mt-1">
                            Answer: {q.correctAnswer || "?"}
                          </p>
                        </div>
                      ))}
                    </div>
                    <button
                      onClick={handleBulkImport}
                      disabled={importLoading}
                      className="btn-primary px-4 py-2 rounded-lg text-sm"
                    >
                      {importLoading ? "Importando..." : `Importar ${importPreview.length} Preguntas`}
                    </button>
                  </>
                )}
              </div>
            )}

            {/* Google Forms Export Section */}
            {showGoogleForms && (
              <div className="glass-card rounded-xl p-6 mb-4 animate-slide-up">
                <h3 className="text-lg text-[var(--gold-400)] mb-3">
                  Exportar a Google Forms / Export to Google Forms
                </h3>
                <p className="text-xs text-slate-500 mb-4">
                  Google Forms no se puede llenar directamente desde una app
                  externa, pero este flujo lo hace en ~2 minutos: primero
                  descarga el CSV con las{" "}
                  <span className="text-slate-300">
                    {filteredQuestions.length} preguntas visibles
                  </span>{" "}
                  (con sus respuestas), luego usa el script de abajo para
                  generar el cuestionario automáticamente.
                  <br />
                  Google Forms can't be filled directly from an external app,
                  but this flow takes ~2 minutes: download the CSV with the{" "}
                  <span className="text-slate-300">
                    {filteredQuestions.length} visible questions
                  </span>{" "}
                  (answers included), then use the script below to generate the
                  form automatically.{" "}
                  <span className="text-[var(--gold-400)]">
                    Se exportan las preguntas del filtro actual / The current
                    filter's questions are exported.
                  </span>
                </p>

                <ol className="text-xs text-slate-400 space-y-1 mb-4 list-decimal list-inside">
                  <li>
                    Descarga el CSV / Download the CSV.
                  </li>
                  <li>
                    Abre{" "}
                    <a
                      href="https://sheets.new"
                      target="_blank"
                      rel="noreferrer"
                      className="text-[var(--gold-400)] hover:underline"
                    >
                      sheets.new
                    </a>{" "}
                    → Archivo → Importar → Subir el archivo CSV / File →
                    Import → Upload the CSV file.
                  </li>
                  <li>
                    Extensión → Apps Script → borra el contenido y pega el
                    script de abajo / Extensions → Apps Script → clear the
                    content and paste the script below.
                  </li>
                  <li>
                    Ejecuta{" "}
                    <span className="font-mono text-[var(--gold-400)]">
                      createFormFromSheet
                    </span>{" "}
                    y otorga permisos: se creará un Google Form (quiz) con las
                    respuestas correctas marcadas. El enlace aparece en
                    "Registro" / Run it and grant permissions: a Google Form
                    (quiz) with correct answers marked is created; the link
                    appears in the "Execution log".
                  </li>
                </ol>

                <button
                  onClick={handleExportGoogleForms}
                  className="btn-primary px-4 py-2 rounded-lg text-sm mb-4"
                >
                  ⬇️ Descargar CSV / Download CSV
                </button>

                <p className="text-xs text-slate-500 mb-2">
                  Script de Google Apps Script (pégalo en la hoja / paste it
                  into the sheet):
                </p>
                <div className="relative mb-2">
                  <button
                    onClick={handleCopyAppsScript}
                    className="absolute top-2 right-2 btn-secondary px-3 py-1 rounded-lg text-xs z-10"
                  >
                    {scriptCopied ? "¡Copiado! / Copied!" : "📋 Copiar / Copy"}
                  </button>
                  <pre className="bg-[var(--navy-900)] rounded-lg p-4 text-xs text-slate-300 overflow-x-auto max-h-72">
                    {GOOGLE_FORMS_APPS_SCRIPT}
                  </pre>
                </div>

                <p className="text-xs text-slate-500">
                  Nota / Note: las preguntas de tipo 4 (respuesta escrita) se
                  crean sin clave de calificación automática (limitación de
                  Apps Script); revísalas manualmente en el Form si las
                  necesitas calificadas. / Type 4 (typed answer) questions are
                  created without an automatic answer key (Apps Script
                  limitation); set them manually in the Form if you need them
                  graded.
                </p>
              </div>
            )}

            {/* Create Form (the edit form opens inline next to its question below) */}
            {showCreateForm && renderQuestionForm(false, handleCreateQuestion)}

            {/* Questions List */}
            <div className="glass-card rounded-xl overflow-hidden animate-slide-up" style={{ animationDelay: "0.1s" }}>
              {questionsLoading ? (
                <div className="p-8 text-center">
                  <div className="animate-spin h-8 w-8 border-2 border-[var(--gold-500)] border-t-transparent rounded-full mx-auto mb-3" />
                  <p className="text-slate-500 text-sm">Cargando...</p>
                </div>
              ) : filteredQuestions.length === 0 ? (
                <div className="p-8 text-center text-slate-500">
                  No hay preguntas / No questions
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="admin-table">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Tipo</th>
                        <th>Dif.</th>
                        <th>Pregunta / Question</th>
                        <th>Resp. / Answer</th>
                        <th>Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredQuestions.map((q) => (
                        <Fragment key={q.id}>
                          <tr
                            id={`question-row-${q.id}`}
                            className={
                              editingQuestion?.id === q.id
                                ? "bg-[var(--gold-500)]/10"
                                : ""
                            }
                          >
                          <td className="text-slate-500">{q.id}</td>
                          <td>
                            <span className="badge-gold text-[10px] px-2 py-0.5 rounded">
                              {TYPE_LABELS_FULL[q.questionType]?.es || q.questionType}
                            </span>
                          </td>
                          <td className="text-slate-400">{q.difficultyOrder}</td>
                          <td className="text-slate-200 max-w-xs whitespace-pre-line line-clamp-3">
                            {q.questionText}
                          </td>
                          <td className="font-bold text-[var(--gold-400)]">
                            {q.correctAnswer}
                          </td>
                          <td>
                            <div className="flex gap-2">
                              <button
                                onClick={() => startEdit(q)}
                                className="text-xs text-slate-400 hover:text-[var(--gold-400)] transition-colors"
                              >
                                Editar
                              </button>
                              <button
                                onClick={() => handleDeleteQuestion(q.id)}
                                className="text-xs text-slate-400 hover:text-red-400 transition-colors"
                              >
                                Eliminar
                              </button>
                            </div>
                          </td>
                          </tr>
                          {editingQuestion?.id === q.id && (
                            <tr>
                              <td colSpan={6}>
                                <div id="inline-edit-form" className="p-3">
                                  {renderQuestionForm(true, handleUpdateQuestion)}
                                </div>
                              </td>
                            </tr>
                          )}
                        </Fragment>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
