import { useState, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { checkStudent } from "../api/client";

// ⚠️ TEMPORARY POLICY (2026-10-01): multiple attempts are allowed for now.
// This mirrors ALLOW_MULTIPLE_ATTEMPTS in backend/server/src/index.ts.
// Set back to false when attempts are locked again (one attempt only).
const TEMP_MULTIPLE_ATTEMPTS = true;

// Cadet ID format: 7 digits total — Generación (3) + Grupo (2) + No. de Lista (2)
const GEN_DIGITS = 3;
const GROUP_DIGITS = 2;
const LIST_DIGITS = 2;
const CADET_ID_TOTAL_DIGITS = GEN_DIGITS + GROUP_DIGITS + LIST_DIGITS;

export function LoginPage() {
  const [generation, setGeneration] = useState("");
  const [group, setGroup] = useState("");
  const [listNumber, setListNumber] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  // Footer copy follows the server flag once known (see handleSubmit).
  const [attemptsAllowed, setAttemptsAllowed] = useState(TEMP_MULTIPLE_ATTEMPTS);
  const navigate = useNavigate();

  // Input refs for auto-advance between fields
  const generationRef = useRef<HTMLInputElement>(null);
  const groupRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLInputElement>(null);

  // Combined cadet ID: generation + group + list number, exactly 7 digits.
  // Group/list single digits are normalized to 2 digits (e.g. "8" → "08");
  // the Generación field is used exactly as typed (never zero-padded).
  const paddedGroup = group ? group.padStart(GROUP_DIGITS, "0") : group;
  const paddedList = listNumber ? listNumber.padStart(LIST_DIGITS, "0") : listNumber;
  const studentId = generation + paddedGroup + paddedList;
  const totalDigits = studentId.length;
  const isIdValid =
    generation.length === GEN_DIGITS &&
    paddedGroup.length === GROUP_DIGITS &&
    paddedList.length === LIST_DIGITS;

  // Digits only, capped at each field's fixed width; auto-advance when full
  const handleDigitChange = (
    setter: React.Dispatch<React.SetStateAction<string>>,
    max: number,
    nextRef?: React.RefObject<HTMLInputElement>
  ) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const digits = e.target.value.replace(/\D/g, "").slice(0, max);
    setter(digits);
    if (error) setError("");
    if (digits.length === max && nextRef?.current) nextRef.current.focus();
  };

  // On blur, left-pad short values with zeros (e.g. "8" → "08") — ONLY for the
  // Grupo and Lista fields, which are always 2 digits. The Generación field is
  // never padded, so its number never defaults to starting with a zero.
  const padField = (
    value: string,
    setter: React.Dispatch<React.SetStateAction<string>>,
    max: number
  ) => () => {
    if (value.length > 0 && value.length < max) {
      setter(value.padStart(max, "0"));
    }
  };

  // Easter egg: 5 logo clicks → admin page
  const logoClickCount = useRef(0);
  const logoClickTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleLogoClick = useCallback(() => {
    logoClickCount.current += 1;

    if (logoClickCount.current >= 5) {
      logoClickCount.current = 0;
      if (logoClickTimer.current) clearTimeout(logoClickTimer.current);
      navigate("/elap-admin-2024");
      return;
    }

    // Reset counter after 2 seconds of no clicks
    if (logoClickTimer.current) clearTimeout(logoClickTimer.current);
    logoClickTimer.current = setTimeout(() => {
      logoClickCount.current = 0;
    }, 2000);
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!generation || !paddedGroup || !paddedList) {
      setError(
        "Por favor ingresa generación, grupo y número de lista / Please enter generation, group and list number"
      );
      return;
    }

    if (!isIdValid) {
      setError(
        "La matrícula es: generación 3 dígitos, grupo 2 y lista 2 (7 en total) / The ID is: generation 3 digits, group 2, list 2 (7 total)"
      );
      return;
    }

    setLoading(true);
    try {
      const result = await checkStudent(studentId);

      // Temporary multiple-attempts policy: trust the server flag when the
      // deployed backend sends it. If absent (older backend), fall back to
      // blocking completed students — the original one-attempt-only behavior.
      const serverAllowsMultiple = result.multipleAttemptsAllowed === true;
      setAttemptsAllowed(serverAllowsMultiple);

      if (result.exists && result.attempt && !serverAllowsMultiple) {
        // Student already completed and policy is one-attempt-only → exit screen
        navigate("/exit", { state: { studentId } });
      } else {
        // New or resuming student → instructions screen explains the four
        // question types and per-part time limits before the test starts.
        navigate("/instructions", {
          state: {
            studentId,
            ...(result.exists && result.inProgress
              ? { attemptId: result.attemptId }
              : {}),
          },
        });
      }
    } catch (err: any) {
      setError("Error de conexión / Connection error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page min-h-screen bg-pattern flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background orbs */}
      <div className="bg-orb bg-orb-1" />
      <div className="bg-orb bg-orb-2" />
      <div className="bg-orb bg-orb-3" />
      <div className="w-full max-w-md animate-slide-up relative z-10">
        {/* Logo / Badge Area */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-28 h-28 mb-5 logo-glow cursor-pointer select-none" onClick={handleLogoClick}>
            <img
              src="/unipol-logo.jpg"
              alt="UNIPOL ELAP Logo"
              className="w-28 h-28 object-contain pointer-events-none"
            />
          </div>
          <h1 className="text-4xl font-bold title-gradient tracking-wider mb-2">
            UNIPOL ELAP
          </h1>
          <p className="text-sm text-slate-200 tracking-widest">
            English Language Assessment Program
          </p>
          <p className="text-xs text-slate-300 mt-1 tracking-wide">
            Programa de Evaluación del Idioma Inglés
          </p>
        </div>

        {/* Login Card */}
        <div className="glass-card-glow rounded-2xl p-8">
          <div className="gold-accent mb-6" />

          <form onSubmit={handleSubmit}>
            <label className="block mb-2 text-sm font-medium text-slate-100">
              Matrícula del Cadete (7 dígitos) / Cadet ID (7 digits)
            </label>

            <div className="grid grid-cols-3 gap-3 mb-2">
              <div>
                <label className="block mb-1 text-[11px] text-slate-400 uppercase tracking-wider">
                  Generación (3) / Gen.
                </label>
                <input
                  ref={generationRef}
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  autoComplete="off"
                  value={generation}
                  onChange={handleDigitChange(setGeneration, GEN_DIGITS, groupRef)}
                  placeholder="302"
                  className="input-field w-full px-3 py-3 rounded-lg text-lg text-center"
                  autoFocus
                  disabled={loading}
                />
              </div>
              <div>
                <label className="block mb-1 text-[11px] text-slate-400 uppercase tracking-wider">
                  Grupo (2) / Group
                </label>
                <input
                  ref={groupRef}
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  autoComplete="off"
                  value={group}
                  onChange={handleDigitChange(setGroup, GROUP_DIGITS, listRef)}
                  onBlur={padField(group, setGroup, GROUP_DIGITS)}
                  placeholder="08"
                  className="input-field w-full px-3 py-3 rounded-lg text-lg text-center"
                  disabled={loading}
                />
              </div>
              <div>
                <label className="block mb-1 text-[11px] text-slate-400 uppercase tracking-wider">
                  No. de Lista (2) / List
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  autoComplete="off"
                  value={listNumber}
                  onChange={handleDigitChange(setListNumber, LIST_DIGITS)}
                  onBlur={padField(listNumber, setListNumber, LIST_DIGITS)}
                  placeholder="05"
                  className="input-field w-full px-3 py-3 rounded-lg text-lg text-center"
                  disabled={loading}
                />
              </div>
            </div>

            {/* Live preview of the combined 7-digit ID */}
            <div className="flex items-center justify-between mb-4 text-xs">
              <span className="text-slate-400">
                {totalDigits} / {CADET_ID_TOTAL_DIGITS} dígitos / digits
              </span>
              <span
                className={`font-mono tracking-widest ${
                  isIdValid
                    ? "text-[var(--gold-400)] font-medium"
                    : "text-slate-500"
                }`}
              >
                {studentId ? `${generation}-${paddedGroup}-${paddedList}` : "—"}
              </span>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg px-4 py-3 mb-4 text-sm text-red-400 animate-fade-in">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading || !isIdValid}
              className="btn-primary w-full py-3 rounded-lg text-lg"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                      fill="none"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                  Registrando... / Registering...
                </span>
              ) : (
                "Registrar / Register"
              )}
            </button>
          </form>

          <div className="gold-accent mt-6 mb-4" />

          <p className="text-xs text-slate-300 text-center leading-relaxed">40 preguntas · 4 partes · 30/45/45/60 s por pregunta{!attemptsAllowed && " · Una sola oportunidad"}
            <br />40 questions · 4 parts · 30/45/45/60 s per question{!attemptsAllowed && " · One attempt only"}
          </p>
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-slate-300 mt-6 tracking-wide">SSC CDMX · UNIPOL</p>
      </div>
    </div>
  );
}
