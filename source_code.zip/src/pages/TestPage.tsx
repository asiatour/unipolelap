import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { startTest, submitAnswer, completeTest } from "../api/client";
import {
  TYPE_LABELS,
  TYPE_TIME_LIMITS,
  SECTION_ORDER,
} from "../config/assessment";

interface Question {
  id: number;
  questionType: number;
  difficultyOrder: number;
  questionText: string;
  optionA: string | null;
  optionB: string | null;
  optionC: string | null;
  optionD: string | null;
  correctAnswer: string;
}

interface TestState {
  studentId: string;
  attemptId?: number;
}

// Per-question time limit comes from the question type:
// Type 1 (Vocabulary) = 20s, Types 2-3 (Conversation / Fill in the Blank) = 45s,
// Type 4 (Type in the Missing Word) = 60s (see src/config/assessment.ts).

export function TestPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const state = location.state as TestState;

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [attemptId, setAttemptId] = useState<number>(state?.attemptId || 0);
  const [allQuestions, setAllQuestions] = useState<Question[]>([]);
  const [currentTypeIndex, setCurrentTypeIndex] = useState(0);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [answers, setAnswers] = useState<
    Record<number, { answer: string | null; timeSpent: number }>
  >({});
  const [timer, setTimer] = useState(TYPE_TIME_LIMITS[1] ?? 30);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [completedCount, setCompletedCount] = useState(0);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const questionStartTime = useRef<number>(Date.now());

  // Redirect if no student ID
  useEffect(() => {
    if (!state?.studentId) {
      navigate("/");
    }
  }, [state, navigate]);

  // Load questions
  useEffect(() => {
    if (!state?.studentId) return;

    const loadTest = async () => {
      try {
        const result = await startTest(state.studentId);
        if (result.error) {
          setError(result.error);
          return;
        }
        setAttemptId(result.attemptId);

        // Flatten questions in section presentation order (SECTION_ORDER,
        // 10 per type, 40 total): Fill in the Blank now comes before
        // Conversation. Random selection must still be presented easiest ->
        // hardest within each section, so sort each type's block by difficulty.
        const flat: Question[] = [];
        for (const type of SECTION_ORDER) {
          if (result.questions[type]) {
            const byType = [...result.questions[type]].sort(
              (a, b) => a.difficultyOrder - b.difficultyOrder
            );
            flat.push(...byType);
          }
        }
        setAllQuestions(flat);
        setLoading(false);
      } catch (err) {
        setError("Error loading test. Please try again.");
      }
    };

    loadTest();
  }, [state?.studentId]);

  // Current question. currentType is the question_type (for labels, timer
  // and behavior); the part number shown to the cadet is the position in
  // SECTION_ORDER (Fill in the Blank = Part 2, Conversation = Part 3).
  const totalQuestions = allQuestions.length;
  const currentQuestion = allQuestions[currentTypeIndex * 10 + currentQuestionIndex];
  const currentType = SECTION_ORDER[currentTypeIndex];
  const partNumber = currentTypeIndex + 1;
  const typeTimeLimit = TYPE_TIME_LIMITS[currentType] ?? 45;
  const globalIndex = currentTypeIndex * 10 + currentQuestionIndex;

  // Timer logic
  useEffect(() => {
    if (loading || !currentQuestion) return;

    setTimer(typeTimeLimit);
    questionStartTime.current = Date.now();

    timerRef.current = setInterval(() => {
      setTimer((prev) => {
        if (prev <= 1) {
          // Time's up - auto submit with no answer
          if (timerRef.current) clearInterval(timerRef.current);
          handleTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentTypeIndex, currentQuestionIndex, loading, currentQuestion]);

  const handleTimeUp = useCallback(() => {
    if (currentQuestion && !answers[currentQuestion.id]) {
      const timeSpent = Math.round(
        (Date.now() - questionStartTime.current) / 1000
      );
      setAnswers((prev) => ({
        ...prev,
        [currentQuestion.id]: { answer: null, timeSpent },
      }));
      submitToServer(currentQuestion.id, null, timeSpent);
      moveToNext();
    }
  }, [currentQuestion, answers]);

  const submitToServer = async (
    qId: number,
    answer: string | null,
    timeSpent: number
  ) => {
    try {
      await submitAnswer(attemptId, qId, answer, timeSpent);
    } catch (err) {
      console.error("Failed to submit answer:", err);
    }
  };

  const moveToNext = () => {
    if (currentQuestionIndex < 9) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else if (currentTypeIndex < 3) {
      setCurrentTypeIndex((prev) => prev + 1);
      setCurrentQuestionIndex(0);
    } else {
      // All questions done
      finishTest();
    }
    setSelectedAnswer(null);
  };

  const handleAnswer = (answer: string) => {
    if (!currentQuestion || answers[currentQuestion.id]) return;
    setSelectedAnswer(answer);

    // For multiple choice (types 1-3), immediately submit and advance
    if (currentType !== 4) {
      if (timerRef.current) clearInterval(timerRef.current);
      const timeSpent = Math.round(
        (Date.now() - questionStartTime.current) / 1000
      );
      setAnswers((prev) => ({
        ...prev,
        [currentQuestion.id]: { answer, timeSpent },
      }));
      setCompletedCount((prev) => prev + 1);
      submitToServer(currentQuestion.id, answer, timeSpent);
      moveToNext();
    }
  };

  const handleConfirmAnswer = () => {
    if (!currentQuestion || !selectedAnswer) return;
    if (timerRef.current) clearInterval(timerRef.current);

    const timeSpent = Math.round(
      (Date.now() - questionStartTime.current) / 1000
    );
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: { answer: selectedAnswer, timeSpent },
    }));
    setCompletedCount((prev) => prev + 1);
    submitToServer(currentQuestion.id, selectedAnswer, timeSpent);
    moveToNext();
  };

  const handleDontKnow = () => {
    if (!currentQuestion) return;
    if (timerRef.current) clearInterval(timerRef.current);

    const timeSpent = Math.round(
      (Date.now() - questionStartTime.current) / 1000
    );
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: { answer: null, timeSpent },
    }));
    setCompletedCount((prev) => prev + 1);
    submitToServer(currentQuestion.id, null, timeSpent);
    moveToNext();
  };

  const finishTest = async () => {
    setIsSubmitting(true);
    try {
      await completeTest(attemptId);
      navigate("/exit", { state: { studentId: state.studentId } });
    } catch (err) {
      setError("Error completing test. Your answers were saved.");
      setIsSubmitting(false);
    }
  };

  if (error) {
    return (
      <div className="min-h-screen bg-pattern flex items-center justify-center p-4">
        <div className="glass-card rounded-xl p-8 max-w-md text-center">
          <div className="text-red-400 text-lg mb-4">{error}</div>
          <button
            onClick={() => navigate("/")}
            className="btn-primary px-6 py-2 rounded-lg"
          >
            Volver / Back
          </button>
        </div>
      </div>
    );
  }

  if (loading || !currentQuestion) {
    return (
      <div className="min-h-screen bg-pattern flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin h-12 w-12 border-2 border-[var(--gold-500)] border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-slate-400">
            Preparando evaluación...
            <br />
            Preparing assessment...
          </p>
        </div>
      </div>
    );
  }

  const timerPercent = (timer / typeTimeLimit) * 100;
  const isWarning = timer <= Math.min(10, Math.ceil(typeTimeLimit / 3));
  const answeredCount = Object.keys(answers).length;

  return (
    <div className="min-h-screen bg-pattern">
      {/* Top Bar */}
      <div className="bg-[var(--navy-800)] border-b border-[var(--gold-500)]/20 px-4 py-3">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div>
            <span className="badge-gold text-xs px-3 py-1 rounded-full">
              UNIPOL ELAP
            </span>
          </div>
          <div className="text-sm text-slate-400">
            <span className="text-[var(--gold-400)] font-medium">
              {state.studentId}
            </span>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-[var(--navy-800)]/50 px-4 py-2">
        <div className="max-w-3xl mx-auto">
          {/* Type segments (in test presentation order) */}
          <div className="flex gap-1 mb-2">
            {SECTION_ORDER.map((type, idx) => {
              const typeStart = (type - 1) * 10;
              const typeEnd = type * 10;
              const typeCompleted = Object.keys(answers).filter((qId) => {
                const q = allQuestions.find((x) => x.id === parseInt(qId));
                return q && q.questionType === type;
              }).length;
              const isActive = currentTypeIndex === idx;

              return (
                <div key={type} className="flex-1">
                  <div className="text-[10px] text-center text-slate-500 mb-1 truncate">
                    {TYPE_LABELS[type].es}
                  </div>
                  <div className="h-1.5 bg-[var(--navy-900)] rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${(typeCompleted / 10) * 100}%`,
                        background: isActive
                          ? "var(--gold-500)"
                          : typeCompleted === 10
                          ? "var(--green-500)"
                          : "var(--navy-600)",
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="text-xs text-slate-500 text-center">
            {answeredCount} / 40 completadas
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-3xl mx-auto px-4 py-6">
        {/* Question Type Header */}
        <div className="flex items-center justify-between mb-4 animate-fade-in">
          <div>
            <span className="badge-gold text-[10px] px-2 py-0.5 rounded">
              Tipo {partNumber} / Type {partNumber}
            </span>
            <h2 className="text-sm text-slate-400 mt-1">
              {TYPE_LABELS[currentType].es} · {TYPE_LABELS[currentType].en}
            </h2>
          </div>
          <div className="text-right">
            <span className="text-xs text-slate-500">
              Pregunta {currentQuestionIndex + 1} de 10
            </span>
          </div>
        </div>

        {/* Type-specific directions */}
        {currentType === 2 && (
          <div className="mb-4 px-4 py-3 rounded-lg border border-[var(--gold-500)]/25 bg-[var(--gold-500)]/5 animate-fade-in">
            <p className="text-sm text-[var(--gold-300)] font-medium">
              Haz clic en la respuesta más apropiada.
            </p>
            <p className="text-sm text-slate-400 mt-0.5">
              Click on the most appropriate response.
            </p>
          </div>
        )}

        {/* Timer */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-slate-500">Tiempo / Time</span>
            <span
              className={`text-lg font-bold font-['Oswald'] tracking-wider ${
                isWarning ? "timer-warning" : "text-[var(--gold-400)]"
              }`}
            >
              {timer}s
            </span>
          </div>
          <div className="h-1 bg-[var(--navy-900)] rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-1000"
              style={{
                width: `${timerPercent}%`,
                background: isWarning ? "var(--red-500)" : "var(--gold-500)",
              }}
            />
          </div>
        </div>

        {/* Question (full dialogue — line breaks preserved) */}
        <div className="glass-card rounded-xl p-6 mb-6 animate-slide-up">
          <p className="text-lg leading-relaxed text-slate-200 whitespace-pre-line">
            {currentQuestion.questionText}
          </p>
        </div>

        {/* Options or Fill-in-the-blank */}
        {currentType === 4 ? (
          /* Fill in the blank */
          <div className="mb-6">
            <input
              type="text"
              value={selectedAnswer || ""}
              onChange={(e) => setSelectedAnswer(e.target.value)}
              placeholder="Escribe tu respuesta / Type your answer"
              className="input-field w-full px-4 py-3 rounded-lg text-lg"
              autoFocus
              disabled={!!answers[currentQuestion.id]}
            />
          </div>
        ) : (
          /* Multiple choice - 4 options */
          <div className="space-y-3 mb-6">
            {["A", "B", "C", "D"].map((letter) => {
              const optionKey = `option${letter}` as keyof Question;
              const optionText = currentQuestion[optionKey] as string | null;
              if (!optionText) return null;

              const isSelected = selectedAnswer === letter;
              const isAnswered = !!answers[currentQuestion.id];

              return (
                <button
                  key={letter}
                  onClick={() => handleAnswer(letter)}
                  disabled={isAnswered}
                  className={`option-card w-full text-left px-5 py-4 rounded-lg border flex items-center gap-4 ${
                    isSelected
                      ? "selected border-[var(--gold-500)]"
                      : "border-slate-700/50"
                  } ${isAnswered ? "opacity-50 cursor-not-allowed" : ""}`}
                >
                  <span
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0 ${
                      isSelected
                        ? "bg-[var(--gold-500)] text-[var(--navy-900)]"
                        : "bg-[var(--navy-700)] text-slate-400"
                    }`}
                  >
                    {letter}
                  </span>
                  <span className="text-slate-200">{optionText}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-3">
          <button
            onClick={handleDontKnow}
            disabled={!!answers[currentQuestion.id] || isSubmitting}
            className="btn-secondary flex-1 py-3 rounded-lg text-sm"
          >
            No sé / I don't know
          </button>
          {currentType === 4 && (
            <button
              onClick={handleConfirmAnswer}
              disabled={
                !selectedAnswer ||
                selectedAnswer.trim() === "" ||
                !!answers[currentQuestion.id] ||
                isSubmitting
              }
              className="btn-primary flex-1 py-3 rounded-lg text-sm"
            >
              Confirmar / Confirm
            </button>
          )}
        </div>
      </div>

      {/* Confirm Dialog */}
      {showConfirm && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
          <div className="glass-card rounded-xl p-6 max-w-sm w-full animate-slide-up">
            <h3 className="text-lg text-[var(--gold-400)] mb-3">
              ¿Terminar evaluación?
            </h3>
            <p className="text-slate-400 text-sm mb-4">
              Complete test? You have answered {answeredCount} of 40 questions.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowConfirm(false)}
                className="btn-secondary flex-1 py-2 rounded-lg text-sm"
              >
                Cancelar
              </button>
              <button
                onClick={finishTest}
                className="btn-primary flex-1 py-2 rounded-lg text-sm"
              >
                Terminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
