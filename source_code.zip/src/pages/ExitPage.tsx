import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";

interface ExitState {
  studentId: string;
}

const COUNTDOWN_SECONDS = 10;

export function ExitPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const state = location.state as ExitState;
  const [countdown, setCountdown] = useState(COUNTDOWN_SECONDS);

  useEffect(() => {
    if (!state?.studentId) {
      navigate("/");
      return;
    }

    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          navigate("/");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [state, navigate]);

  return (
    <div className="min-h-screen bg-pattern flex items-center justify-center p-4">
      <div className="w-full max-w-md animate-slide-up text-center">
        {/* Checkmark Icon */}
        <div className="inline-flex items-center justify-center w-24 h-24 rounded-full border-2 border-emerald-400/40 mb-8 bg-emerald-400/10">
          <svg
            className="w-12 h-12 text-emerald-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M4.5 12.75l6 6 9-13.5"
            />
          </svg>
        </div>

        {/* Thank You Message */}
        <h1 className="text-3xl font-bold text-[var(--gold-500)] tracking-wider mb-3">
          ¡Gracias!
        </h1>
        <h2 className="text-xl text-[var(--gold-400)] tracking-wider mb-2">
          Thank you for taking the test.
        </h2>
        <p className="text-sm text-slate-400 mb-2">
          Gracias por realizar la evaluación.
        </p>

        {/* Student ID */}
        <div className="glass-card rounded-xl p-4 mt-6 mb-8">
          <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">
            Estudiante / Student
          </p>
          <p className="text-lg font-medium text-[var(--gold-400)] font-['Oswald'] tracking-wider">
            {state?.studentId}
          </p>
        </div>

        {/* Countdown */}
        <div className="glass-card rounded-xl p-5">
          <p className="text-sm text-slate-400 mb-2">
            Regresando al inicio en / Returning to home in
          </p>
          <div className="text-4xl font-bold font-['Oswald'] text-[var(--gold-500)] tracking-wider">
            {countdown}s
          </div>
          <div className="mt-3 h-1.5 bg-[var(--navy-900)] rounded-full overflow-hidden">
            <div
              className="h-full rounded-full bg-[var(--gold-500)] transition-all duration-1000"
              style={{ width: `${(countdown / COUNTDOWN_SECONDS) * 100}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
