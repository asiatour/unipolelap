import { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  QUESTION_TYPES,
  TOTAL_MAX_SECONDS,
  SECTION_ORDER,
} from "../config/assessment";

interface InstructionsState {
  studentId: string;
  attemptId?: number;
}

export function InstructionsPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const state = location.state as InstructionsState | null;

  // Redirect home if reached directly (no student ID in state)
  useEffect(() => {
    if (!state?.studentId) {
      navigate("/");
    }
  }, [state, navigate]);

  if (!state?.studentId) return null;

  const totalMinutes = Math.round(TOTAL_MAX_SECONDS / 60);

  const handleStart = () => {
    navigate("/test", {
      state: { studentId: state.studentId, attemptId: state.attemptId },
    });
  };

  return (
    <div className="min-h-screen bg-pattern">
      {/* Top Bar */}
      <div className="bg-[var(--navy-800)] border-b border-[var(--gold-500)]/20 px-4 py-3">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div>
            <span className="badge-gold text-xs px-3 py-1 rounded-full">
              UNIPOL ELAP
            </span>
          </div>
          <div className="text-sm text-slate-400">
            <span className="text-[var(--gold-400)] font-medium">
              {state.studentId}
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8 animate-slide-up">
          <div className="inline-flex items-center justify-center w-20 h-20 mb-4 logo-glow">
            <img
              src="/unipol-logo.jpg"
              alt="UNIPOL ELAP Logo"
              className="w-20 h-20 object-contain"
            />
          </div>
          <h1 className="text-3xl font-bold title-gradient tracking-wider mb-2">
            Instrucciones
          </h1>
          <p className="text-sm text-slate-200 tracking-widest">Instructions</p>
          <p className="text-xs text-slate-400 mt-3 leading-relaxed">
            Tu evaluación de inglés tiene <strong className="text-[var(--gold-400)]">4 partes</strong> y{" "}
            <strong className="text-[var(--gold-400)]">40 preguntas</strong> en total.
            <br />
            Your English assessment has <strong className="text-[var(--gold-400)]">4 parts</strong> and{" "}
            <strong className="text-[var(--gold-400)]">40 questions</strong> in total.
          </p>
        </div>

        {/* Question type cards */}
        <div className="space-y-4 mb-8">
          {SECTION_ORDER.map((type, index) => {
            const q = QUESTION_TYPES.find((t) => t.type === type)!;
            return (
            <div
              key={q.type}
              className="glass-card rounded-xl p-5 animate-slide-up"
              style={{ animationDelay: `${index * 0.08}s` }}
            >
              <div className="flex items-start justify-between gap-4 mb-3">
                <div>
                  <span className="badge-gold text-[10px] px-2 py-0.5 rounded">
                    Tipo {index + 1} · Parte {index + 1} / Part {index + 1}
                  </span>
                  <h2 className="text-lg text-slate-100 font-semibold mt-2">
                    {q.es}
                    <span className="text-slate-400 font-normal"> · {q.en}</span>
                  </h2>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-2xl font-bold font-['Oswald'] tracking-wider text-[var(--gold-400)]">
                    {q.timeLimitSeconds}s
                  </div>
                  <div className="text-[10px] text-slate-500 leading-tight">
                    máx. por pregunta
                    <br />
                    max. per question
                  </div>
                </div>
              </div>

              <p className="text-sm text-slate-200 leading-relaxed">
                {q.descEs}
              </p>
              <p className="text-sm text-slate-400 leading-relaxed mt-0.5">
                {q.descEn}
              </p>

              <div className="mt-3 flex flex-wrap gap-2 text-[11px]">
                <span className="px-2 py-0.5 rounded bg-[var(--navy-700)] text-slate-300">
                  10 preguntas / questions
                </span>
                <span className="px-2 py-0.5 rounded bg-[var(--navy-700)] text-slate-300">
                  {q.formatEs} / {q.formatEn}
                </span>
              </div>
            </div>
            );
          })}
        </div>

        {/* Summary + tips */}
        <div className="glass-card rounded-xl p-5 mb-8 animate-fade-in">
          <div className="gold-accent mb-4" />
          <div className="grid grid-cols-2 gap-4 text-center mb-4">
            <div>
              <div className="text-2xl font-bold font-['Oswald'] text-[var(--gold-400)]">
                40
              </div>
              <div className="text-xs text-slate-400">
                Preguntas / Questions
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold font-['Oswald'] text-[var(--gold-400)]">
                ~{totalMinutes} min
              </div>
              <div className="text-xs text-slate-400">
                Duración máxima / Max duration
              </div>
            </div>
          </div>
          <div className="gold-accent mb-4" />
          <ul className="text-sm text-slate-300 space-y-1.5 leading-relaxed">
            <li>
              • Al responder, avanzarás automáticamente a la siguiente pregunta.
            </li>
            <li>
              • Cuando se acabe el tiempo, la pregunta se marcará como sin
              responder.
            </li>
            <li>
              • En la Parte 4 escribe la palabra que falta y confirma tu
              respuesta.
            </li>
          </ul>
          <ul className="text-sm text-slate-400 space-y-1.5 leading-relaxed mt-2">
            <li>
              • You will advance automatically after answering each question.
            </li>
            <li>
              • When time runs out, the question will be marked as unanswered.
            </li>
            <li>
              • In Part 4, type the missing word and confirm your answer.
            </li>
          </ul>
        </div>

        {/* Start button */}
        <div className="text-center animate-slide-up">
          <button
            onClick={handleStart}
            className="btn-primary w-full max-w-md py-4 rounded-lg text-lg"
          >
            Iniciar la Evaluación / Start the Assessment
          </button>
          <p className="text-xs text-slate-400 mt-3">
            Matrícula / Cadet ID:{" "}
            <span className="font-mono text-[var(--gold-400)]">
              {state.studentId}
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
