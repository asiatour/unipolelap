// Single source of truth for question types, labels, and per-question time
// limits. Used by InstructionsPage (overview screen shown after ID entry) and
// TestPage (live per-question timer) so both always show the same timing.

export interface QuestionTypeInfo {
  type: number;
  es: string;
  en: string;
  descEs: string;
  descEn: string;
  formatEs: string;
  formatEn: string;
  /** Maximum seconds allowed for each question in this part. */
  timeLimitSeconds: number;
}

export const QUESTION_TYPES: QuestionTypeInfo[] = [
  {
    type: 1,
    es: "Vocabulario",
    en: "Vocabulary",
    descEs: "Traduce la palabra al inglés. Elige la opción correcta.",
    descEn: "Translate the word into English. Choose the correct option.",
    formatEs: "Opción múltiple",
    formatEn: "Multiple choice",
    timeLimitSeconds: 30,
  },
  {
    type: 2,
    es: "Conversación",
    en: "Conversation",
    descEs:
      "Completa la conversación. Haz clic en la respuesta más apropiada.",
    descEn: "Complete the conversation. Click on the most appropriate response.",
    formatEs: "Opción múltiple",
    formatEn: "Multiple choice",
    timeLimitSeconds: 45,
  },
  {
    type: 3,
    es: "Completar",
    en: "Fill in the Blank",
    descEs:
      "Se muestra una conversación con una palabra faltando en la cuarta parte. Elige la palabra correcta entre cuatro opciones.",
    descEn:
      "A conversation is shown with one word missing in the fourth part. Choose the correct word from the four options.",
    formatEs: "Opción múltiple",
    formatEn: "Multiple choice",
    timeLimitSeconds: 45,
  },
  {
    type: 4,
    es: "Escribe la Palabra que Falta",
    en: "Type in the Missing Word",
    descEs: "Escribe la palabra que falta en la conversación.",
    descEn: "Type the missing word in the conversation.",
    formatEs: "Respuesta escrita",
    formatEn: "Typed answer",
    timeLimitSeconds: 60,
  },
];

export const TYPE_LABELS: Record<number, { en: string; es: string }> =
  Object.fromEntries(
    QUESTION_TYPES.map((t) => [t.type, { en: t.en, es: t.es }])
  );

export const TYPE_TIME_LIMITS: Record<number, number> = Object.fromEntries(
  QUESTION_TYPES.map((t) => [t.type, t.timeLimitSeconds])
);

/**
 * Presentation order of the sections on the test (question "parts").
 * Sections 2 and 3 were swapped on 2026-10-02: Fill in the Blank (type 3)
 * is easier than Conversation (type 2), so it is presented first.
 * Part N on screen = SECTION_ORDER[N - 1] (a question_type value).
 */
export const SECTION_ORDER: number[] = [1, 3, 2, 4];

/** Total maximum assessment time in seconds (10 questions per type). */
export const TOTAL_MAX_SECONDS = QUESTION_TYPES.reduce(
  (sum, t) => sum + t.timeLimitSeconds * 10,
  0
);
