import { useNavigate } from "react-router-dom";

/**
 * Floating action button visible ONLY in development mode.
 * Links to the admin question editor.
 */
export function DevFloatingButton() {
  const navigate = useNavigate();

  // Only render in development mode
  if (!import.meta.env.DEV) return null;

  return (
    <button
      onClick={() => navigate("/elap-admin-2024")}
      className="fixed bottom-6 right-6 z-50 group"
      title="Question Editor (Dev Only)"
    >
      <div className="flex items-center gap-2 bg-[var(--navy-800)] border border-[var(--gold-500)]/40 text-[var(--gold-400)] px-4 py-3 rounded-full shadow-lg shadow-black/40 hover:bg-[var(--navy-700)] hover:border-[var(--gold-500)]/60 transition-all duration-200">
        {/* Pencil/Editor Icon */}
        <svg
          className="w-5 h-5"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={1.5}
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10"
          />
        </svg>
        <span className="text-sm font-medium tracking-wide hidden sm:inline">
          Editor
        </span>
        {/* Dev badge */}
        <span className="text-[9px] bg-[var(--gold-500)]/20 text-[var(--gold-400)] px-1.5 py-0.5 rounded-full font-bold uppercase">
          DEV
        </span>
      </div>
    </button>
  );
}
