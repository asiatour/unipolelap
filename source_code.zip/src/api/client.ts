import { createEdgeSpark } from "@edgespark/client";

// Backend worker URL
const WORKER_URL =
  import.meta.env.VITE_BACKEND_URL ||
  "https://staging--vp5tdlcfjg7l98fiuarx.youbase.cloud";

export const client = createEdgeSpark({ baseUrl: WORKER_URL });

// API helpers
export async function checkStudent(studentId: string) {
  const res = await client.api.fetch("/api/public/check-student", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ studentId }),
  });
  return res.json();
}

export async function startTest(studentId: string) {
  const res = await client.api.fetch("/api/public/start-test", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ studentId }),
  });
  return res.json();
}

export async function submitAnswer(
  attemptId: number,
  questionId: number,
  selectedAnswer: string | null,
  timeSpent: number
) {
  const res = await client.api.fetch("/api/public/submit-answer", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ attemptId, questionId, selectedAnswer, timeSpent }),
  });
  return res.json();
}

export async function completeTest(attemptId: number) {
  const res = await client.api.fetch("/api/public/complete-test", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ attemptId }),
  });
  return res.json();
}

export async function getResults(studentId: string) {
  const res = await client.api.fetch(`/api/public/results/${studentId}`);
  return res.json();
}

export async function getAdminScores(adminCode: string) {
  const res = await client.api.fetch("/api/public/admin/scores", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ adminCode }),
  });
  return res.json();
}

export async function deleteScore(adminCode: string, scoreId: number) {
  const res = await client.api.fetch("/api/public/admin/scores/delete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ adminCode, scoreId }),
  });
  return res.json();
}

// Question Management API (Admin only)

export async function getAdminQuestions(adminCode: string, questionType?: number) {
  const res = await client.api.fetch("/api/public/admin/questions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ adminCode, questionType }),
  });
  return res.json();
}

export async function createQuestion(
  adminCode: string,
  question: {
    questionType: number;
    difficultyOrder: number;
    questionText: string;
    optionA?: string;
    optionB?: string;
    optionC?: string;
    optionD?: string;
    correctAnswer: string;
  }
) {
  const res = await client.api.fetch("/api/public/admin/questions/create", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ adminCode, question }),
  });
  return res.json();
}

export async function updateQuestion(
  adminCode: string,
  questionId: number,
  updates: Record<string, any>
) {
  const res = await client.api.fetch("/api/public/admin/questions/update", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ adminCode, questionId, updates }),
  });
  return res.json();
}

export async function deleteQuestion(adminCode: string, questionId: number) {
  const res = await client.api.fetch("/api/public/admin/questions/delete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ adminCode, questionId }),
  });
  return res.json();
}
