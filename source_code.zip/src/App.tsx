import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { LoginPage } from "./pages/LoginPage";
import { InstructionsPage } from "./pages/InstructionsPage";
import { TestPage } from "./pages/TestPage";
import { ExitPage } from "./pages/ExitPage";
import { ResultsPage } from "./pages/ResultsPage";
import { AdminPage } from "./pages/AdminPage";
import { DevFloatingButton } from "./components/DevFloatingButton";
import "./index.css";

function App() {
  return (
    <BrowserRouter>
      <DevFloatingButton />
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/instructions" element={<InstructionsPage />} />
        <Route path="/test" element={<TestPage />} />
        <Route path="/exit" element={<ExitPage />} />
        <Route path="/results" element={<ResultsPage />} />
        <Route path="/elap-admin-2024" element={<AdminPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
