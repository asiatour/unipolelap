# UNIPOL ELAP - English Language Assessment Program

## Programa de Evaluación del Idioma Inglés para Cadetes de Policía

### Overview
A web-based English assessment system for Mexican police cadets. Cadets log in with their 7-digit cadet ID — Generación (3) + Grupo (2) + No. de Lista (2) — via the bilingual **Register** button, review the instructions screen (four question types + per-part time limits), and complete 40 questions (10 per type) with a per-type timer: **30s** for Type 1, **45s** for Types 2-3, **60s** for Type 4.

### Section Names, Order & Timing (updated 2026-10-02)
Sections renamed to match their actual formats: 1 **Vocabulary**, 2 **Conversation**, 3 **Fill in the Blank** (conversation shown in full with only the correct answer's word blanked inline, e.g. `B: Nice to __________ you, too.`; choose the word from 4 options), 4 **Type in the Missing Word** (typed answer). Timings: **30s / 45s / 45s / 60s** (total max = exactly **30 min**).

**Presentation order**: sections 2 and 3 were **swapped** on 2026-10-02 — Fill in the Blank (question_type 3) is easier, so it is now Part 2 and Conversation (question_type 2) is Part 3. `SECTION_ORDER = [1, 3, 2, 4]` in `src/config/assessment.ts` drives the order on the Instructions screen, the live test (question sequence, part badges, progress segments) and the results breakdown; part numbers on screen are positions in this array, not `question_type`. Question data in the DB is untouched.

### Login ID Format
- Cadet ID (matrícula) = **7 digits**: Generación (3) + Grupo (2) + No. de Lista (2) — e.g. `302` · `08` · `05` → `3020805` (leading zeros matter: group/list are always 2 digits)
- Fixed widths per field (3-2-2); digits only, auto-advance to the next field when one is full
- Single-digit **group/list** values are left-padded with zeros on blur **and at submit** (e.g. `8` → `08`) so cadets always match the format; placeholder example is `302 · 08 · 05`
- The **Generación** field is never zero-padded — its number stays exactly as typed (e.g. `3` stays `3`, never becomes `003`)
- Login page shows a live preview (`302-08-05`) and a `x / 7` digit counter; submit stays disabled until all 7 digits are entered
- The combined 7-digit string is stored as `studentId` in the DB (no schema change)

### Architecture
- **Frontend**: React 18 + TypeScript + Tailwind CSS + Vite
- **Backend**: EdgeSpark (Cloudflare Workers + D1 Database)
- **Backend URL**: `https://staging--vp5tdlcfjg7l98fiuarx.youbase.cloud`

### Question Types
| Type | Category | ES | EN |
|------|----------|----|----|
| 1 | Vocabulary | Vocabulario | Vocabulary |
| 2 | Conversation | Conversación | Conversation |
| 3 | Fill in the Blank | Completar | Fill in the Blank |
| 4 | Type in the Missing Word | Escribe la Palabra que Falta | Type in the Missing Word |

Presentation order on the test (Part 1 → 4) = `SECTION_ORDER` = [1, 3, 2, 4]: Part 1 Vocabulary · Part 2 Fill in the Blank · Part 3 Conversation · Part 4 Type in the Missing Word.

### Pages
| Route | Description |
|-------|-------------|
| `/` | Login page - 7-digit cadet ID (Generación 3 + Grupo 2 + Lista 2), submit button "Registrar / Register" |
| `/instructions` | Instructions screen (shown after ID entry) - explains the 4 question types and per-part time limits; "Iniciar la Evaluación / Start the Assessment" button continues to `/test` |
| `/test` | Test page - Questions with per-type timer |
| `/exit` | Exit screen - "Thank you" in EN/ES, 10s auto-redirect to home |
| `/results` | Results page - Score display (admin/legacy) |
| `/elap-admin-2024` | Admin page - Scores + hidden question editor |

### Database Tables
- `questions` - All test questions (4 types × 10 difficulty levels)
- `test_attempts` - Student test sessions
- `answers` - Individual answer records

### Scoring
- 1 point per correct answer, 40 points total
- **Multiple correct answers for Type 4 (2026-10-02)**: typed-answer questions (question_type 4) can list several accepted answers stored in `questions.correct_answer` joined with `/` (e.g. `stolen/took`; `,` and `;` also act as separators). Grading in `/api/public/submit-answer` (`backend/server/src/index.ts`) marks the answer correct if the typed text matches ANY accepted option (trimmed, lowercased, whitespace-collapsed); single-answer questions behave exactly as before. In the admin question editor, Type 4 shows the primary answer plus removable "+ Añadir otra respuesta correcta / Add another correct answer" fields (`altAnswers` in `formDraft`, joined by `joinCorrectAnswers` in `src/pages/AdminPage.tsx`, split back by `splitCorrectAnswers` when editing); the questions table shows the joined string as-is
- **Ranking bands (raw score out of 40, updated 2026-10-01)**:
  | Score | Level (Results page & Admin scores table — full labels since 2026-10-02) | Color |
  |-------|----------------------------------------------|-------|
  | 31–40 | Trainer Material | emerald |
  | 21–30 | Ready for Investigation | blue |
  | 16–20 | Cadet Fast-Track | yellow |
  | 11–15 | Cadet High-Level | orange |
  | 0–10 | Cadet Low-Level | red |
  - Defined in `getLevel` in `src/pages/ResultsPage.tsx` and duplicated (full labels) in the scores table in `src/pages/AdminPage.tsx` — keep both in sync
  - Bands key off the raw score normalized to 40 points (`Math.round(score/maxScore*40)`), not the percentage
- Attempts: **TEMPORARY (2026-10-01) — multiple attempts allowed per student ID**. The policy is controlled by two flags: `ALLOW_MULTIPLE_ATTEMPTS` in `backend/server/src/index.ts` (server-side enforcement + `multipleAttemptsAllowed` flag in `check-student` responses) and `TEMP_MULTIPLE_ATTEMPTS` in `src/pages/LoginPage.tsx` (login copy). Set both back to `false` to restore the original one-attempt-only policy. Backend deployed to staging 2026-10-01 and re-deployed 2026-10-02 (see Retakes below); the frontend flag is already `true` in the repo
- **Retakes always create a new attempt row (2026-10-02)**: `test_attempts` has **no unique constraint on `student_id`** (plain index only), and every `/api/public/start-test` call inserts a fresh row — so a cadet retaking with the same matrícula (even on the same browser) gets each result saved separately. The admin scores screen shows **one row per completed attempt**; duplicate cadet IDs appear as multiple rows with their own dates/scores/levels. Backend hardening deployed 2026-10-02: (1) `start-test` first marks any of that student's stale `in_progress` attempts as `abandoned` (valid per the `test_attempts` status check constraint alongside `in_progress`/`completed`; `abandoned` rows never show in the admin screen — which filters `status = 'completed'` — and stop `check-student` from reporting ancient "in progress" sessions left behind on the same browser), and (2) `GET /api/public/results/:studentId` now returns the **latest** completed attempt (`ORDER BY completed_at DESC, id DESC`) instead of an arbitrary first row, so retakes display the newest score
- Questions ordered by difficulty (earlier in source = easier)
- 10 random questions selected per type, then **presented easiest → hardest** within each section:
  - Backend `/api/public/start-test` re-sorts each type's 10 selected questions by `difficulty_order` ascending; ties keep the random selection order (verified live against the staging API)
  - `TestPage` additionally sorts each type's block by `difficultyOrder` after loading, so presentation stays difficulty-ordered even if the backend order ever changes (safety net)
  - `difficulty_order` cycles 1-10 per type: type 1 ≈ 10 questions per level; types 2-4 have 5 per level 1-8 and 4 per level 9-10

### Admin Access
- Secret route: `/elap-admin-2024`
- Protected by `ADMIN_SECRET_CODE` environment variable
- **Session persistence (2026-10-02)**: after a successful login the admin code is saved to `sessionStorage` (`ADMIN_SESSION_KEY` in `src/pages/AdminPage.tsx`) and re-verified against the backend on page load, so refreshing the tab doesn't require retyping the code. It clears when the tab/browser closes, when the stored code is rejected, and on "Cerrar sesión"
- View all scores, sort by score/student/date
- **Delete scores (2026-10-01)**: each row in the scores table has an "Eliminar" button — bilingual confirm dialog, then deletes the attempt + its answers via `/api/public/admin/scores/delete` (admin-code protected, atomic `db.batch`)
- **Export CSV (2026-10-02)**: an "Exportar CSV / Export CSV" button sits at the right end of the sort-controls row in the Scores tab and downloads the **full results table** as `unipol-elap-resultados-YYYY-MM-DD.csv`. One row per completed attempt, in the current sort order, with columns: `#`, `Matrícula / Student ID`, `Puntaje / Score`, `Máximo / Max`, `%`, one per-type column per `SECTION_ORDER` section (full bilingual labels via `TYPE_LABELS_FULL`), `Nivel / Level` (full band label, `getLevelLabel`) and `Fecha / Date` (`YYYY-MM-DD HH:MM:SS`, `sv-SE` locale). Built by `handleExportScoresCsv` in `src/pages/AdminPage.tsx` using module-level helpers `SCORES_CSV_HEADERS`, `csvEscape` and `downloadCsvFile` (BOM `\uFEFF` + `\r\n` so Excel/Sheets open accents correctly); the questions-tab Google Forms export shares the same `downloadCsvFile` helper
- **Scores table layout (2026-10-02)**: the scores table uses `admin-table-compact` (tighter padding/font, defined in `src/index.css`) and shows **full level descriptions** ("Ready for Investigation", etc., `whitespace-nowrap` badge) — other columns were condensed so the level text fits; per-type columns follow `SECTION_ORDER`; dates render as `MM/DD HH:MM`
- **Question editor (CRUD)**: Create, edit, delete questions — fully hidden from test-taker frontend
- **Inline edit form (2026-10-02)**: clicking "Editar" on a question row opens the edit form inline directly below that row (not at the top of the page); the form scrolls smoothly into view, the row is highlighted, and changing the type filter closes the open form. The create form ("+ Nueva Pregunta") still opens at the top of the Questions tab
- **Export to Google Forms (2026-10-02)**: the "📤 Exportar / Export" button in the Questions tab downloads a UTF-8 CSV (BOM included) of the currently visible questions (respects the type filter), ordered by `SECTION_ORDER` part then `difficulty_order` — columns: Parte, Tipo, Pregunta, Opción A-D, Respuesta correcta, Dificultad (column order is mirrored by column indexes in `GOOGLE_FORMS_APPS_SCRIPT`). A panel then shows a copy-paste Google Apps Script (`createFormFromSheet`) that builds an auto-graded Google Form quiz from the imported sheet (`sheets.new` → import CSV → Extensions → Apps Script). Type 4 (typed answer) items are created without an auto answer key (Apps Script limitation — `FormApp` has no text-item grading); the panel says so. Helpers/constants live above `AdminPage` in `src/pages/AdminPage.tsx` (`GOOGLE_FORMS_CSV_HEADERS`, `csvEscape`, `GOOGLE_FORMS_APPS_SCRIPT`); direct Google Forms API creation was rejected since it needs per-user Google OAuth
- **Save keeps your place in the list (2026-10-02)**: after saving/creating/deleting a question (or finishing a bulk import), the questions list refreshes **silently** (`loadQuestions({ silent: true })` — no "Cargando..." spinner, table stays mounted) so the page never jumps back to the top; after an inline edit save the scroll position is restored via `requestAnimationFrame` and the saved row (id `question-row-<id>`) is scrolled back into view. Tab switches and type-filter changes still show the spinner (full load)
- Tab system: "Resultados / Scores" and "Preguntas / Questions"

### Assessment Timing (2026-10-01)
- Per-question time limit depends on the question type/part: **Type 1 = 30s max**, **Types 2 & 3 = 45s max**, **Type 4 = 60s max** (total max = exactly 30 min = 1800s)
- Section presentation order is `SECTION_ORDER` ([1, 3, 2, 4], swapped 2026-10-02) — part numbers shown to cadets are positions in this array; `question_type` values in the DB are unchanged
- Timing constants live in `src/config/assessment.ts` (`QUESTION_TYPES`, `TYPE_TIME_LIMITS`) — the instructions screen and the live test timer both read from there, so editing one file keeps them in sync
- Timer warning (red) kicks in at the last third of each question's limit, capped at 10s
- Instructions flow: LoginPage validates the ID → navigates to `/instructions` (new AND resumed attempts) → Start button navigates to `/test` passing `studentId` + optional `attemptId` → `TestPage` still calls `/api/public/start-test` itself (the backend creates the attempt row and abandons any stale in-progress attempts first — see Attempts)

### Question Type Directions
- **Type 2 (Conversation)** shows bilingual directions under the type header on every question: "Haz clic en la respuesta más apropiada. / Click on the most appropriate response."
- Directions are defined inline in `src/pages/TestPage.tsx` (`currentType === 2` block) — edit there if wording changes

### Key Features
- Per-question timer: 30s (Type 1) / 45s (Types 2-3) / 60s (Type 4)
- Instructions screen between login and test (bilingual, four type cards with time limits)
- Bilingual CTAs: home button "Registrar / Register", instructions button "Iniciar la Evaluación / Start the Assessment"
- Click answer → auto-advance to next question (no confirm needed for multiple choice)
- "No sé / I don't know" button to skip
- Exit screen: "Thank you for taking the test" in English and Spanish
- 10-second countdown on exit screen, then auto-redirect to home
- Bilingual interface (Spanish + English)
- Police-themed dark design with gold accents
- Mobile-responsive

### Question Bank
240 questions imported from the official UNIPOL ELAP docx:
- **Type 1 (Vocabulary)**: 96 questions — Spanish→English translation MCQs
- **Type 2 (Conversation)**: 48 questions — Conversation completion (pick the right dialogue line)
- **Type 3 (Fill in the Blank)**: 48 questions — Conversation shown in full with only the correct answer's word blanked inline (e.g. `B: I'm __________ to the market.`); choose the word from 4 options (MCQ)
- **Type 4 (Type in the Missing Word)**: 48 questions — Type the missing word (no options)

All answers verified against the original document answer key. Difficulty levels 1-10 cycle through each type. The test picks 10 random questions per type (40 total).

### Full Dialogue Question Text (Types 2-4)
- Types 2-4 store the **entire dialogue** in `question_text` (multi-line, speaker lines `A: ...` / `B: ...`), with a visible blank `__________` where the missing word/response goes. Type 2: the blank replaces the final speaker line (the missing response). **Type 3 (2026-10-02): the blank is inline — only the correct answer's word is missing and the rest of the line stays visible** (e.g. `B: Nice to __________ you, too.`), matching the official docx Part 2 "Single-Word Completion" format; the old pipeline collapsed the whole line to `B: __________`, which removed all context and confused test takers. Type 4: blank embedded in the line to complete (typed answer)
- Type-3 rebuild (2026-10-02): `chat/rebuild_type3_inline_blanks.py` re-parses docx Part 2 from `chat/questions_raw.md` and restores inline blanks for ids 191-238 (options/answers untouched); `--write-import` regenerates `chat/import_type3_reading.txt` in the inline format. `chat/format_questions.py` now preserves inline blanks (`clean_blanks`) instead of collapsing whole lines, so future regeneration keeps the context words
- DB row map: type 2 = ids 143-190, type 3 = 191-238, type 4 = 239-286 (insertion order == `chat/import_type*.txt` order)
- Frontend renders `question_text` with `whitespace-pre-line`: TestPage question card, AdminPage import preview, question list (`line-clamp-3`), and editor textarea (6 rows)
- Import parsers preserve full dialogues: offline pipeline (`chat/format_questions.py`, `chat/gen_sql.py`) and the AdminPage "Texto extraído" parser — options only match `A)` / `A.` lines; speaker lines `A:` / `B:` stay inside question text; fill-in answers (type 4) keep full words; underscore runs normalize to `__________`
- Repair/report scripts: `chat/fix_full_dialogues.py` (one-time rebuild of types 2-4 text from the import files), `chat/probe_drift.py` (report-only option/answer drift vs verified files)
- Known intentional DB option edits kept as-is vs verified files: id 143 option A, id 153 option D, id 163 option B

### Deployment
- Backend: `cd backend && npx edgespark deploy`
- Frontend: Built and deployed via Youware platform
